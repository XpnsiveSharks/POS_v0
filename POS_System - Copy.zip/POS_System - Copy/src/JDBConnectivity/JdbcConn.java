package JDBConnectivity;

import java.sql.Connection;
import java.sql.DriverManager;

public class JdbcConn {
	public static Connection connect() {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3333/posdb", "root", "root");

			return (Connection) conn;
		}
		catch(Exception e) 
		{
			return null;
		}
	}
}

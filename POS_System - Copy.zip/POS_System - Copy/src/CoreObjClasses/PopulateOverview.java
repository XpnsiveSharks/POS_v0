package CoreObjClasses;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import JDBConnectivity.JdbcConn;
import net.proteanit.sql.DbUtils;

public class PopulateOverview {

    private JTable tblIngredients, tblSoldItems, tblOrders, tblSoldOrders;
    private JLabel lblWarningMessage;
    private JTextField txtIngStatFilter, txtSoldItemsFilter, txtOrdersFilter, txtSoldAndOrders;
    private TableRowSorter<TableModel> SoldItemSorter;
    private TableModel SoldItemTableModel;
    private TableRowSorter<TableModel> IngredientStatSorter;
    private TableModel IngredientStatSorterTableModel;
    private TableRowSorter<TableModel> OrderSorter;
    private TableModel OrderTableModel;
    private TableRowSorter<TableModel> OrdersSoldSorter;
    private TableModel OrdersSoldTableModel;
    private Connection conn = JdbcConn.connect();

    public PopulateOverview(JTable tblIngredients, JLabel lblWarningMessage, JTable tblSoldItems,
                            JTextField txtIngStatFilter, JTextField txtSoldItemsFilter, JTable tblOrders, JTextField txtOrdersFilter,
                            JTextField txtSoldAndOrders, JTable tblSoldOrders) {
        this.tblIngredients = tblIngredients;
        this.lblWarningMessage = lblWarningMessage;
        this.tblSoldItems = tblSoldItems;
        this.txtIngStatFilter = txtIngStatFilter;
        this.txtSoldItemsFilter = txtSoldItemsFilter;
        this.tblOrders = tblOrders;
        this.txtOrdersFilter = txtOrdersFilter;
        this.tblSoldOrders = tblSoldOrders;
        this.txtSoldAndOrders = txtSoldAndOrders;
    }

    public void checkIngredientQuantityUsedUp() {
        try {
            String query = "SELECT Ingredient FROM ingredients WHERE Quantity <= 5";
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String ingredient = rs.getString("Ingredient");
                lblWarningMessage.setText("Warning: ingredient '" + ingredient + "' is in Critical level");
            } else {
                lblWarningMessage.setText("");
            }

            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void HistoryOfPurchasedItems() {
        txtSoldItemsFilter.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String query = txtSoldItemsFilter.getText().toLowerCase();
                filterSoldItems(query);
            }
        });
    }

    private void filterSoldItems(String query) {
        SoldItemSorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
    }

    public void LoadTblPurchasedItems() {
        try {
            String UsageQuery = "SELECT p.Product_Name, oi.quantity, ps.Product_Size, s.SugarLvl, oi.price " +
                    "FROM product_tb AS p " +
                    "INNER JOIN order_items AS oi ON p.Product_ID = oi.item_id " +
                    "LEFT JOIN sizeandsugar AS ss ON oi.size_sugar_id = ss.size_sugar_id " +
                    "LEFT JOIN sugarlvl AS s ON ss.Sugar_Lvl_ID = s.Sugar_Lvl_ID " +
                    "LEFT JOIN product_size AS ps ON ss.Size_ID = ps.Size_ID";

            PreparedStatement pstUsage = conn.prepareStatement(UsageQuery);
            ResultSet rsIngredient = pstUsage.executeQuery();
            SoldItemTableModel = DbUtils.resultSetToTableModel(rsIngredient);
            tblSoldItems.setModel(SoldItemTableModel);
            SoldItemSorter = new TableRowSorter<>(SoldItemTableModel);
            tblSoldItems.setRowSorter(SoldItemSorter);
            pstUsage.close();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    public void IngredientsStatus() {
        txtIngStatFilter.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String query = txtIngStatFilter.getText().toLowerCase();
                filterIngredientsStatus(query);
            }
        });
    }

    private void filterIngredientsStatus(String query) {
        IngredientStatSorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
    }

    public void LoadTblIngredientsStatus() {
        try {
            String UsageQuery = "SELECT Ingredient, Quantity, Unit FROM ingredients";
            PreparedStatement pstUsage = conn.prepareStatement(UsageQuery);
            ResultSet rsIngredient = pstUsage.executeQuery();
            IngredientStatSorterTableModel = DbUtils.resultSetToTableModel(rsIngredient);
            tblIngredients.setModel(IngredientStatSorterTableModel);
            IngredientStatSorter = new TableRowSorter<>(IngredientStatSorterTableModel);
            tblIngredients.setRowSorter(IngredientStatSorter);
            pstUsage.close();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    public void OrdersHistory() {
        txtOrdersFilter.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String query = txtOrdersFilter.getText().toLowerCase();
                filterOrders(query);
            }
        });
    }

    private void filterOrders(String query) {
        OrderSorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
    }

    public void LoadTblOrders() {
        try {
            String UsageQuery = "SELECT DISTINCT o.order_id, c.customer_name, c.email_or_phone, c.address, o.order_method, o.total_amount, o.order_date " +
                    "FROM product_tb AS p " +
                    "INNER JOIN order_items AS oi ON p.Product_ID = oi.item_id " +
                    "LEFT JOIN orders AS o ON oi.order_id = o.order_id " +
                    "LEFT JOIN customers AS c ON o.customer_id = c.customer_id";
            PreparedStatement pstUsage = conn.prepareStatement(UsageQuery);
            ResultSet rsIngredient = pstUsage.executeQuery();
            OrderTableModel = DbUtils.resultSetToTableModel(rsIngredient);
            tblOrders.setModel(OrderTableModel);
            OrderSorter = new TableRowSorter<>(OrderTableModel);
            tblOrders.setRowSorter(OrderSorter);
            pstUsage.close();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    // new sorter
    public void OrdersSold() {
        txtSoldAndOrders.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String query = txtSoldAndOrders.getText().toLowerCase();
                filterOrdersSold(query);
            }
        });
    }

    private void filterOrdersSold(String query) {
        OrdersSoldSorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
    }

    public void LoadTblOrdersSold() {
        try {
        	String UsageQuery = "SELECT o.order_id, c.customer_name, c.email_or_phone, c.address, p.Product_Name, oi.quantity, ps.Product_Size, s.SugarLvl, o.order_method, o.order_date " +
        	        "FROM product_tb AS p " +
        	        "INNER JOIN order_items AS oi ON p.Product_ID = oi.item_id " +
        	        "LEFT JOIN sizeandsugar AS ss ON oi.size_sugar_id = ss.size_sugar_id " +
        	        "LEFT JOIN sugarlvl AS s ON ss.Sugar_Lvl_ID = s.Sugar_Lvl_ID " +
        	        "LEFT JOIN product_size AS ps ON ss.Size_ID = ps.Size_ID " +
        	        "LEFT JOIN orders AS o ON oi.order_id = o.order_id " +
        	        "LEFT JOIN customers AS c ON o.customer_id = c.customer_id";

            PreparedStatement pstUsage = conn.prepareStatement(UsageQuery);
            ResultSet rsIngredient = pstUsage.executeQuery();
            OrdersSoldTableModel = DbUtils.resultSetToTableModel(rsIngredient);
            tblSoldOrders.setModel(OrdersSoldTableModel); // Fixed: Set the model for tblSoldOrders
            OrdersSoldSorter = new TableRowSorter<>(OrdersSoldTableModel);
            tblSoldOrders.setRowSorter(OrdersSoldSorter);
            pstUsage.close();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }
}

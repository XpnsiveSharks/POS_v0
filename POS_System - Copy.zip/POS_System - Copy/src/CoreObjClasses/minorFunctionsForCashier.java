package CoreObjClasses;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class minorFunctionsForCashier {
    private JPanel paneCashier, paneInventory, paneOverview, paneLogout;

    public minorFunctionsForCashier(JPanel paneCashier, JPanel paneOverview, JPanel paneLogout,
            JPanel paneInventory) {
        this.paneCashier = paneCashier;
        this.paneOverview = paneOverview;
        this.paneLogout = paneLogout;
        this.paneInventory = paneInventory;
    }

    public void menuPanels() {
        paneCashier.addMouseListener(new PanelButtonMouseAdapter(paneCashier) {
            public void mouseClicked(MouseEvent e) {
            }
        });
        paneOverview.addMouseListener(new PanelButtonMouseAdapter(paneOverview) {
            public void mouseClicked(MouseEvent e) {
            }
        });
        paneLogout.addMouseListener(new PanelButtonMouseAdapter(paneLogout) {
            public void mousePressed(MouseEvent e) {
                
            }
        });
        paneInventory.addMouseListener(new PanelButtonMouseAdapter(paneInventory) {
            public void mouseClicked(MouseEvent e) {
            }
        });
    }

    private class PanelButtonMouseAdapter extends MouseAdapter {
        JPanel panel;

        public PanelButtonMouseAdapter(JPanel panel) {
            this.panel = panel;
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            panel.setBackground(new Color(0, 100, 0));
        }

        @Override
        public void mouseExited(MouseEvent e) {
            panel.setBackground(new Color(89, 63, 14));
        }

        @Override
        public void mousePressed(MouseEvent e) {
            panel.setBackground(new Color(145, 234, 182));
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            panel.setBackground(new Color(89, 63, 14));
        }
    }
}

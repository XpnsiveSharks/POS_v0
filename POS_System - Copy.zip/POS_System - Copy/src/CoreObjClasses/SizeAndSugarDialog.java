package CoreObjClasses;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import JDBConnectivity.JdbcConn;
import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JTextField;

import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SizeAndSugarDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JComboBox cbxAddOnsCat, cbxProdCat;
	private JTable tblProdSize, tblSugarLvl, tblOrders;
    Connection conn = JdbcConn.connect();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			SizeAndSugarDialog dialog = new SizeAndSugarDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public SizeAndSugarDialog() {
		 try {
		        // Apply Nimbus look and feel
		        UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
		        e.printStackTrace();
		    }
		Components();
		Events();
	}

	private void Events() {

		TblSizePopulate();
		TblSugarPopulate();
			
			
		{
		    JPanel buttonPane = new JPanel();
		    buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		    getContentPane().add(buttonPane, BorderLayout.SOUTH);

		    JButton okButton = new JButton("OK");
		    okButton.setFont(new Font("SansSerif", Font.BOLD, 12));
		    okButton.setForeground(new Color(255, 255, 255));
		    okButton.setBackground(new Color(59, 41, 6));
		    okButton.setActionCommand("OK");
		    okButton.addActionListener(new ActionListener() {
		        public void actionPerformed(ActionEvent e) {
		            int selectedRowSize = tblProdSize.getSelectedRow();
		            int selectedRowSugar = tblSugarLvl.getSelectedRow();

		            if (selectedRowSize != -1 && selectedRowSugar != -1) {			            			    
		                DefaultTableModel sizeModel = (DefaultTableModel) tblProdSize.getModel();
		                DefaultTableModel sugarModel = (DefaultTableModel) tblSugarLvl.getModel();
		                
		                Object sizeValue = sizeModel.getValueAt(selectedRowSize, 0); // Size_ID
		                Object sugarValue = sugarModel.getValueAt(selectedRowSugar, 0); // Sugar_Lvl_ID

		                try {
		                    Connection conn = JdbcConn.connect();
		                    String sql = "INSERT INTO sizeandsugar (Size_ID, Sugar_Lvl_ID) VALUES (?, ?)";
		                    PreparedStatement pst = conn.prepareStatement(sql);
		                    pst.setString(1, sizeValue.toString()); // Set the Size_ID value
		                    pst.setString(2, sugarValue.toString()); // Set the Sugar_Lvl_ID value
		                    int rowsAffected = pst.executeUpdate(); // Execute the statement to insert the item into the database
		                    pst.close();

		                    if (rowsAffected > 0) {
		    		            dispose(); 

		                    } else {
		                        JOptionPane.showMessageDialog(null, "Failed to add product to order.", "Error", JOptionPane.ERROR_MESSAGE);
		                    }
		                } catch (Exception e1) {
		                    e1.printStackTrace();
		                }
		            } else if (selectedRowSize != -1 || selectedRowSugar != -1) {
		                JOptionPane.showMessageDialog(null, "Please select both Size and Sugar Level.", "Incomplete Selection", JOptionPane.WARNING_MESSAGE);
		            }
		        }
		    });
		    buttonPane.add(okButton);
		    getRootPane().setDefaultButton(okButton);

		    JButton cancelButton = new JButton("Cancel");
		    cancelButton.setFont(new Font("SansSerif", Font.BOLD, 12));
		    cancelButton.setForeground(new Color(255, 255, 255));
		    cancelButton.setBackground(new Color(59, 41, 6));
		    cancelButton.setActionCommand("Cancel");
		    cancelButton.addActionListener(new ActionListener() {
		        public void actionPerformed(ActionEvent e) {
		            Integer sizeValue = null; // Use Integer instead of String for sizeValue
		            Integer sugarValue = null; // Use Integer instead of String for sugarValue

		            try {
		                Connection conn = JdbcConn.connect();
		                String sql = "INSERT INTO sizeandsugar (Size_ID, Sugar_Lvl_ID) VALUES (?, ?)";
		                PreparedStatement pst = conn.prepareStatement(sql);

		                if (sizeValue != null) {
		                    pst.setInt(1, sizeValue); // Set the Size_ID value
		                } else {
		                    pst.setNull(1, java.sql.Types.INTEGER); // Set the Size_ID value as null
		                }

		                if (sugarValue != null) {
		                    pst.setInt(2, sugarValue); // Set the Sugar_Lvl_ID value
		                } else {
		                    pst.setNull(2, java.sql.Types.INTEGER); // Set the Sugar_Lvl_ID value as null
		                }

		                int rowsAffected = pst.executeUpdate(); // Execute the statement to insert the item into the database
		                pst.close();

		                if (rowsAffected > 0) {
		                    dispose();
		                }
		            } catch (Exception e1) {
		                e1.printStackTrace();
		            }
		        }
		    });

		    cancelButton.addActionListener(new ActionListener() {
		        public void actionPerformed(ActionEvent e) {
		           
		            dispose(); 
		        }
		    });
		    buttonPane.add(cancelButton);
		}		
	}

	private void Components() {
		setBounds(100, 100, 650, 400);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(59, 41, 6));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setForeground(new Color(245, 245, 245));
			scrollPane.setBounds(6, 48, 308, 271);
			contentPanel.add(scrollPane);
			{
				tblProdSize = new JTable();
				tblProdSize.setForeground(new Color(255, 255, 255));
				tblProdSize.setSelectionBackground(new Color(0, 100, 0));
				tblProdSize.setBackground(new Color(103, 72, 11));
				scrollPane.setViewportView(tblProdSize);
			}
		}
		{
			JScrollPane scrollPane = new JScrollPane();			
			scrollPane.setBounds(326, 48, 304, 271);
			contentPanel.add(scrollPane);
			{
				tblSugarLvl = new JTable();				
				tblSugarLvl.setForeground(new Color(255, 255, 255));
				tblSugarLvl.setSelectionBackground(new Color(0, 100, 0));
				tblSugarLvl.setBackground(new Color(103, 72, 11));
				scrollPane.setViewportView(tblSugarLvl);
			}
		}
		
		JLabel lblSize = new JLabel("SIZE");
		lblSize.setHorizontalAlignment(SwingConstants.CENTER);
		lblSize.setForeground(Color.WHITE);
		lblSize.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblSize.setBounds(10, 12, 302, 38);
		contentPanel.add(lblSize);
		
		JLabel lblSugarLevel = new JLabel("SUGAR LEVEL");
		lblSugarLevel.setHorizontalAlignment(SwingConstants.CENTER);
		lblSugarLevel.setForeground(Color.WHITE);
		lblSugarLevel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblSugarLevel.setBounds(324, 12, 306, 38);
		contentPanel.add(lblSugarLevel);
	}
	public void TblSizePopulate() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT Size_ID, Product_Size, Size_Price FROM product_size");
    		ResultSet rs = pst.executeQuery();
    		tblProdSize.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
		}
	}
	public void TblSugarPopulate() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT Sugar_Lvl_ID, SugarLvl FROM sugarlvl");
    		ResultSet rs = pst.executeQuery();
    		tblSugarLvl.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
		}
	}
}

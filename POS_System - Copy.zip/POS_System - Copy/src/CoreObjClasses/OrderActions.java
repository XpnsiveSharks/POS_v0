package CoreObjClasses;
/**
* @author: Marynelle
*/
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.table.DefaultTableModel;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;

import JDBConnectivity.JdbcConn;

import Ui.*;

//order Id generator
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;

import java.text.DecimalFormat;



public class OrderActions {
	private JTable tblAddOns, tblProdSize, tblSugarLvl, tblProducts;
	
	private JTextField txtName, txtPhoneemail, txtAddress,txtGenOrderID;
	private JRadioButton rdbtnDine, rdbtnTakeout, rdbtnDelivery;
	private ButtonGroup buttonGroup = new ButtonGroup();
	
	//Order
	private JTable tblOrders;
	private JButton btnPay, btnRemoveItem, btnAddCusInfo, btnPrintReceipt;
	private JTextField txtTotalP, txtChange, txtPayment;
	//generate order ID button
	private JTextField txtGenOrID;
	private JButton btnGenerateOrderID;
	
	private JComboBox cbxAddOnsCat, cbxProdCat;
	
	 private int quantity;
	
	
	public OrderActions(int quantity) {
		
	}
	public OrderActions(JTable tblAddOns, JTable tblProdSize, JTable tblSugarLvl, JTable tblProducts,
			JTextField txtName, JTextField txtPhoneemail, JTextField txtAddress,
			JRadioButton rdbtnDine, JRadioButton rdbtnTakeout, JRadioButton rdbtnDelivery,
			ButtonGroup buttonGroup, JTable tblOrders, JButton btnPay, 
			JButton btnRemoveItem, JTextField txtGenOrID, JButton btnGenerateOrderID, JTextField txtTotalP,
			JTextField txtChange, JTextField txtPayment, JButton btnAddCusInfo, JButton btnPrintReceipt
			) {
		this.tblAddOns = tblAddOns;
		this.tblProdSize = tblProdSize;
		this.tblSugarLvl = tblSugarLvl;
		this.tblProducts = tblProducts;
		//customer
		this.txtName = txtName;
		this.txtPhoneemail = txtPhoneemail;
		this.txtAddress = txtAddress;
		this.txtGenOrderID = txtGenOrderID;
		this.rdbtnDine = rdbtnDine;
		this.rdbtnTakeout = rdbtnTakeout;
		this.rdbtnDelivery = rdbtnDelivery;
		this.buttonGroup = buttonGroup;
		this.btnAddCusInfo = btnAddCusInfo;
		this.btnPrintReceipt = btnPrintReceipt;
		//order 
		this.tblOrders = tblOrders;
		this.btnRemoveItem = btnRemoveItem;
		this.btnPay = btnPay;
		this.txtTotalP = txtTotalP;
		this.txtChange = txtChange;
		this.txtPayment = txtPayment;
		//generate order ID button
		this.txtGenOrID = txtGenOrID;
		this.btnGenerateOrderID = btnGenerateOrderID;
		
		
	}
	private AtomicBoolean isInsertProductToDbExecuted = new AtomicBoolean(false);
	private AtomicBoolean isGenerateOrderIDExecuted = new AtomicBoolean(false);
	private AtomicBoolean isupdateTableOrdersExecuted = new AtomicBoolean(false);
	private AtomicBoolean isordersExecuted = new AtomicBoolean(false);
//	private AtomicBoolean isPrintReceiptExecuted = new AtomicBoolean (false);


	public void InsertProductToDb() {
	    tblProducts.addMouseListener(new MouseAdapter() {
	        @Override
	        public void mouseClicked(MouseEvent e) {
	        	//Boolean check
		    	if (!isGenerateOrderIDExecuted.get()) {
	                JOptionPane.showMessageDialog(null, "Please generate Order ID first.");
	                return;
	            }
	            int selectedRow = tblProducts.getSelectedRow();	            
	            if (selectedRow != -1) {	            	
	            	ItemQuantity();
	                int value = quantity;
	                InsertSugarAndSize();

	                // Retrieve the last inserted size_sugar_id from the sizeandsugar table
	                int sizeSugar = -1;
	                try {
	                    Connection conn = JdbcConn.connect();
	                    String lastInsertedIdQuery = "SELECT size_sugar_id FROM sizeandsugar ORDER BY size_sugar_id DESC LIMIT 1";
	                    Statement statement = conn.createStatement();
	                    ResultSet resultSet = statement.executeQuery(lastInsertedIdQuery);
	                    if (resultSet.next()) {
	                        sizeSugar = resultSet.getInt("size_sugar_id");
	                    }
	                    statement.close();
	                    resultSet.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
	                // Order ID generator
	                String Oi = null;
	                try {
	                    Connection conn = JdbcConn.connect();
	                    String lastInsertedIdQuery = "SELECT order_id FROM orders ORDER BY order_id DESC LIMIT 1";
	                    Statement statement = conn.createStatement();
	                    ResultSet resultSet = statement.executeQuery(lastInsertedIdQuery);
	                    if (resultSet.next()) {
	                        String orderId = resultSet.getString("order_id");
	                        // Extract the numeric portion of the order ID
	                        String numericId = orderId.substring(1); // Assuming the order ID format is "O000003"
	                        int numericValue = Integer.parseInt(numericId);
	                        Oi = String.format("O%06d", numericValue);
	                    }
	                    statement.close();
	                    resultSet.close();
	                    conn.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }

	                // tblProducts assigned variables
	                DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
	                Object selectedValue = model.getValueAt(selectedRow, 0);
	                Object selectedValue2 = model.getValueAt(selectedRow, 2);

	                try {
	                    Connection conn = JdbcConn.connect();
	                    String sql = "INSERT INTO order_items (order_id, item_id, item_type, size_sugar_id, quantity, price) VALUES (?, ?, ?, ?, ?, ?)";
	                    PreparedStatement pst = conn.prepareStatement(sql);
	                    pst.setString(1, Oi);
	                    pst.setString(2, selectedValue.toString());
	                    pst.setString(3, "Product");
	                    pst.setInt(4, sizeSugar);
	                    pst.setInt(5, value);
	                    double itemAmount = Double.parseDouble(selectedValue2.toString()) * value;
	                    pst.setBigDecimal(6, BigDecimal.valueOf(itemAmount));
	                    int rowsAffected = pst.executeUpdate();
	                    pst.close();
	                    updateTableOrders();
	                    if (rowsAffected > 0) {
	                        JOptionPane.showMessageDialog(null, "Items added to order.", "Success", JOptionPane.INFORMATION_MESSAGE);
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Failed to add product to order.", "Error", JOptionPane.ERROR_MESSAGE);
	                    }
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
	            }
	            isInsertProductToDbExecuted.set(true); 

	        }
	    });
	}
//********************************************item quantity*******************************************//

	 public void ItemQuantity() {
	        String qty;
	        while (true) {
	            qty = JOptionPane.showInputDialog(null, "Enter quantity:");
	            if (qty == null || qty.isEmpty()) {
	                return;
	            }
	            try {
	                quantity = Integer.parseInt(qty);
	                if (quantity > 0) {
	                    break;
	                } else {
	                    JOptionPane.showMessageDialog(null, "Please enter a positive integer.");
	                }
	            } catch (NumberFormatException ex) {
	                JOptionPane.showMessageDialog(null, "Please enter a valid integer.");
	            }
	        }
	    }

//**************************************Insseert addons to order**************************************//
	public void InsertAddOnsToProduct() {
		tblAddOns.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		    	//Boolean check
		    	if (!isInsertProductToDbExecuted.get()) {
	                JOptionPane.showMessageDialog(null, "Please add a product to the order first.");
	                return;
	            }
		        int selectedRow = tblAddOns.getSelectedRow();
		        if (selectedRow != -1) {
		            DefaultTableModel model = (DefaultTableModel) tblAddOns.getModel();
		            Object selectedValue = model.getValueAt(selectedRow, 0);
		            Object selectedValue2 = model.getValueAt(selectedRow, 1);
		            Object selectedValue3 = model.getValueAt(selectedRow, 2);
		            //Insert Order Id from orders
		            String OiFAo = null;
	                try {
	                    Connection conn = JdbcConn.connect();
	                    String lastInsertedIdQuery = "SELECT order_id FROM orders ORDER BY order_id DESC LIMIT 1";
	                    Statement statement = conn.createStatement();
	                    ResultSet resultSet = statement.executeQuery(lastInsertedIdQuery);
	                    if (resultSet.next()) {
	                        String orderId = resultSet.getString("order_id");
	                        // Extract the numeric portion of the order ID
	                        String numericId = orderId.substring(1);
	                        int numericValue = Integer.parseInt(numericId);
	                        OiFAo = String.format("O%06d", numericValue);
	                    }
	                    statement.close();
	                    resultSet.close();
	                    conn.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }

		            try {
		                Connection conn = JdbcConn.connect();
		                String sql = "INSERT INTO order_items (order_id, item_id, item_type, quantity, price) VALUES (?, ?, ?, ?, ?) " +
		                             "ON DUPLICATE KEY UPDATE quantity = quantity + 1"; // Increment quantity by 1 if duplicate key exists
		                PreparedStatement pst = conn.prepareStatement(sql);
		                pst.setString(1, OiFAo);
		                pst.setString(2, selectedValue.toString());
		                pst.setString(3, "Addon");
		                pst.setInt(4, 1); 
		                pst.setString(5, selectedValue3.toString()); 
		                int rowsAffected = pst.executeUpdate();
		                pst.close();
		                updateTableOrders();
    	                ItemsTotalDisplayInTextField();
		                if (rowsAffected > 0) {
		                    JOptionPane.showMessageDialog(null, "added succesfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
		                } else {
		                    JOptionPane.showMessageDialog(null, "Failed to add product to order.", "Error", JOptionPane.ERROR_MESSAGE);
		                }
		            } catch (Exception e1) {
		                e1.printStackTrace();
		            }
		        }

		    }
		});
	}
//******************************************Insert product size in order********************************//
	public void InsertSugarAndSize() {   
//	        CashierUi parentFrame = new CashierUi(); 
	        SizeAndSugarDialog dialog = new SizeAndSugarDialog();
	        dialog.setModal(true);
	        dialog.setVisible(true);     
	}
//******************************************insert customers Info********************************//
	public void insertUserInfo() {
	    String nm = txtName.getText();
	    String pE = txtPhoneemail.getText();
	    String add = txtAddress.getText();
	    if (nm.isEmpty()) {
	        JOptionPane.showMessageDialog(null, "Please fill in all the fields.");
	        return;
	    }
	    try {
	        Connection conn = JdbcConn.connect();	       
	        String insertQuery = "INSERT INTO customers (customer_name, email_or_phone, address) VALUES (?, ?, ?)";
	        PreparedStatement insertPst = conn.prepareStatement(insertQuery);
	        insertPst.setString(1, nm);
	        insertPst.setString(2, pE);
	        insertPst.setString(3, add);
	        insertPst.executeUpdate();
	        insertPst.close();

	        String countQuery = "SELECT COUNT(*) AS order_count FROM orders WHERE customer_id IN (SELECT customer_id FROM customers WHERE email_or_phone = ? AND email_or_phone IS NOT NULL)";
	        PreparedStatement countPst = conn.prepareStatement(countQuery);
	        countPst.setString(1, pE);
	        ResultSet countResult = countPst.executeQuery();

	        if (countResult.next()) {
	            int orderCount = countResult.getInt("order_count");
	            orderCount++;
	            JOptionPane.showMessageDialog(null, "number of orders: " + orderCount);
	        }
	        conn.close();
	        countResult.close();
	        countPst.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}


//******************************************Order ID Generator******************************************//
	public static class OrderIdGenerator {
		 public static String generateOrderId() {
		        String orderIdFormat = "O%06d";
		        int orderId = getNextOrderId();
		        return String.format(orderIdFormat, orderId);
		    }
	
		    private static int getNextOrderId() {
		        try {
		            Connection conn = JdbcConn.connect();
		            String query = "SELECT MAX(CAST(SUBSTRING(order_id, 2) AS UNSIGNED)) AS max_id FROM orders";
		            Statement statement = conn.createStatement();
		            ResultSet resultSet = statement.executeQuery(query);
		            if (resultSet.next()) {
		                int maxId = resultSet.getInt("max_id");
		                return maxId + 1;
		            }
		            statement.close();
		            resultSet.close();
		            conn.close();
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		        // Default starting value if no existing orders
		        return 1;
		    }
		}
	public void GenerateOrderID() {
		btnGenerateOrderID.addMouseListener(new MouseAdapter() {
			@Override
	         public void mouseClicked(MouseEvent e) {
				
				//----------------------------------------------------
	            String orderId = OrderIdGenerator.generateOrderId();
	            txtGenOrID.setText(orderId);
	            try {
	            	Connection conn = JdbcConn.connect();
                    String sql = "INSERT INTO orders (order_id) VALUES (?)";
                    PreparedStatement pst = conn.prepareStatement(sql);
                    pst.setString(1, orderId);    	    	
                    pst.executeUpdate(); 
    	            JOptionPane.showMessageDialog(null, "Order ID Generated Successfully!.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    pst.close();
                  
                    conn.close();
	            }
	            catch(Exception e3) {
	            	e3.printStackTrace();
	            }
	            isGenerateOrderIDExecuted.set(true);		            
			}
		});
	}

//******************************************Payment******************************************//
		public void PayButton() {
		    btnPay.addMouseListener(new MouseAdapter() {
		        @Override
		        public void mouseClicked(MouseEvent e) {	        	
		           
		        	if(txtPayment.getText().equals("")) {
	    	            JOptionPane.showMessageDialog(null, "Please fill the payment field first!.", "WARNING", JOptionPane.WARNING_MESSAGE);
	    	            return;
		        	}
		            double total = 0.00;
		            double change = 0.00;
		            double payment = 0.00;

		            try {
		                payment = Double.parseDouble(txtPayment.getText());
		                total = Double.parseDouble(txtTotalP.getText());

		                change = payment - total;

		                txtChange.setText(String.format("%.2f", change));
		            } catch (NumberFormatException ex) {
		                ex.printStackTrace();
		            }
		            
		            
		            txtGenOrID.setText(null); 
		            DefaultTableModel addOnsModel = (DefaultTableModel) tblAddOns.getModel();
		            addOnsModel.setRowCount(0);
		            DefaultTableModel productsModel = (DefaultTableModel) tblProducts.getModel();
		            productsModel.setRowCount(0);		       
		            
		            isGenerateOrderIDExecuted.set(false);
		            isInsertProductToDbExecuted.set(false);
		        }
		    });
		}

//***********************************Insert Orders to table orders***********************************//
	public void updateTableOrders() {
	    try {
	        String specificOrderId = null;
	        Connection conn = JdbcConn.connect();
	        String lastInsertedIdQuery = "SELECT order_id FROM orders ORDER BY order_id DESC LIMIT 1";
	        Statement statement = conn.createStatement();
	        ResultSet resultSet = statement.executeQuery(lastInsertedIdQuery);
	        if (resultSet.next()) {
	            String orderId = resultSet.getString("order_id");
	            String numericId = orderId.substring(1);
	            int numericValue = Integer.parseInt(numericId);
	            specificOrderId = String.format("O%06d", numericValue);
	        }
	        String query = "SELECT oi.order_item_id, p.Product_Name, oi.quantity, s.SugarLvl, ps.Product_Size, oi.size_fee, oi.price " +
	                "FROM product_tb AS p " +
	                "INNER JOIN order_items AS oi ON p.Product_ID = oi.item_id " +
	                "LEFT JOIN sizeandsugar AS ss ON oi.size_sugar_id = ss.size_sugar_id " +
	                "LEFT JOIN sugarlvl AS s ON ss.Sugar_Lvl_ID = s.Sugar_Lvl_ID " +
	                "LEFT JOIN product_size AS ps ON ss.Size_ID = ps.Size_ID " +
	                "WHERE oi.order_id = ?";

            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, specificOrderId);

                try (ResultSet rs = stmt.executeQuery()) {
                	DefaultTableModel model = (DefaultTableModel) tblOrders.getModel();
    				model.setRowCount(0);
                	while (rs.next()) {
    					Object[] row = new Object[7];
                        row[0] = rs.getString("order_item_id");
                        row[1] = rs.getString("Product_Name");
                        row[2] = rs.getInt("quantity");
                        row[3] = rs.getString("SugarLvl");
                        row[4] = rs.getString("Product_Size");
                        row[5] = rs.getDouble("size_fee");
                        row[6] = rs.getDouble("price");
    					model.addRow(row);

                    }
	                ItemsTotalDisplayInTextField();
		            isupdateTableOrdersExecuted.set(true);

                }
            }	        
	    }catch (Exception e) {
	        e.printStackTrace();
	    }
	}
//**********************************Remove Items from order table*************************************//
	public void RemoveItemFromTableOrders() {
		btnRemoveItem.addMouseListener(new MouseAdapter() {
    	    @Override
    	    public void mouseClicked(MouseEvent e) {
    	        DefaultTableModel d1 = (DefaultTableModel) tblOrders.getModel();
    	        int selectedIndex = tblOrders.getSelectedRow();

    	        if (selectedIndex == -1) {
    	            // No row selected, display message dialog
    	            JOptionPane.showMessageDialog(null, "Please select a row to delete.");
    	            return;
    	        }

    	        String idString = d1.getValueAt(selectedIndex, 0).toString();
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to remove this item", "Warning", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
    	            try {
    	                Connection conn = JdbcConn.connect();
    	                String query = "DELETE FROM order_items WHERE order_item_id = ?";
    	                PreparedStatement pst = conn.prepareStatement(query);
    	                pst.setString(1, idString);
    	                pst.executeUpdate();    	           
    	                JOptionPane.showMessageDialog(null, "Item Removed.");
    	                updateTableOrders();
    	                ItemsTotalDisplayInTextField();
    	            } catch (Exception r) {
    	                r.printStackTrace();
    	            }
    	        }
    	    }
    	});
	}
//************************************Display total price**************************************//
	public void ItemsTotalDisplayInTextField() {
	    if (tblOrders != null && tblOrders.getColumnCount() >= 6) {
	        double Psum = 0.00;
	        double Asum = 0.00;

	        for (int i = 0; i < tblOrders.getRowCount(); i++) {
	            Object priceValue = tblOrders.getValueAt(i, 5);
	            if (priceValue != null && !priceValue.toString().equals("")) {
	                try {
	                    double price = Double.parseDouble(priceValue.toString());
	                    Psum += price;
	                } catch (NumberFormatException e) {
	                    e.printStackTrace();
	                }
	            }
	        }	       
	        for (int i = 0; i < tblOrders.getRowCount(); i++) {
	            Object priceValue = tblOrders.getValueAt(i, 6);
	            if (priceValue != null && !priceValue.toString().equals("")) {
	                try {
	                    double price = Double.parseDouble(priceValue.toString());
	                    Asum += price;
	                } catch (NumberFormatException e) {
	                    e.printStackTrace();
	                }
	            }
	        }

	        double totalSum = Psum + Asum;
	        txtTotalP.setText(Double.toString(totalSum));
	    }
	}
//******************************************Orders**********************************************//
	public void orders() {
		btnAddCusInfo.addMouseListener(new MouseAdapter() {
			@Override
    	    public void mouseClicked(MouseEvent e) {
				if (!isupdateTableOrdersExecuted.get()) {
	                JOptionPane.showMessageDialog(null, "get the order first.");
	                return;
	            }
				 // Check if an order method is selected
	            String orderMethod = null;
	            if (rdbtnDine.isSelected()) {
	                orderMethod = "Dine-In";
	            } else if (rdbtnTakeout.isSelected()) {
	                orderMethod = "Take-Out";
	            } else if (rdbtnDelivery.isSelected()) {
	                orderMethod = "Delivery";
	            }

	            if (orderMethod == null) {
	                JOptionPane.showMessageDialog(null, "Please select an order method.");
	                return;
	            }

				
				insertUserInfo(); 	
				 Connection conn = null;
				    PreparedStatement pst = null;

				    try {
				        conn = JdbcConn.connect();
				        String specificOrderId = null;
				        int lastCusId = 0;
				        String totalAmount = txtTotalP.getText();

				        String OiFAo = null;
				        String lastInsertedIdQuery = "SELECT order_id FROM orders ORDER BY order_id DESC LIMIT 1";

				        Statement statement = conn.createStatement();
				        ResultSet resultSet = statement.executeQuery(lastInsertedIdQuery);

				        if (resultSet.next()) {
				            String orderId = resultSet.getString("order_id");
				            String numericId = orderId.substring(1); 
				            int numericValue = Integer.parseInt(numericId);
				            specificOrderId = String.format("O%06d", numericValue);
				        }

				        resultSet.close();
				        statement.close();

				        // Retrieve the last inserted customer ID
				        String lastInsertedCustomerIdQuery = "SELECT customer_id FROM customers ORDER BY customer_id DESC LIMIT 1";
				        statement = conn.createStatement();
				        resultSet = statement.executeQuery(lastInsertedCustomerIdQuery);

				        if (resultSet.next()) {
				            lastCusId = resultSet.getInt("customer_id");
				        } else {
				            // No existing customer ID found, handle this case
				            JOptionPane.showMessageDialog(null, "No existing customer ID found.");
				            return;
				        }

				        resultSet.close();
				        statement.close();

				        if (rdbtnDine.isSelected()) {
				            orderMethod = "Dine-In";
				        } else if (rdbtnTakeout.isSelected()) {
				            orderMethod = "Take-Out";
				        } else if (rdbtnDelivery.isSelected()) {
				            orderMethod = "Delivery";
				        }

				        String updateQuery = "UPDATE orders SET customer_id = ?, order_method = ?, total_amount = ? WHERE order_id = ?";
				        pst = conn.prepareStatement(updateQuery);
				        pst.setInt(1, lastCusId);
				        pst.setString(2, orderMethod);
				        pst.setString(3, totalAmount);
				        pst.setString(4, specificOrderId);

				        pst.executeUpdate();

//				        JOptionPane.showMessageDialog(null, "Successfully updated.");
				    } catch (SQLException ex) {
				        ex.printStackTrace();
				        JOptionPane.showMessageDialog(null, "An error occurred while updating the order.");
				    } finally {
				        try {
				            if (pst != null) {
				                pst.close();
				            }
				            if (conn != null) {
				                conn.close();
				            }
				        } catch (SQLException e1) {
				            e1.printStackTrace();
				        }
				    }
		           
		            isupdateTableOrdersExecuted.set(false);
		            isordersExecuted.set(true);
		            
		            txtName.setText(null);
		            txtPhoneemail.setText(null);
		            txtAddress.setText(null);
		            buttonGroup.clearSelection();
			}
			
		});
	   
	}
	public void printReceipt() {
	    btnPrintReceipt.addMouseListener(new MouseAdapter() {
	        public void mouseClicked(MouseEvent e) {
	            PrintReceipt();
	            txtTotalP.setText(null);
	            txtChange.setText(null);
	            txtPayment.setText(null);

	            DefaultTableModel tblOrdersModel = (DefaultTableModel) tblOrders.getModel();
	            tblOrdersModel.setRowCount(0);
	        }
	        
	    });
	}
	public void PrintReceipt() {   
        Print dialog1 = new Print();
        dialog1.setModal(true);
        dialog1.setVisible(true);     
	}
}
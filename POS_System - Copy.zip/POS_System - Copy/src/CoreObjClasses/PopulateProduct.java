package CoreObjClasses;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import JDBConnectivity.JdbcConn;
import net.proteanit.sql.DbUtils;

public class PopulateProduct {
	private JComboBox cbxProdCategory, cbxAddOnsCat;
	private JTable tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl;
	
    Connection conn = JdbcConn.connect();

	public PopulateProduct(JComboBox cbxProdCategory, JTable tblProducts, JTable tblProdCategory,
			JTable tblAddOns, JTable tblSize, JTable tblSugarLvl, JComboBox cbxAddOnsCat) {
		this.cbxProdCategory = cbxProdCategory;
		this.tblProducts = tblProducts;
		this.tblProdCategory = tblProdCategory;
		this.tblAddOns = tblAddOns;
		this.tblSize = tblSize;
		this.tblSugarLvl = tblSugarLvl;
		this.cbxAddOnsCat = cbxAddOnsCat;
	}
//********************************Populate ComboBox Product Category********************************//
	public void CbxProdCategoryPopulate() {
	    try {
	        Statement stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT DISTINCT Category FROM category");
	        cbxProdCategory.removeAllItems();
	        cbxProdCategory.addItem("");

	        while (rs.next()) {
	        	cbxProdCategory.addItem(rs.getString("Category"));
	        }
	        rs.close();
	        stmt.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to populate combo box category: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);      

	    }
	}
//********************************Populate Table Products********************************//
	public void TblProductPopulate() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT * FROM product_tb WHERE Product_ID LIKE 'P%'");
            ResultSet rs = pst.executeQuery();
            tblProducts.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to populate table product: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);      

	    }
	}
//********************************Populate Table Product Category********************************//
	public void TblProdCatPopulate() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT * FROM category");
    		ResultSet rs = pst.executeQuery();
    		tblProdCategory.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
		}
	}
//********************************Populate Table Add-Ons********************************//
	public void TblAddOnsPopulate() {
	    try {
	        PreparedStatement pst = conn.prepareStatement("SELECT Product_ID, Category, Product_Name, Price FROM product_tb WHERE Product_ID LIKE 'A%'");
	        ResultSet rs = pst.executeQuery();
	        tblAddOns.setModel(DbUtils.resultSetToTableModel(rs));
	        pst.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	public void PopulateCbxAddOns() {
		try {
	        Statement stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT DISTINCT Category FROM category");
	        cbxAddOnsCat.removeAllItems();
	        cbxAddOnsCat.addItem("");

	        while (rs.next()) {
	        	cbxAddOnsCat.addItem(rs.getString("Category"));
	        }
	        rs.close();
	        stmt.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
//********************************Populate Table Product Size********************************//
	public void TblProdSizePopulate() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT * FROM product_size");
    		ResultSet rs = pst.executeQuery();
    		tblSize.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
		}
	}
	public void TblSugarLvlPopulate() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT * FROM sugarlvl");
    		ResultSet rs = pst.executeQuery();
    		tblSugarLvl.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
		}
	}
}

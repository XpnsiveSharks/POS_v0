package CoreObjClasses;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import JDBConnectivity.JdbcConn;
import Ui.ImageTableCellRenderer;
import net.proteanit.sql.DbUtils;

public class ActionCashier {
	private JLabel LblAddOnsSearch;
	private JComboBox cbxAddOnsCat;
	private JTable tblAddOns;
	private JComboBox cbxProdCat;
	private JTable tblProducts;
	private JLabel lblSearchProducts;
	private JTextField txtSearchProID;
	private JLabel lblSearchProID;


	
	public ActionCashier(JLabel LblAddOnsSearch, JComboBox cbxAddOnsCat, JTable tblAddOns, JComboBox cbxProdCat,
			JTable tblProducts, JLabel lblSearchProducts, JTextField txtSearchProID, JLabel lblSearchProID) {
		this.LblAddOnsSearch = LblAddOnsSearch;
		this.cbxAddOnsCat = cbxAddOnsCat;
		this.tblAddOns = tblAddOns;
		this.cbxProdCat = cbxProdCat;
		this.tblProducts = tblProducts;
		this.lblSearchProducts = lblSearchProducts;
		this.txtSearchProID = txtSearchProID;
		this.lblSearchProID = lblSearchProID;
	}
//*************************************add-ons**************************************//
	public void AddOnsActions() {
		
		LblAddOnsSearch.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        String searchCatgry = (String) cbxAddOnsCat.getSelectedItem();
		        if (searchCatgry == "") {
		            JOptionPane.showMessageDialog(null, "Please select a category.", "Category Not Selected", JOptionPane.WARNING_MESSAGE);
		            return;  
		        }
		        try {
		            Connection conn = JdbcConn.connect();
		            String sql = "SELECT * FROM product_tb WHERE Category LIKE ? AND Product_ID LIKE 'A%'";
		            PreparedStatement stmt = conn.prepareStatement(sql);
		            stmt.setString(1, "%" + searchCatgry + "%");
		            ResultSet rs = stmt.executeQuery();
		            DefaultTableModel model = (DefaultTableModel) tblAddOns.getModel();
		            model.setRowCount(0);
		            boolean hasResults = false;
		            while (rs.next()) {
		                hasResults = true;
		                Object[] row = new Object[3];
		                row[0] = rs.getString("Product_ID");
		                row[1] = rs.getString("Product_Name");
		                row[2] = rs.getString("Price");
		                model.addRow(row);
		            }
		            rs.close();
		            stmt.close();
		            conn.close();

		            if (!hasResults) {
		                JOptionPane.showMessageDialog(null, "No matching products found.", "No Results", JOptionPane.INFORMATION_MESSAGE);
		            }
		        } catch (Exception e1) {
		            e1.printStackTrace();
		        }
		        cbxAddOnsCat.setSelectedIndex(0);
		    }
		});

	}
//******************************************Product**************************************//
	public void ActionCbxSearchProdCat() {
		lblSearchProducts.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            String searchCatgry = (String) cbxProdCat.getSelectedItem();
            if (searchCatgry == "") {
                JOptionPane.showMessageDialog(null, "Please select a category.", "Category Not Selected", JOptionPane.WARNING_MESSAGE);
                return;  
            }
            try {
	            Connection conn = JdbcConn.connect();
                String sql = "SELECT * FROM product_tb WHERE Category LIKE ? AND Product_ID LIKE 'P%'";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1,searchCatgry);
                ResultSet rs = stmt.executeQuery();
                DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
                model.setRowCount(0);
                boolean hasResults = false;
                while (rs.next()) {
                    hasResults = true;
                    Object[] row = new Object[5];
                    row[0] = rs.getString("Product_ID");
                    row[1] = rs.getString("Product_Name");
                    row[2] = rs.getString("Price");
                    row[3] = rs.getString("Description");
                    byte[] imageData = rs.getBytes("Image");
                    if (imageData != null) {
                        ImageIcon icon = new ImageIcon(imageData);
                        row[4] = icon;
                    } else {
                        row[4] = null;
                    }
                    model.addRow(row);
                }
                tblProducts.setModel(model);
                tblProducts.getColumnModel().getColumn(4).setCellRenderer(new ImageTableCellRenderer(100, 100));
                TableColumnModel columnModel = tblProducts.getColumnModel();
                columnModel.getColumn(4).setPreferredWidth(100);
                tblProducts.setRowHeight(100);

                rs.close();
                stmt.close();
                conn.close();

                if (!hasResults) {
                    JOptionPane.showMessageDialog(null, "No matching products found.", "No Results", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            cbxProdCat.setSelectedIndex(0);
            
        }
    });	
//******************************************Add-ons**************************************//
		lblSearchProID.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        String searchProdId = txtSearchProID.getText();
		        if (!searchProdId.matches("P\\d{6}")) {
		            JOptionPane.showMessageDialog(null, "Invalid Product ID format. Please use the format with the letter 'P' followed by six digits. Example: 'P000000'", "Invalid Input", JOptionPane.ERROR_MESSAGE);
		            return;
		        }
		        try {
		            Connection conn = JdbcConn.connect();
		            String sql = "SELECT * FROM product_tb WHERE Product_ID = ?";
		            PreparedStatement stmt = conn.prepareStatement(sql);
		            stmt.setString(1, searchProdId);
		            ResultSet rs = stmt.executeQuery();
		            DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
		            model.setRowCount(0);
		            boolean hasResults = false;
		            while (rs.next()) {
		                hasResults = true;
		                Object[] row = new Object[5];
		                row[0] = rs.getString("Product_ID");
		                row[1] = rs.getString("Product_Name");
		                row[2] = rs.getString("Price");
		                row[3] = rs.getString("Description");
		                byte[] imageData = rs.getBytes("Image");
		                if (imageData != null) {
		                    ImageIcon icon = new ImageIcon(imageData);
		                    row[4] = icon;
		                } else {
		                    row[4] = null;
		                }
		                model.addRow(row);
		            }
		            tblProducts.setModel(model);
		            tblProducts.getColumnModel().getColumn(4).setCellRenderer(new ImageTableCellRenderer(100, 100));
		            TableColumnModel columnModel = tblProducts.getColumnModel();
		            columnModel.getColumn(4).setPreferredWidth(100);
		            tblProducts.setRowHeight(100);

		            rs.close();
		            stmt.close();
		            conn.close();

		            if (!hasResults) {
		                JOptionPane.showMessageDialog(null, "No matching product found.", "No Results", JOptionPane.INFORMATION_MESSAGE);
		            }
		        } catch (Exception e1) {
		            e1.printStackTrace();
		        }
		    }
		});
		
	}
}
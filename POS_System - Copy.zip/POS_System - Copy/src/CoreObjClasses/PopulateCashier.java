package CoreObjClasses;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JTable;

import JDBConnectivity.JdbcConn;
import net.proteanit.sql.DbUtils;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

public class PopulateCashier {
	private JComboBox cbxAddOnsCat, cbxProdCat;
	private JTable tblProdSize, tblSugarLvl, tblOrders;
	
    Connection conn = JdbcConn.connect();

	public PopulateCashier(JComboBox cbxAddOnsCat, JTable tblProdSize, JTable tblSugarLvl, JComboBox cbxProdCat, JTable tblOrders) {
		this.cbxAddOnsCat = cbxAddOnsCat;
		this.tblProdSize = tblProdSize;
		this.tblSugarLvl = tblSugarLvl;
		this.cbxProdCat = cbxProdCat;
		this.tblOrders = tblOrders;
	}
	public void PopulateCbxAddOns() {
		
		try {
	        Statement stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT DISTINCT Category FROM product_tb WHERE Product_ID LIKE '%A%'");
	        cbxAddOnsCat.removeAllItems();
	        cbxAddOnsCat.addItem("");

	        while (rs.next()) {
	        	cbxAddOnsCat.addItem(rs.getString("Category"));
	        }
	        rs.close();
	        stmt.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	public void TblProdSizePopulate() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT * FROM product_size");
    		ResultSet rs = pst.executeQuery();
    		tblProdSize.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
		}
	}
	public void TblSugarLvlPopulate() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT * FROM sugarlvl");
    		ResultSet rs = pst.executeQuery();
    		tblSugarLvl.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
		}
	}
	public void PopulateCbxProdCat() {
		try {
	        Statement stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT DISTINCT Category FROM product_tb WHERE Product_ID LIKE '%P%'");

	        cbxProdCat.removeAllItems();
	        cbxProdCat.addItem("");

	        while (rs.next()) {
	        	cbxProdCat.addItem(rs.getString("Category"));
	        }
	        rs.close();
	        stmt.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
//******************************************8***populate table orders*************************************************//
	public void displayOrders() {
		try {
    		PreparedStatement pst = conn.prepareStatement("SELECT oi.order_item_id, p.Product_Name, oi.quantity, s.SugarLvl, ps.Product_Size, ps.Price, oi.price " +
                    "FROM product_tb AS p " +
                    "INNER JOIN order_items AS oi ON p.Product_ID = oi.item_id " +
                    "LEFT JOIN sizeandsugar AS ss ON oi.size_sugar_id = ss.size_sugar_id " +
                    "LEFT JOIN sugarlvl AS s ON ss.Sugar_Lvl_ID = s.Sugar_Lvl_ID " +
                    "LEFT JOIN product_size AS ps ON ss.Size_ID = ps.Size_ID");
    		ResultSet rs = pst.executeQuery();
    		tblOrders.setModel(DbUtils.resultSetToTableModel(rs));
            pst.close();
		} catch (SQLException e) {
	        e.printStackTrace();
		}
	}
}


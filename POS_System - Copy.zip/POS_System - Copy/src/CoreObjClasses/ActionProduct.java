package CoreObjClasses;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.atomic.AtomicInteger;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import CoreObjClasses.OrderActions.OrderIdGenerator;
import JDBConnectivity.JdbcConn;

public class ActionProduct {
	
	//variable declarations for product functions
	private JLabel lblImg;
	private JComboBox cbxProdCategory;
	private JButton btnChooseImg, btnAdd, btnUpdate, btnDelete;
	private JTextField txtProductName, txtProductId, txtPrice, txtDescription;
	private JTable tblProducts;
	//variable declarations for ProdCatActions functions
	private JTable tblProdCategory;
	private JTextField txtCategoryId, txtProductCategory;
	private JButton btnAddCategory, btnDeleteCategory, btnUpdateCategory;
	//variable declarations for Add-Ons
	private JTable tblAddOns;
	private JComboBox cbxAddOnsCat;
	private JTextField txtAddOnsID, txtAddOns, txtAddOnsPrice;
	private JButton btnInsertAddOns, btnUpdateAddOns, btnDeleteAddOns;
	//variable declarations for Product Size
	private JTable tblSize;
	private JTextField txtSize, txtSizePrice, txtSizePercentageAdded;
	private JButton btnAddSize, btnUpdateSize, btnDeleteSize;
	//variable declarations for Sugar Level
	private JTable tblSugarLvl;
	private JTextField txtSugarLevel, txtSugarQty;
	private JButton btnAddSL, btnUpdateSL, btnDeleteSL;
	//variable declarations for Auto generated IDs
	private JLabel LblgenCat, LblGenAO, LblGenProd;
/*this code code is a constructor for a class ActionProduct. The constructor takes numerous parameters representing various GUI 
 *components such as labels, combo boxes, buttons, text fields, and tables.
 */
	public ActionProduct(JLabel lblImg, JComboBox cbxProdCategory, JButton btnChooseImg, JTextField txtProductName,
			JTextField txtProductId, JTextField txtPrice, JTextField txtDescription, JButton btnAdd, JButton btnUpdate,
			JButton btnDelete, JTable tblProducts, JTextField txtCategoryId,JTextField txtProductCategory,
			JButton btnAddCategory, JTable tblProdCategory, JButton btnDeleteCategory, JButton btnUpdateCategory,
			JTable tblAddOns, JTextField txtAddOnsID, JTextField txtAddOns, JTextField txtAddOnsPrice,
			JButton btnInsertAddOns, JButton btnUpdateAddOns, JButton btnDeleteAddOns, JTable tblSize, JTextField txtSize, 
			JTextField txtSizePrice, JButton btnAddSize, JButton btnUpdateSize, JButton btnDeleteSize, JTable tblSugarLvl, 
			JTextField txtSugarLevel, JButton btnAddSL, JButton btnUpdateSL, JButton btnDeleteSL, JComboBox cbxAddOnsCat,
			JLabel LblgenCat, JLabel LblGenAO, JLabel LblGenProd, JTextField txtSizePercentageAdded, JTextField txtSugarQty) {
		//instance variables
		this.lblImg = lblImg;
		this.cbxProdCategory = cbxProdCategory;
		this.btnChooseImg = btnChooseImg;
		this.txtProductName = txtProductName;
		this.txtProductId = txtProductId;
		this.txtPrice = txtPrice;
		this.txtDescription = txtDescription;
		this.btnAdd = btnAdd;
		this.btnUpdate = btnUpdate;
		this.btnDelete = btnDelete;
		this.tblProducts = tblProducts;
		//Product Category Instance variables
		this.txtCategoryId = txtCategoryId;
		this.txtProductCategory = txtProductCategory;
		this.btnAddCategory = btnAddCategory;
		this.tblProdCategory = tblProdCategory;
		this.btnDeleteCategory = btnDeleteCategory;
		this.btnUpdateCategory = btnUpdateCategory;
		//Add-Ons Instance variables
		this.tblAddOns = tblAddOns;
		this.cbxAddOnsCat = cbxAddOnsCat;
		this.txtAddOnsID = txtAddOnsID;
		this.txtAddOns = txtAddOns;
		this.txtAddOnsPrice = txtAddOnsPrice;
		this.btnInsertAddOns = btnInsertAddOns;
		this.btnUpdateAddOns = btnUpdateAddOns;
		this.btnDeleteAddOns = btnDeleteAddOns;
		//Size Instance variables
		this.tblSize = tblSize;
		this.txtSize = txtSize;
		this.txtSizePrice = txtSizePrice;
		this.btnAddSize = btnAddSize;
		this.btnUpdateSize = btnUpdateSize;
		this.btnDeleteSize = btnDeleteSize;
		this.txtSizePercentageAdded = txtSizePercentageAdded;
		//Sugar Level Instance variables
		this.tblSugarLvl = tblSugarLvl;
		this.txtSugarLevel = txtSugarLevel;
		this.btnAddSL = btnAddSL;
		this.btnUpdateSL = btnUpdateSL;
		this.btnDeleteSL = btnDeleteSL;
		this.txtSugarQty = txtSugarQty;
		//Auto Generated Ids Instance variables
		this.LblgenCat = LblgenCat;
		this.LblGenAO = LblGenAO;
		this.LblGenProd = LblGenProd;
	}
//******************************************Product Functions******************************************//
    public void ProductEvents() {
/*this code sets up an action listener for the btnChooseImg button. When clicked, it opens a file chooser, 
 * allows the user to select an image file, displays the selected image on the lblImg label, and provides 
 * access to the image data in the form of a byte array.
 */
    	btnChooseImg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.showOpenDialog(null);
                File f = chooser.getSelectedFile();
                if (f != null) {
                    String path = f.getAbsolutePath();
                    try {
                        BufferedImage bi = ImageIO.read(f);
                        Image img = bi.getScaledInstance(336, 277, Image.SCALE_SMOOTH);
                        ImageIcon icon = new ImageIcon(img);
                        lblImg.setIcon(icon);

                        byte[] imageBytes = Files.readAllBytes(f.toPath());

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
//Insert product to DB
    	btnAdd.addActionListener(new ActionListener() {
    	    @Override
    	    public void actionPerformed(ActionEvent e) {
    	        String pID = txtProductId.getText();
    	        String pCAT = (String) cbxProdCategory.getSelectedItem();
    	        String pNM = txtProductName.getText();
    	        String pPRC = txtPrice.getText();
    	        String pDESC = txtDescription.getText();
    	        byte[] lblimg = null;
    	        Icon icon = lblImg.getIcon();
//Validates the format of the product ID (pID) using a regular expression pattern.
    	        if (!pID.matches("P\\d{6}")) {
    	        	JOptionPane.showMessageDialog(null, "Invalid Product ID format. Please use the format with the letter 'P' followed by six digits. Example: 'P000000'", "Invalid Input", JOptionPane.ERROR_MESSAGE);
    	            return;
    	        }
    	        if (icon instanceof ImageIcon) {
    	            Image img = ((ImageIcon) icon).getImage();
    	            BufferedImage bImage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
    	            Graphics2D bImageGraphics = bImage.createGraphics();
    	            bImageGraphics.drawImage(img, 0, 0, null);
    	            bImageGraphics.dispose();
    	            ByteArrayOutputStream baos = new ByteArrayOutputStream();
    	            try {
    	                ImageIO.write(bImage, "png", baos);
    	                baos.flush();
    	                lblimg = baos.toByteArray();
    	                baos.close();
    	            } catch (IOException ex) {
    	                ex.printStackTrace();
    	            }
    	        }  
    	        if(cbxProdCategory.getSelectedItem().equals("")||txtProductName.getText().equals("Product Name")||txtPrice.getText().equals("Price")||txtDescription.getText().equals("Description")) {
    	        	JOptionPane.showMessageDialog(null, "Please insert a valid data", "Invalid Input", JOptionPane.ERROR_MESSAGE);
    	        	return;
    	        }
    	        try {
    	            Connection conn = JdbcConn.connect();
    	            PreparedStatement pst = conn.prepareStatement("INSERT INTO product_tb (Product_ID, Category, Product_Name, Price, Description, Image) VALUES (?, ?, ?, ?, ?, ?)");
    	            pst.setString(1, pID);
    	            pst.setString(2, pCAT);
    	            pst.setString(3, pNM);
    	            pst.setString(4, pPRC);
    	            pst.setString(5, pDESC);
    	            pst.setBytes(6, lblimg);
    	            pst.executeUpdate();  	            
    	            JOptionPane.showMessageDialog(null, "Product successfully inserted.", "Success", JOptionPane.INFORMATION_MESSAGE);
    	            PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
    	            p.TblProductPopulate();

    	        } catch (SQLException ex) {
    	            ex.printStackTrace();
    	            JOptionPane.showMessageDialog(null, "Failed to insert product: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    	        }
    	    }
    	});

//Displays the product info in the fields
    	tblProducts.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                DefaultTableModel d1 = (DefaultTableModel) tblProducts.getModel();
                int selectedIndex = tblProducts.getSelectedRow();

                txtProductId.setText(d1.getValueAt(selectedIndex, 0).toString());
                cbxProdCategory.setSelectedItem(d1.getValueAt(selectedIndex, 1).toString());
                txtProductName.setText(d1.getValueAt(selectedIndex, 2).toString());
                txtPrice.setText(d1.getValueAt(selectedIndex, 3).toString());
                txtDescription.setText(d1.getValueAt(selectedIndex, 4).toString());

                byte[] imageData = (byte[]) d1.getValueAt(selectedIndex, 5);
                if (imageData != null) {
                    ImageIcon icon = new ImageIcon(imageData);
                    lblImg.setIcon(icon);
                } else {
                	lblImg.setIcon(null); // Set the icon to null when imageData is null
                }
            }
        });
//Delete product from db
    	btnDelete.addMouseListener(new MouseAdapter() {
    	    @Override
    	    public void mouseClicked(MouseEvent e) {
    	        DefaultTableModel d1 = (DefaultTableModel) tblProducts.getModel();
    	        int selectedIndex = tblProducts.getSelectedRow();

    	        if (selectedIndex == -1) {
    	            // No row selected, display message dialog
    	            JOptionPane.showMessageDialog(null, "Please select a row to delete.");
    	            return;
    	        }

    	        String idString = d1.getValueAt(selectedIndex, 0).toString();
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Delete the Record", "Warning", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
    	            try {
    	                Connection conn = JdbcConn.connect();
    	                String query = "DELETE FROM product_tb WHERE Product_ID = ?";
    	                PreparedStatement pst = conn.prepareStatement(query);
    	                pst.setString(1, idString);
    	                pst.executeUpdate();
    	                PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
        	    		p.TblProductPopulate();
    	                JOptionPane.showMessageDialog(null, "Product Deleted.");
    	            } catch (SQLException r) {
        	            JOptionPane.showMessageDialog(null, "error: " + r.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

    	            }
    	        }
    	    }
    	});
//Update Products
    	btnUpdate.addMouseListener(new MouseAdapter() {
    	    @Override
    	    public void mouseClicked(MouseEvent e) {
    	        DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
    	        int selectedIndex = tblProducts.getSelectedRow();

    	        if (selectedIndex == -1) {
    	            JOptionPane.showMessageDialog(null, "Please select a row to update.");
    	            return;
    	        }

    	        String pID = txtProductId.getText();
    	        String pCAT = (String) cbxProdCategory.getSelectedItem();
    	        String pNM = txtProductName.getText();
    	        String pPRC = txtPrice.getText();
    	        String pDESC = txtDescription.getText();
    	        byte[] imageBytes = null;
    	        Icon icon = lblImg.getIcon();
    	        if (!pID.matches("P\\d{6}")) {
    	        	JOptionPane.showMessageDialog(null, "Invalid Product ID format. Please use the format with the letter 'P' followed by six digits. Example: 'P000000'", "Invalid Input", JOptionPane.ERROR_MESSAGE);
    	            return;
    	        }
    	        if (icon instanceof ImageIcon) {
    	            Image img = ((ImageIcon) icon).getImage();
    	            BufferedImage bImage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
    	            Graphics2D bImageGraphics = bImage.createGraphics();
    	            bImageGraphics.drawImage(img, 0, 0, null);
    	            bImageGraphics.dispose();

    	            ByteArrayOutputStream baos = new ByteArrayOutputStream();
    	            try {
    	                ImageIO.write(bImage, "png", baos);
    	                baos.flush();
    	                imageBytes = baos.toByteArray();
    	                baos.close();
    	            } catch (IOException ex) {
    	                ex.printStackTrace();
    	            }
    	        }

    	        Connection conn = null;
    	        PreparedStatement pst = null;
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Update the Record", "Message", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
    	        try {
    	            Connection conn1 = JdbcConn.connect();
    	            String query = "UPDATE product_tb SET Product_ID = ?, Category = ?, Product_Name = ?, "
    	                    + "Price = ?, Description = ?, Image = ?  WHERE Product_ID = ?";
    	            pst = conn1.prepareStatement(query);
    	            pst.setString(1, pID);
    	            pst.setString(2, pCAT);
    	            pst.setString(3, pNM);
    	            pst.setString(4, pPRC);
    	            pst.setString(5, pDESC);
    	            pst.setBytes(6, imageBytes);
    	            pst.setString(7, pID); // Use the provided Product ID directly

    	            int rowsUpdated = pst.executeUpdate();   	          
    	            if (rowsUpdated > 0) {
    	                JOptionPane.showMessageDialog(null, "Successfully updated.");
    	            } else {
    	                JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
    	            }
	                PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
    	            p.TblProductPopulate();
    	        } catch (SQLException ex) {
    	            ex.printStackTrace();
    	            JOptionPane.showMessageDialog(null, "An error occurred while updating the product.");
    	        } finally {
    	            try {
    	                if (pst != null) {
    	                    pst.close();
    	                }
    	                if (conn != null) {
    	                    conn.close();
    	                }
    	            } catch (SQLException ex) {
    	                ex.printStackTrace();
    	            }
    	        	}
    	        }
    	    }
    	});
    }
//******************************************Product Category Functions************************************//
    public void ProdCatActions() {
//Insert Product Category to DB
    	btnAddCategory.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String catID = txtCategoryId.getText();        
                String pCAT = txtProductCategory.getText();          
                if (!catID.matches("C\\d{6}")) {
    	        	JOptionPane.showMessageDialog(null, "Invalid Product ID format. Please use the format with the letter 'C' followed by six digits. Example: 'C000000'", "Invalid Input", JOptionPane.ERROR_MESSAGE);
    	            return;
    	        }
                try {
    	            Connection conn = JdbcConn.connect();
                    String sql = "INSERT INTO category (Category_ID, Category) VALUES (?, ?)";
                    PreparedStatement pst = conn.prepareStatement(sql);
                    pst.setString(1, catID);
                    pst.setString(2, pCAT);
    	    	
                    pst.executeUpdate(); // Execute the statement to insert the category into the database
    	            JOptionPane.showMessageDialog(null, "Category successfully inserted.", "Success", JOptionPane.INFORMATION_MESSAGE);
	                PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
    	    		p.TblProdCatPopulate();
                    pst.close();
                  
                    conn.close();
                } catch (Exception m) {
                    m.printStackTrace();
                }
            }
    	});
//Delete Category
    	btnDeleteCategory.addMouseListener(new MouseAdapter() {
    	    @Override
    	    public void mouseClicked(MouseEvent e) {
    	        DefaultTableModel d1 = (DefaultTableModel) tblProdCategory.getModel();
    	        int selectedIndex = tblProdCategory.getSelectedRow();

    	        if (selectedIndex == -1) {
    	            // No row selected, display message dialog
    	            JOptionPane.showMessageDialog(null, "Please select a row to delete.");
    	            return;
    	        }

    	        String idString = d1.getValueAt(selectedIndex, 0).toString();
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Delete the Record", "Warning", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
    	            try {
    	                Connection conn = JdbcConn.connect();
    	                String query = "DELETE FROM category WHERE Category_ID = ?";
    	                PreparedStatement pst = conn.prepareStatement(query);
    	                pst.setString(1, idString);
    	                pst.executeUpdate();    	           
    	                JOptionPane.showMessageDialog(null, "Category Deleted.");
    	                PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
        	    		p.TblProdCatPopulate();
    	            } catch (Exception r) {
    	                r.printStackTrace();
    	            }
    	        }
    	    }
    	});
//Update Product Category
    	btnUpdateCategory.addMouseListener(new MouseAdapter() {
    	    @Override
    	    public void mouseClicked(MouseEvent e) {
    	        DefaultTableModel model = (DefaultTableModel) tblProdCategory.getModel();
    	        int selectedIndex = tblProdCategory.getSelectedRow();

    	        if (selectedIndex == -1) {
    	            JOptionPane.showMessageDialog(null, "Please select a row to update.");
    	            return;
    	        }

    	        String catID = txtCategoryId.getText();
    	        String pCAT = txtProductCategory.getText();

    	        if (!catID.matches("C\\d{6}")) {
    	            JOptionPane.showMessageDialog(null, "Invalid Category ID format. Please use the format with the letter 'C' followed by six digits. Example: 'C000000'", "Invalid Input", JOptionPane.ERROR_MESSAGE);
    	            return;
    	        }

    	        Connection conn = null;
    	        PreparedStatement pst = null;
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Update the Record", "Message", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
    	        try {
    	            conn = JdbcConn.connect();
    	            String query = "UPDATE category SET Category_ID = ?, Category = ? WHERE Category_ID = ?";
    	            pst = conn.prepareStatement(query);
    	            pst.setString(1, catID);
    	            pst.setString(2, pCAT);
    	            pst.setString(3, model.getValueAt(selectedIndex, 0).toString()); // Use the original Category ID from the table

    	            int rowsUpdated = pst.executeUpdate();

    	            if (rowsUpdated > 0) {
    	                JOptionPane.showMessageDialog(null, "Successfully updated.");
    	                PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
    	                p.TblProdCatPopulate();
    	            } else {
    	                JOptionPane.showMessageDialog(null, "No rows were updated. Please check the Category ID.");
    	            }
    	        } catch (SQLException ex) {
    	            ex.printStackTrace();
    	            JOptionPane.showMessageDialog(null, "An error occurred while updating the category: " + ex.getMessage());
    	        } finally {
    	            try {
    	                if (pst != null) {
    	                    pst.close();
    	                }
    	                if (conn != null) {
    	                    conn.close();
    	                }
    	            } catch (SQLException ex) {
    	                ex.printStackTrace();
    	            }
    	        }
    	    }
    	    }
    	});
//Displays the product info in the fields
    	tblProdCategory.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                DefaultTableModel d1 = (DefaultTableModel) tblProdCategory.getModel();
                int selectedIndex = tblProdCategory.getSelectedRow();
                txtCategoryId.setText(d1.getValueAt(selectedIndex, 0).toString());
                txtProductCategory.setText(d1.getValueAt(selectedIndex, 1).toString());              
            }
        });
    }
 //******************************************Add-Ons Functions************************************//
    public void AddOnsActions() {
 //Insert Add-Ons to DB
    	btnInsertAddOns.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String aID = txtAddOnsID.getText();  
                String aOCat = (String) cbxAddOnsCat.getSelectedItem();
                String aO = txtAddOns.getText();
                String aPRC = txtAddOnsPrice.getText();          

                if (!aID.matches("A\\d{6}")) {
    	        	JOptionPane.showMessageDialog(null, "Invalid Product ID format. Please use the format with the letter 'A' followed by six digits. Example: 'A000000'", "Invalid Input", JOptionPane.ERROR_MESSAGE);
    	            return;
    	        }
                try {
    	            Connection conn = JdbcConn.connect();
    	         // Check if the Add-Ons Id already exists in the database
    	            String checkQuery = "SELECT Product_ID FROM product_tb WHERE Product_ID = ?";
    	            PreparedStatement checkPst = conn.prepareStatement(checkQuery);
    	            checkPst.setString(1, aID);
    	            ResultSet rs = checkPst.executeQuery();

    	            if (rs.next()) {
    	                JOptionPane.showMessageDialog(null, "Add-Ons with ID " + aID + " already exists in the database.", "Duplicate Entry", JOptionPane.WARNING_MESSAGE);
    	                checkPst.close();
    	                conn.close();
    	                return;
    	            }
                    String sql = "INSERT INTO product_tb (Product_ID, Category, Product_Name, Price) VALUES (?, ?, ?, ?)";
                    PreparedStatement pst = conn.prepareStatement(sql);
                    pst.setString(1, aID);
                    pst.setString(2, aOCat);
                    pst.setString(3, aO);
                    pst.setString(4, aPRC);
                    pst.executeUpdate(); // Execute the statement to insert the category into the database
    	            JOptionPane.showMessageDialog(null, "Add-Ons successfully inserted.", "Success", JOptionPane.INFORMATION_MESSAGE);
	                PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
    	    		p.TblAddOnsPopulate();
                    pst.close();
                  
                    conn.close();
                } catch (Exception m) {
                    m.printStackTrace();
                }
            }
    	});
//Delete Add-Ons
    	btnDeleteAddOns.addMouseListener(new MouseAdapter() {
    	    @Override
    	    public void mouseClicked(MouseEvent e) {
    	        DefaultTableModel d1 = (DefaultTableModel) tblAddOns.getModel();
    	        int selectedIndex = tblAddOns.getSelectedRow();

    	        if (selectedIndex == -1) {
    	            JOptionPane.showMessageDialog(null, "Please select a row to delete.");
    	            return;
    	        }

    	        String idString = d1.getValueAt(selectedIndex, 0).toString();
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Delete the Record", "Warning", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
    	            try {
    	                Connection conn = JdbcConn.connect();
    	                String query = "DELETE FROM product_tb WHERE Product_ID = ?";
    	                PreparedStatement pst = conn.prepareStatement(query);
    	                pst.setString(1, idString);
    	                pst.executeUpdate();    	           
    	                JOptionPane.showMessageDialog(null, "Add-Ons Deleted.");
    	                PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
        	    		p.TblAddOnsPopulate();
    	            } catch (Exception r) {
    	                r.printStackTrace();
    	            }
    	        }
    	    }
    	});
//Update Add-Ons
    	btnUpdateAddOns.addMouseListener(new MouseAdapter() {
    	    @Override
    	    public void mouseClicked(MouseEvent e) {
    	        DefaultTableModel model = (DefaultTableModel) tblAddOns.getModel();
    	        int selectedIndex = tblAddOns.getSelectedRow();

    	        if (selectedIndex == -1) {
    	            JOptionPane.showMessageDialog(null, "Please select a row to update.");
    	            return;
    	        }

    	        String aID = txtAddOnsID.getText();  
                String aOCat = (String) cbxAddOnsCat.getSelectedItem();
                String aO = txtAddOns.getText();
                String aPRC = txtAddOnsPrice.getText(); 

    	        if (!aID.matches("A\\d{6}")) {
    	            JOptionPane.showMessageDialog(null, "Invalid Category ID format. Please use the format with the letter 'A' followed by six digits. Example: 'A000000'", "Invalid Input", JOptionPane.ERROR_MESSAGE);
    	            return;
    	        }

    	        Connection conn = null;
    	        PreparedStatement pst = null;
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Update the Record", "Message", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
    	        try {
    	            conn = JdbcConn.connect();
    	            String query = "UPDATE product_tb SET Product_ID = ?, Category = ?, Product_Name = ?, Price = ? WHERE Product_ID = ?";
    	            pst = conn.prepareStatement(query);
    	            pst.setString(1, aID);
    	            pst.setString(2, aOCat);
    	            pst.setString(3, aO);
    	            pst.setString(4, aPRC);
    	            pst.setString(5, model.getValueAt(selectedIndex, 0).toString()); // Use the original Category ID from the table

    	            int rowsUpdated = pst.executeUpdate();

    	            if (rowsUpdated > 0) {
    	                JOptionPane.showMessageDialog(null, "Successfully updated.");
    	                PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
        	    		p.TblAddOnsPopulate();
    	            } else {
    	                JOptionPane.showMessageDialog(null, "No rows were updated. Please check the Add-Ons ID.");
    	            }
    	        } catch (SQLException ex) {
    	            ex.printStackTrace();
    	            JOptionPane.showMessageDialog(null, "An error occurred while updating the Add-Ons: " + ex.getMessage());
    	        } finally {
    	            try {
    	                if (pst != null) {
    	                    pst.close();
    	                }
    	                if (conn != null) {
    	                    conn.close();
    	                }
    	            } catch (SQLException ex) {
    	                ex.printStackTrace();
    	            }
    	        }
    	    }
    	    }
    	});
//Displays the Add-Ons in the fields
    	tblAddOns.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
              
                	DefaultTableModel d1 = (DefaultTableModel) tblAddOns.getModel();
                    int selectedIndex = tblAddOns.getSelectedRow();
                    txtAddOnsID.setText(d1.getValueAt(selectedIndex, 0).toString());
                    cbxAddOnsCat.setSelectedItem(d1.getValueAt(selectedIndex, 1).toString());
                    txtAddOns.setText(d1.getValueAt(selectedIndex, 2).toString()); 
                    txtAddOnsPrice.setText(d1.getValueAt(selectedIndex, 3).toString());                                             
            }
        });
    }
//******************************************Product Size Functions************************************//
    public void ProductSizeFunction () {
//Insert Product Size to DB
    	tblSize.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                DefaultTableModel d1 = (DefaultTableModel) tblSize.getModel();
                int selectedIndex = tblSize.getSelectedRow();
                txtSize.setText(d1.getValueAt(selectedIndex, 1).toString());
                txtSizePrice.setText(d1.getValueAt(selectedIndex, 2).toString());
                txtSizePercentageAdded.setText(d1.getValueAt(selectedIndex, 3).toString());
            }
        });
//InsertSize() {
    	btnAddSize.addActionListener(new ActionListener() {
    	    @Override
    	    public void actionPerformed(ActionEvent e) {
    	        String sz = txtSize.getText();
    	        String sp = txtSizePrice.getText();
    	        String spa = txtSizePercentageAdded.getText();
    	        try {
    	            Connection conn = JdbcConn.connect();

    	            // Check if the sz already exists in the database
    	            String checkQuery = "SELECT Product_Size FROM product_size WHERE Product_Size = ?";
    	            PreparedStatement checkPst = conn.prepareStatement(checkQuery);
    	            checkPst.setString(1, sz);
    	            ResultSet rs = checkPst.executeQuery();

    	            if (rs.next()) {
    	                JOptionPane.showMessageDialog(null, "Product Size "+ "'" + sz + "'"+" already exists in the database.", "Duplicate Entry", JOptionPane.WARNING_MESSAGE);
    	                checkPst.close();
    	                conn.close();
    	                return;
    	            }

    	            // Insert the new Size if it does not exist
    	            String insertQuery = "INSERT INTO product_size (Product_Size, Size_Price, Percent_Add) VALUES (?, ?, ?)";
    	            PreparedStatement insertPst = conn.prepareStatement(insertQuery);
    	            insertPst.setString(1, sz);
    	            insertPst.setString(2, sp);
    	            insertPst.setString(3, spa);

    	            insertPst.executeUpdate();

    	            JOptionPane.showMessageDialog(null, "Size successfully added.", "Success", JOptionPane.INFORMATION_MESSAGE);

    	            PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
    	            p.TblProdSizePopulate();

    	            insertPst.close();
    	            conn.close();
    	        } catch (SQLException ex) {
    	            ex.printStackTrace();
    	            JOptionPane.showMessageDialog(null, "An error occurred while adding the Size: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    	        }
    	    }
    	});

//Delete Size
    	btnDeleteSize.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel d1 = (DefaultTableModel) tblSize.getModel();
                int selectedIndex = tblSize.getSelectedRow();
                if (selectedIndex == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to delete.");
                    return;
                }
                 int id1 = Integer.parseInt(d1.getValueAt(selectedIndex, 0).toString());
                int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Delete the Record", "Warning", JOptionPane.YES_NO_OPTION);

                if (dialogResult == JOptionPane.YES_OPTION) {
                    try {
    	                Connection conn = JdbcConn.connect();
                        String query = ("DELETE FROM product_size WHERE Size_ID = ?");
                        PreparedStatement pst = conn.prepareStatement(query);
                        pst.setInt(1, id1);
                        pst.executeUpdate();
                        PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
                        p.TblProdSizePopulate();
                        JOptionPane.showMessageDialog(null, "Product Size Deleted.");
                    } catch (Exception r) {
                        r.printStackTrace();
                    }               
                }
			}   		
    	});
    
//Update Size
    	btnUpdateSize.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) tblSize.getModel();
                int selectedIndex = tblSize.getSelectedRow();
                if (selectedIndex == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to update.");
                    return;
                }
                int id = Integer.parseInt(model.getValueAt(selectedIndex, 0).toString());
                String sz = txtSize.getText();
				String sp = txtSizePrice.getText();
    	        String spa = txtSizePercentageAdded.getText();

				int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Update the Record", "Message", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
                try {
                    PreparedStatement pst = null;
	                Connection conn = JdbcConn.connect();
                    String query = "UPDATE product_size SET Product_Size = ?, Price = ?, Percent_Add = ? WHERE Size_ID = ?";
                    pst = conn.prepareStatement(query);
                    pst.setString(1, sz);
                    pst.setString(2, sp);
                    pst.setString(3, spa);
                    pst.setInt(4, id);
                    int rowsUpdated = pst.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(null, "Successfully updated.");
                        PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
                        p.TblProdSizePopulate();           
                    } else {
                        JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
                    }
                } catch (Exception r) {
                    r.printStackTrace();
                }      				
			} 
			}
    	});
    }
//******************************************Sugar Level Functions************************************//
    public void SugarLevelFunction () {
//Display Sugar Lvl to fields
    	tblSugarLvl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                DefaultTableModel d1 = (DefaultTableModel) tblSugarLvl.getModel();
                int selectedIndex = tblSugarLvl.getSelectedRow();
                txtSugarLevel.setText(d1.getValueAt(selectedIndex, 1).toString());
                txtSugarQty.setText(d1.getValueAt(selectedIndex, 2).toString());
          
            }
        });
//Insert Sugar Lvl() {
    	btnAddSL.addActionListener(new ActionListener() {
    	    @Override
    	    public void actionPerformed(ActionEvent e) {
    	        String sLvl = txtSugarLevel.getText();
    	        String sSQ = txtSugarQty.getText();

    	        try {
    	            Connection conn = JdbcConn.connect();

    	            // Insert the new Size if it does not exist
    	            String insertQuery = "INSERT INTO sugarlvl (SugarLvl, Sugar_Qty) VALUES (?, ?)";
    	            PreparedStatement insertPst = conn.prepareStatement(insertQuery);
    	            insertPst.setString(1, sLvl);
    	            insertPst.setString(2, sSQ);

    	            insertPst.executeUpdate();

    	            JOptionPane.showMessageDialog(null, "Size successfully added.", "Success", JOptionPane.INFORMATION_MESSAGE);
    	            PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
    	            p.TblSugarLvlPopulate();

    	            insertPst.close();
    	            conn.close();
    	        } catch (SQLException ex) {
    	            ex.printStackTrace();
    	            JOptionPane.showMessageDialog(null, "An error occurred while adding the Size: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    	        }
    	    }
    	});

//Delete Sugar Lvl
    	btnDeleteSL.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel d1 = (DefaultTableModel) tblSugarLvl.getModel();
                int selectedIndex = tblSugarLvl.getSelectedRow();
                if (selectedIndex == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to delete.");
                    return;
                }
                 int id1 = Integer.parseInt(d1.getValueAt(selectedIndex, 0).toString());
                int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Delete the Record", "Warning", JOptionPane.YES_NO_OPTION);

                if (dialogResult == JOptionPane.YES_OPTION) {
                    try {
    	                Connection conn = JdbcConn.connect();
                        String query = ("DELETE FROM sugarlvl WHERE Sugar_Lvl_ID = ?");
                        PreparedStatement pst = conn.prepareStatement(query);
                        pst.setInt(1, id1);
                        pst.executeUpdate();                       
                        JOptionPane.showMessageDialog(null, "Sugar Level Deleted.");
                        PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
                        p.TblSugarLvlPopulate();
                    } catch (Exception r) {
                        r.printStackTrace();
                    }               
                }
			}   		
    	});   
//Update Size
    	btnUpdateSL.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) tblSugarLvl.getModel();
                int selectedIndex = tblSugarLvl.getSelectedRow();
                if (selectedIndex == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to update.");
                    return;
                }
                int id = Integer.parseInt(model.getValueAt(selectedIndex, 0).toString());
                String SLvl = txtSugarLevel.getText();
    	        String sSQ = txtSugarQty.getText();

				int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Update the Record", "Message", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
                try {
                    PreparedStatement pst = null;
	                Connection conn = JdbcConn.connect();
                    String query = "UPDATE sugarlvl SET SugarLvl = ?, Sugar_Qty = ? WHERE Sugar_Lvl_ID = ?";
                    pst = conn.prepareStatement(query);
                    pst.setString(1, SLvl);
                    pst.setString(2, sSQ);
                    pst.setInt(3, id);
                    int rowsUpdated = pst.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(null, "Successfully updated.");
                        PopulateProduct p = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns, tblSize, tblSugarLvl, cbxAddOnsCat);
                        p.TblSugarLvlPopulate();           
                    } else {
                        JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
                    }
                } catch (Exception r) {
                    r.printStackTrace();
                }      				
			} 
			}
    	});
    }
//****************************************************Generate Id Category****************************************************//
    public static class CategoryIdGenerator {
	    public static String generateOrderId() {
	        String orderIdFormat = "C%06d";
	        int CatId = getNextCatId();
	        return String.format(orderIdFormat, CatId);
	    }

	    private static int getNextCatId() {
	        try {
	            Connection conn = JdbcConn.connect();
	            String query = "SELECT MAX(CAST(SUBSTRING(Category_ID, 2) AS UNSIGNED)) AS max_id FROM category";
	            Statement statement = conn.createStatement();
	            ResultSet resultSet = statement.executeQuery(query);
	            if (resultSet.next()) {
	                int maxId = resultSet.getInt("max_id");
	                return maxId + 1;
	            }
	            statement.close();
	            resultSet.close();
	            conn.close();
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	        return 1; // Default starting value if no existing orders
	    }
	}
	public void GenerateOrderID() {
		LblgenCat.addMouseListener(new MouseAdapter() {
			@Override
	         public void mouseClicked(MouseEvent e) {
				txtCategoryId.setText("");
	            String orderId = CategoryIdGenerator.generateOrderId();
	            txtCategoryId.setText(orderId);
	           
    	            JOptionPane.showMessageDialog(null, "Categoty ID Generated Successfully!.", "Success", JOptionPane.INFORMATION_MESSAGE);
			}
		});
	}
//****************************************************Generate Id Add-ons****************************************************//
	 public static class AddOnsIdGenerator {
		    public static String generateOrderId() {
		        String orderIdFormat = "A%06d";
		        int AoId = getNextAoId();
		        return String.format(orderIdFormat, AoId);
		    }

		    private static int getNextAoId() {
		        try {
		            Connection conn = JdbcConn.connect();
		            String query = "SELECT MAX(CAST(SUBSTRING(Product_ID, 2) AS UNSIGNED)) AS max_id FROM product_tb WHERE Product_ID LIKE 'A%'";
		            Statement statement = conn.createStatement();
		            ResultSet resultSet = statement.executeQuery(query);
		            if (resultSet.next()) {
		                int maxId = resultSet.getInt("max_id");
		                return maxId + 1;
		            }
		            statement.close();
		            resultSet.close();
		            conn.close();
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		        return 1; // Default starting value if no existing orders
		    }
		}
		public void GenerateAoID() {
			LblGenAO.addMouseListener(new MouseAdapter() {
				@Override
		         public void mouseClicked(MouseEvent e) {
					txtAddOnsID.setText("");
		            String orderId = AddOnsIdGenerator.generateOrderId();
		            txtAddOnsID.setText(orderId);
		           
	    	            JOptionPane.showMessageDialog(null, "Add-On ID Generated Successfully!.", "Success", JOptionPane.INFORMATION_MESSAGE);
				}
			});
		}		
//****************************************************Generate Product ID****************************************************//
		 public static class ProductIdGenerator {
			    public static String generateOrderId() {
			        String orderIdFormat = "P%06d";
			        int PrId = getNextPrId();
			        return String.format(orderIdFormat, PrId);
			    }

			    private static int getNextPrId() {
			        try {
			            Connection conn = JdbcConn.connect();
			            String query = "SELECT MAX(CAST(SUBSTRING(Product_ID, 2) AS UNSIGNED)) AS max_id FROM product_tb WHERE Product_ID LIKE 'P%'";
			            Statement statement = conn.createStatement();
			            ResultSet resultSet = statement.executeQuery(query);
			            if (resultSet.next()) {
			                int maxId = resultSet.getInt("max_id");
			                return maxId + 1;
			            }
			            statement.close();
			            resultSet.close();
			            conn.close();
			        } catch (SQLException ex) {
			            ex.printStackTrace();
			        }
			        return 1; // Default starting value if no existing orders
			    }
			}
			public void GeneratePrID() {
				LblGenProd.addMouseListener(new MouseAdapter() {
					@Override
			         public void mouseClicked(MouseEvent e) {
						txtProductId.setText("");
			            String orderId = ProductIdGenerator.generateOrderId();
			            txtProductId.setText(orderId);
			           
		    	            JOptionPane.showMessageDialog(null, "Add-On ID Generated Successfully!.", "Success", JOptionPane.INFORMATION_MESSAGE);
					}
				});
			}		
}

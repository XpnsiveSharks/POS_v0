package CoreObjClasses;

import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;


public class minorFunctions{
	private JPanel paneProducts, paneCategory, paneAddOns, paneSize, paneSugarLvl, panel, paneCashier,
	paneInventory, paneOverview, paneLogout;
	private JTabbedPane tPaneMenu;
	private JTextField txtProductName, txtProductId, txtPrice, txtDescription, txtCategoryId, txtProductCategory,
		txtAddOnsID, txtAddOns, txtAddOnsPrice, txtSize, txtSizePrice , txtSugarLevel, txtSugarQty, txtSizePercentageAdded;

	public minorFunctions(JPanel paneProducts, JPanel paneCategory, JPanel paneAddOns, JPanel paneSize,
			JPanel paneSugarLvl, JPanel panel, JPanel paneCashier, JPanel paneInventory, JPanel paneOverview,
			JPanel paneLogout, JTabbedPane tPaneMenu, JTextField txtProductName, JTextField txtProductId,
			JTextField txtPrice, JTextField txtDescription, JTextField txtCategoryId, JTextField txtProductCategory,
			JTextField txtAddOnsID, JTextField txtAddOns, JTextField txtAddOnsPrice, JTextField txtSize,
			JTextField txtSizePrice, JTextField txtSugarLevel, JTextField txtSugarQty, JTextField txtSizePercentageAdded) {
		super();
		this.paneProducts = paneProducts;
		this.paneCategory = paneCategory;
		this.paneAddOns = paneAddOns;
		this.paneSize = paneSize;
		this.paneSugarLvl = paneSugarLvl;
		this.panel = panel;
		this.paneCashier = paneCashier;
		this.paneInventory = paneInventory;
		this.paneOverview = paneOverview;
		this.paneLogout = paneLogout;
		this.tPaneMenu = tPaneMenu;
		this.txtProductName = txtProductName;
		this.txtProductId = txtProductId;
		this.txtPrice = txtPrice;
		this.txtDescription = txtDescription;
		this.txtCategoryId = txtCategoryId;
		this.txtProductCategory = txtProductCategory;
		this.txtAddOnsID = txtAddOnsID;
		this.txtAddOns = txtAddOns;
		this.txtAddOnsPrice = txtAddOnsPrice;
		this.txtSize = txtSize;
		this.txtSizePrice = txtSizePrice;
		this.txtSugarLevel = txtSugarLevel;
		this.txtSugarQty = txtSugarQty;
		this.txtSizePercentageAdded = txtSizePercentageAdded;
	}
	public void menuPanels() {
	    paneProducts.addMouseListener(new PanelButtonMouseAdapter(paneProducts) {
	        public void mouseClicked(MouseEvent e) {
	            tPaneMenu.setSelectedIndex(0);
	        }
	    });
	    paneCategory.addMouseListener(new PanelButtonMouseAdapter(paneCategory) {
	        public void mouseClicked(MouseEvent e) {
	            tPaneMenu.setSelectedIndex(1);
	        }
	    });
	    paneAddOns.addMouseListener(new PanelButtonMouseAdapter(paneAddOns) {
	        public void mouseClicked(MouseEvent e) {
	            tPaneMenu.setSelectedIndex(2);
	        }
	    });
	    paneSize.addMouseListener(new PanelButtonMouseAdapter(paneSize) {
	        public void mouseClicked(MouseEvent e) {
	            tPaneMenu.setSelectedIndex(3);
	        }
	    });
	    paneSugarLvl.addMouseListener(new PanelButtonMouseAdapter(paneSugarLvl) {
	        public void mouseClicked(MouseEvent e) {
	            tPaneMenu.setSelectedIndex(4);
	        }
	    });
	    paneCashier.addMouseListener(new PanelButtonMouseAdapter(paneCashier) {
	        public void mouseClicked(MouseEvent e) {
	        }
	    });
	    paneInventory.addMouseListener(new PanelButtonMouseAdapter(paneInventory) {
	        public void mouseClicked(MouseEvent e) {
	        }
	    });
	    paneOverview.addMouseListener(new PanelButtonMouseAdapter(paneOverview) {
	        public void mouseClicked(MouseEvent e) {
	        }
	    });
	    paneLogout.addMouseListener(new PanelButtonMouseAdapter(paneLogout) {
	        public void mouseClicked(MouseEvent e) {
	        }
	    });
	}

	private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel;
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(0, 100, 0));
		}
		@Override
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(89, 63, 14));
		}
		@Override
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(145, 234, 182));
		}
		@Override
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(89, 63, 14));
		}
		 
	}
//*******************************text fields*******************************//
	public void TextFields() {
	    txtProductName.addFocusListener(new JTextFieldFocusMouseAdapter(txtProductName));
	    txtProductId.addFocusListener(new JTextFieldFocusMouseAdapter(txtProductId));
	    txtPrice.addFocusListener(new JTextFieldFocusMouseAdapter(txtPrice));
	    txtDescription.addFocusListener(new JTextFieldFocusMouseAdapter(txtDescription));
	    txtCategoryId.addFocusListener(new JTextFieldFocusMouseAdapter(txtCategoryId));
	    txtProductCategory.addFocusListener(new JTextFieldFocusMouseAdapter(txtProductCategory));
	    txtAddOnsID.addFocusListener(new JTextFieldFocusMouseAdapter(txtAddOnsID));
	    txtAddOns.addFocusListener(new JTextFieldFocusMouseAdapter(txtAddOns));
	    txtAddOnsPrice.addFocusListener(new JTextFieldFocusMouseAdapter(txtAddOnsPrice));
	    txtSize.addFocusListener(new JTextFieldFocusMouseAdapter(txtSize));
	    txtSizePrice.addFocusListener(new JTextFieldFocusMouseAdapter(txtSizePrice));
	    txtSugarLevel.addFocusListener(new JTextFieldFocusMouseAdapter(txtSugarLevel));
	    txtSugarQty.addFocusListener(new JTextFieldFocusMouseAdapter(txtSugarQty));
	    txtSizePercentageAdded.addFocusListener(new JTextFieldFocusMouseAdapter(txtSizePercentageAdded));

	}

	private class JTextFieldFocusMouseAdapter extends FocusAdapter {
	    JTextField jtextField;

	    public JTextFieldFocusMouseAdapter(JTextField jtextField) {
	        this.jtextField = jtextField;
	    }

	    @Override
	    public void focusGained(FocusEvent e) {
	        if (jtextField.getText().equals("Product Name") || jtextField.getText().equals("Product Name")
	        		|| jtextField.getText().equals("Product ID")|| jtextField.getText().equals("Price") 
	        		|| jtextField.getText().equals("Description")|| jtextField.getText().equals("Category ID")
	        		|| jtextField.getText().equals("Product category")|| jtextField.getText().equals("Add-On ID")
	        		|| jtextField.getText().equals("Add-On")|| jtextField.getText().equals("Price") 
	        		|| jtextField.getText().equals("Product Size")|| jtextField.getText().equals("Price") 
	        		|| jtextField.getText().equals("Sugar Level")|| jtextField.getText().equals("Sugar Qty")
	        		|| jtextField.getText().equals("Size percentage Added")){
	            jtextField.setText("");
	            return;
	        }
	    }

	    @Override
	    public void focusLost(FocusEvent e) {
	        if (jtextField.getText().equals("")) {
	            if (jtextField == txtProductName) {
	                jtextField.setText("Product Name");
	            } else if (jtextField == txtProductId) {
	                jtextField.setText("Product ID");
	            } else if (jtextField == txtPrice) {
	                jtextField.setText("Price");
	            } else if (jtextField == txtDescription) {
	                jtextField.setText("Description");
	            } else if (jtextField == txtCategoryId) {
	                jtextField.setText("Category ID");
	            } else if (jtextField == txtProductCategory) {
	                jtextField.setText("Product category");
	            } else if (jtextField == txtAddOnsID) {
	                jtextField.setText("Add-On ID");
	            } else if (jtextField == txtAddOns) {
	                jtextField.setText("Add-On");
	            } else if (jtextField == txtAddOnsPrice) {
	                jtextField.setText("Price");
	            } else if (jtextField == txtSize) {
	                jtextField.setText("Product Size");
	            } else if (jtextField == txtSizePrice) {
	                jtextField.setText("Price");
	            } else if (jtextField == txtSugarLevel) {
	                jtextField.setText("Sugar Level");
	            } else if (jtextField == txtSugarQty) {
	                jtextField.setText("Sugar Qty");
	            } else if (jtextField == txtSizePercentageAdded) {
	                jtextField.setText("Size percentage Added");
	            }
	        }
	    }
	}
}


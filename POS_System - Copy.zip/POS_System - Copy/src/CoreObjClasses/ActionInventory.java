package CoreObjClasses;
/**
* @author: Marynelle
*/
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import JDBConnectivity.JdbcConn;
import net.proteanit.sql.DbUtils;

public class ActionInventory {
	private JTextField txtIngredients, txtQty, txtUnit, txtPrice, txtProd, txtIngSorter, txtQtyUsed
					   ;
	private JButton btnAdd, btnUpdate, btnDelete, btnAddUsage, btnUpdateUsage, btnDeleteUsage;
	private JTable tblIngredients, tblIngUsage, tblProductID, tblIngredientUsage;
	
	private TableRowSorter<TableModel> productSorter;
	private TableRowSorter<TableModel> ingredientSorter;

	private TableModel productTableModel;
	private TableModel ingredientTableModel;


    Connection conn = JdbcConn.connect();


	public ActionInventory(JTextField txtIngredients, JTextField txtQty, JTextField txtUnit, JTextField txtPrice,
			JButton btnAdd, JButton btnUpdate, JButton btnDelete, JTable tblIngredients, JTextField txtProd,
			JTable tblProductID, JTextField txtIngSorter, JTable tblIngUsage, JButton btnAddUsage, JButton btnUpdateUsage,
			JButton btnDeleteUsage, JTextField txtQtyUsed, JTable tblIngredientUsage) {
		this.txtIngredients = txtIngredients;
		this.txtQty = txtQty;
		this.txtUnit = txtUnit;
		this.txtPrice = txtPrice;
		this.btnAdd = btnAdd;
		this.btnUpdate = btnUpdate;
		this.btnDelete = btnDelete;
		this.tblIngredients = tblIngredients;
		this.txtProd = txtProd;
		this.tblProductID = tblProductID;
		this.txtIngSorter = txtIngSorter;
		this.tblIngUsage = tblIngUsage;
		this.btnAddUsage = btnAddUsage;
		this.btnUpdateUsage = btnUpdateUsage;
		this.btnDeleteUsage = btnDeleteUsage;
		this.txtQtyUsed = txtQtyUsed;
		this.tblIngredientUsage = tblIngredientUsage;
	}
	public void InventoryFunction () {
	    PopulateInventory p = new PopulateInventory(tblIngredients, tblIngredientUsage);
		//Display Ingredients
		tblIngredients.addMouseListener(new MouseAdapter() {
		            @Override
		            public void mouseClicked(MouseEvent e) {
		                DefaultTableModel d1 = (DefaultTableModel) tblIngredients.getModel();
		                int selectedIndex = tblIngredients.getSelectedRow();
		                txtIngredients.setText(d1.getValueAt(selectedIndex, 1).toString());
		                txtQty.setText(d1.getValueAt(selectedIndex, 2).toString());
		                txtUnit.setText(d1.getValueAt(selectedIndex, 3).toString());
		                txtPrice.setText(d1.getValueAt(selectedIndex, 4).toString());

		            }
		        });
		//Ingredients() {
		btnAdd.addActionListener(new ActionListener() {
		    	@Override
		    	public void actionPerformed(ActionEvent e) {
		    	    String ind = txtIngredients.getText();
		    	    String qty = txtQty.getText();
		    	    String unt = txtUnit.getText();
		    	    String prc = txtPrice.getText();
		    	 //to be checked
		    	    if(txtIngredients.getText().equals("")||txtQty.getText().equals("")||txtUnit.getText().equals("")||txtPrice.getText().equals("")){
			    	JOptionPane.showMessageDialog(null, "You can't insert a null value.", "Warning", JOptionPane.WARNING_MESSAGE);
	    	    		return;
	    	    		
		    	    }
		    	    else if(txtIngredients.getText().equals("Ingredients")||txtQty.getText().equals("Quantity")||txtUnit.getText().equals("Unit of Measurement")||txtPrice.getText().equals("Price")) {
				    	JOptionPane.showMessageDialog(null, "invalid Data inserted.", "Warning", JOptionPane.WARNING_MESSAGE);
		    	    	return;
		    	    }
		    	  //to be checked
		    	try {
		    	    String insertQuery = "INSERT INTO ingredients (Ingredient, Quantity, Unit, Price) VALUES (?, ?, ?, ?)";
		    	    PreparedStatement insertPst = conn.prepareStatement(insertQuery);
		    	    insertPst.setString(1, ind);
		    	    insertPst.setString(2, qty);
		    	    insertPst.setString(3, unt);
		    	    insertPst.setString(4, prc);
		    	    insertPst.executeUpdate();

		    	    JOptionPane.showMessageDialog(null, "Ingredients successfully added.", "Success", JOptionPane.INFORMATION_MESSAGE);
		    	    p.TblIngredientsPopulate();
		    	    insertPst.close();
		    	} catch (SQLException ex) {
		    	            ex.printStackTrace();
		    	            JOptionPane.showMessageDialog(null, "An error occurred while adding the Ingredients: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		    	        }
		    	txtIngredients.setText("Ingredients");
	            txtQty.setText("Quantity");
	            txtUnit.setText("Unit of Measurement");
	            txtPrice.setText("Price");
		    	    }
		    	});

		//Delete Size
		btnDelete.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        DefaultTableModel d1 = (DefaultTableModel) tblIngredients.getModel();
		        int selectedIndex = tblIngredients.getSelectedRow();
		        if (selectedIndex == -1) {
		            JOptionPane.showMessageDialog(null, "Please select a row to delete.");
		            return;
		        }
		        int id1 = Integer.parseInt(d1.getValueAt(selectedIndex, 0).toString());
		        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Delete the Record", "Warning", JOptionPane.YES_NO_OPTION);

		        if (dialogResult == JOptionPane.YES_OPTION) {
		            try {
		                String query = "DELETE FROM ingredients WHERE IngredientID = ?";
		                PreparedStatement pst = conn.prepareStatement(query);
		                pst.setInt(1, id1);
		                int rowsAffected = pst.executeUpdate();
		                if (rowsAffected > 0) {
		                    JOptionPane.showMessageDialog(null, "Ingredient Deleted.");
		                    p.TblIngredientsPopulate();
		                } else {
		                    JOptionPane.showMessageDialog(null, "Error: Ingredient not found or cannot be deleted.");
		                }
		            } catch (SQLException ex) {
		                if (ex.getErrorCode() == 1451) {
		                    JOptionPane.showMessageDialog(null, "Error: Cannot delete ingredient. It is referenced by other records.");
		                } else {
		                    ex.printStackTrace();
		                }
		            }
		        }
		    }
		});
  
		//Update Ingredients
		btnUpdate.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) tblIngredients.getModel();
		        int selectedIndex = tblIngredients.getSelectedRow();
		        if (selectedIndex == -1) {
		           JOptionPane.showMessageDialog(null, "Please select a row to update.");
		           return;
		        }
		        int id = Integer.parseInt(model.getValueAt(selectedIndex, 0).toString());
		        String ind = txtIngredients.getText();
	    	    String qty = txtQty.getText();
	    	    String unt = txtUnit.getText();
	    	    String prc = txtPrice.getText();
				int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Update the Record", "Message", JOptionPane.YES_NO_OPTION);

		    	if (dialogResult == JOptionPane.YES_OPTION) {
		           try {
		            PreparedStatement pst = null;
		            String query = "UPDATE ingredients SET Ingredient = ?, Quantity = ?, Unit = ?, Price = ? WHERE IngredientID = ?";
		            pst = conn.prepareStatement(query);
		            pst.setString(1, ind);
		            pst.setString(2, qty);
		            pst.setString(3, unt);
		            pst.setString(4, prc);
		            pst.setInt(5, id);
		            int rowsUpdated = pst.executeUpdate();
		        if (rowsUpdated > 0) {
		            JOptionPane.showMessageDialog(null, "Successfully updated.");        
		        } else {
		            JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
		        }
	    	    p.TblIngredientsPopulate();

		        } catch (Exception r) {
		             r.printStackTrace();
		           }      				
				} 
			}
		});
	}
//********************************Filtering Product & ingredients***********************************//
	public void filterProduct() {
		txtProd.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				String query = txtProd.getText().toLowerCase();
				filterProductTable(query);
			}
		});
		txtIngSorter.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				String query = txtIngSorter.getText().toLowerCase();
				filterIngredientTable(query);
			}
		});
//		txtSearchUsedIng.addKeyListener(new KeyAdapter() {
//			public void keyReleased(KeyEvent e) {
//				String query = txtSearchUsedIng.getText().toLowerCase();
//				filterUsage(query);
//			}
//		});
	}
	
	private void filterProductTable(String query) {
		productSorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
	}
	
	private void filterIngredientTable(String query) {
		ingredientSorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
	}
//	private void filterUsage(String query) {
//		UsageSorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
//	}
	
	public void loadTableProduct() {
		try {
			String productQuery = "SELECT Product_ID, Product_Name FROM product_tb";
			PreparedStatement pstProduct = conn.prepareStatement(productQuery);
			ResultSet rsProduct = pstProduct.executeQuery();
			productTableModel = DbUtils.resultSetToTableModel(rsProduct);
			tblProductID.setModel(productTableModel);
			productSorter = new TableRowSorter<>(productTableModel);
			tblProductID.setRowSorter(productSorter);
			pstProduct.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			String ingredientQuery = "SELECT IngredientID, Ingredient, Unit FROM ingredients";
			PreparedStatement pstIngredient = conn.prepareStatement(ingredientQuery);
			ResultSet rsIngredient = pstIngredient.executeQuery();
			ingredientTableModel = DbUtils.resultSetToTableModel(rsIngredient);
			tblIngUsage.setModel(ingredientTableModel);
			ingredientSorter = new TableRowSorter<>(ingredientTableModel);
			tblIngUsage.setRowSorter(ingredientSorter);
			pstIngredient.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}

	}
//*******************************Ingredients Usage**********************************************//
	public void IngredientUsage() {
	    PopulateInventory pp = new PopulateInventory(tblIngredients, tblIngredientUsage);

	    btnAddUsage.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            int IngselectedRow = tblIngUsage.getSelectedRow();
	            int ProdselectedRow = tblProductID.getSelectedRow();

	            if (IngselectedRow != -1 && ProdselectedRow != -1) {
	                DefaultTableModel ingModel = (DefaultTableModel) tblIngUsage.getModel();
	                DefaultTableModel prodModel = (DefaultTableModel) tblProductID.getModel();

	                Object InID = ingModel.getValueAt(IngselectedRow, 0);
	                Object ProID = prodModel.getValueAt(ProdselectedRow, 0);
	                String qtyUsed = txtQtyUsed.getText();

	                try {
	                    String insertQuery = "INSERT INTO ingredientusage (IngredientID, Product_ID, QuantityUsed) VALUES (?, ?, ?)";
	                    PreparedStatement insertPst = conn.prepareStatement(insertQuery);
	                    insertPst.setString(1, InID.toString());
	                    insertPst.setString(2, ProID.toString());
	                    insertPst.setString(3, qtyUsed);
	                    insertPst.executeUpdate();

	                    JOptionPane.showMessageDialog(null, "Ingredients successfully added.", "Success", JOptionPane.INFORMATION_MESSAGE);
	                    insertPst.close();

	                    pp.TblIngredientUsage();

	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                    JOptionPane.showMessageDialog(null, "An error occurred while adding the Ingredients: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	                }
	            } else {
	                if (IngselectedRow == -1) {
	                    JOptionPane.showMessageDialog(null, "Please select from table ingredients.");
	                } else {
	                    JOptionPane.showMessageDialog(null, "Please select from table products.");
	                }
	            }
	            
	        }
	    });
	    btnDeleteUsage.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            DefaultTableModel d1 = (DefaultTableModel) tblIngredientUsage.getModel();
	            int selectedIndex = tblIngredientUsage.getSelectedRow();
	            if (selectedIndex == -1) {
	                JOptionPane.showMessageDialog(null, "Please select a row to delete.");
	                return;
	            }
	            if (selectedIndex >= d1.getRowCount()) {
	                JOptionPane.showMessageDialog(null, "Invalid row index selected.");
	                return;
	            }
	            int id1 = Integer.parseInt(d1.getValueAt(selectedIndex, 0).toString());
	            int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Delete the Record", "Warning", JOptionPane.YES_NO_OPTION);

	            if (dialogResult == JOptionPane.YES_OPTION) {
	                try {
	                    String query = "DELETE FROM ingredientusage WHERE UsageID = ?";
	                    PreparedStatement pst = conn.prepareStatement(query);
	                    pst.setInt(1, id1);
	                    int rowsAffected = pst.executeUpdate();
	                    if (rowsAffected > 0) {
	                        JOptionPane.showMessageDialog(null, "Ingredient Usage Deleted.");
	                        pp.TblIngredientUsage();
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Error: Ingredient Usage not found or cannot be deleted.");
	                    }
	                } catch (SQLException ex) {
	                    if (ex.getErrorCode() == 1451) {
	                        JOptionPane.showMessageDialog(null, "Error: Cannot delete ingredient usage. It is referenced by other records.");
	                    } else {
	                        ex.printStackTrace();
	                    }
	                }
	            }
	        }
	    });

		//Update Ingredients
	    btnUpdateUsage.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            DefaultTableModel model = (DefaultTableModel) tblIngredientUsage.getModel();
	            int selectedIndex = tblIngredientUsage.getSelectedRow();
	            if (selectedIndex == -1) {
	                JOptionPane.showMessageDialog(null, "Please select a row to update.");
	                return;
	            }

	            int IngselectedRow = tblIngUsage.getSelectedRow();
	            int ProdselectedRow = tblProductID.getSelectedRow();

	            if (IngselectedRow != -1 && ProdselectedRow != -1) {
	                DefaultTableModel ingModel = (DefaultTableModel) tblIngUsage.getModel();
	                DefaultTableModel prodModel = (DefaultTableModel) tblProductID.getModel();

	                Object InID = ingModel.getValueAt(IngselectedRow, 0);
	                Object ProID = prodModel.getValueAt(ProdselectedRow, 0);
	                String qtyUsed = txtQtyUsed.getText();
	                int id = Integer.parseInt(model.getValueAt(selectedIndex, 0).toString());
	                int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Update the Record", "Message", JOptionPane.YES_NO_OPTION);

	                if (dialogResult == JOptionPane.YES_OPTION) {
	                    try {
	                        PreparedStatement pst = null;
	                        String query = "UPDATE ingredientusage SET IngredientID = ?, Product_ID = ?, QuantityUsed = ? WHERE UsageID = ?";
	                        pst = conn.prepareStatement(query);
	                        pst.setString(1, InID.toString());
	                        pst.setString(2, ProID.toString());
	                        pst.setString(3, qtyUsed);
	                        pst.setInt(4, id);
	                        int rowsUpdated = pst.executeUpdate();

	                        if (rowsUpdated > 0) {
	                            JOptionPane.showMessageDialog(null, "Successfully updated.");
	    	                    pp.TblIngredientUsage();
	                        } else {
	                            JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
	                        }
	                    } catch (Exception r) {
	                        r.printStackTrace();
	                    }
	                }
	            } else {
	                if (IngselectedRow == -1) {
	                    JOptionPane.showMessageDialog(null, "Please select from table ingredients.");
	                } else {
	                    JOptionPane.showMessageDialog(null, "Please select from table products.");
	                }
	            }
	        }
	    });
	}
}
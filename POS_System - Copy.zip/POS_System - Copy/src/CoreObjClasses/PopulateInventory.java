package CoreObjClasses;
/**
* @author: Marynelle
*/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;


import JDBConnectivity.JdbcConn;
import net.proteanit.sql.DbUtils;

public class PopulateInventory {
	private JTable tblIngredients, tblIngredientUsage;
    Connection conn = JdbcConn.connect();


	public PopulateInventory(JTable tblIngredients, JTable tblIngredientUsage) {
		this.tblIngredients = tblIngredients;
		this.tblIngredientUsage = tblIngredientUsage;

	}
//********************************Populate Table Ingredients********************************//
	public void TblIngredientsPopulate() {
		try {
	    PreparedStatement pst = conn.prepareStatement("SELECT * FROM ingredients");
	    ResultSet rs = pst.executeQuery();
	    tblIngredients.setModel(DbUtils.resultSetToTableModel(rs));
	    pst.close();
		} catch (SQLException e) {
		   e.printStackTrace();
		}
	}
	public void TblIngredientUsage() {
		try {
			PreparedStatement pst = conn.prepareStatement("SELECT u.UsageID, i.Ingredient, p.Product_Name, u.QuantityUsed, i.Unit "
				+ "FROM ingredients i "
				+ "INNER JOIN ingredientusage u ON i.IngredientID = u.IngredientID "
				+ "INNER JOIN product_tb p ON u.Product_ID = p.Product_ID");
			ResultSet rs = pst.executeQuery();
			tblIngredientUsage.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
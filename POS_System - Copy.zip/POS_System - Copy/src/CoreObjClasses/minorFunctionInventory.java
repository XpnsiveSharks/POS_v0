package CoreObjClasses;

import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.JTextField;


public class minorFunctionInventory {
	private JTextField txtIngredients, txtQty, txtUnit, txtPrice, txtQtyUsed;
	private JPanel paneManagement, paneInventory, paneCashier, paneLogout;
	public minorFunctionInventory(JTextField txtIngredients, JTextField txtQty, JTextField txtUnit, JTextField txtPrice,
			JTextField txtQtyUsed, JPanel paneManagement, JPanel paneInventory, JPanel paneCashier, JPanel paneLogout) {
		this.txtIngredients = txtIngredients;
		this.txtQty = txtQty;
		this.txtUnit = txtUnit;
		this.txtPrice = txtPrice;
		this.txtQtyUsed = txtQtyUsed;
		this.paneManagement = paneManagement;
		this.paneInventory = paneInventory;
		this.paneCashier = paneCashier;
		this.paneLogout = paneLogout;
	}
	public void menuPanels() {
		paneManagement.addMouseListener(new PanelButtonMouseAdapter(paneManagement) {
	        public void mouseClicked(MouseEvent e) {
	        }
	    });
		paneInventory.addMouseListener(new PanelButtonMouseAdapter(paneInventory) {
	        public void mouseClicked(MouseEvent e) {
	        }
	    });
		paneCashier.addMouseListener(new PanelButtonMouseAdapter(paneCashier) {
	        public void mouseClicked(MouseEvent e) {
	        }
	    });
		paneLogout.addMouseListener(new PanelButtonMouseAdapter(paneLogout) {
	        public void mouseClicked(MouseEvent e) {
	        }
	    });
		
	}
	private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel;
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(0, 100, 0));
		}
		@Override
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(89, 63, 14));
		}
		@Override
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(145, 234, 182));
		}
		@Override
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(89, 63, 14));
		}
		 
	}
	public void TextFields() {
		txtIngredients.addFocusListener(new JTextFieldFocusMouseAdapter(txtIngredients));
		txtQty.addFocusListener(new JTextFieldFocusMouseAdapter(txtQty));
		txtUnit.addFocusListener(new JTextFieldFocusMouseAdapter(txtUnit));
		txtPrice.addFocusListener(new JTextFieldFocusMouseAdapter(txtPrice));
		txtQtyUsed.addFocusListener(new JTextFieldFocusMouseAdapter(txtQtyUsed));

	}
	private class JTextFieldFocusMouseAdapter extends FocusAdapter {
	    JTextField jtextField;

	    public JTextFieldFocusMouseAdapter(JTextField jtextField) {
	        this.jtextField = jtextField;
	    }
	    @Override
	    public void focusGained(FocusEvent e) {
	        if (jtextField.getText().equals("Ingredients") || jtextField.getText().equals("Quantity")
	        		|| jtextField.getText().equals("Unit of Measurement")|| jtextField.getText().equals("Price") 
	        		|| jtextField.getText().equals("Quantity Used")){
	            jtextField.setText("");
	            return;
	        }
	    }

	    @Override
	    public void focusLost(FocusEvent e) {
	        if (jtextField.getText().equals("")) {
	            if (jtextField == txtIngredients) {
	                jtextField.setText("Ingredients");
	            } else if (jtextField == txtQty) {
	                jtextField.setText("Quantity");
	            } else if (jtextField == txtUnit) {
	                jtextField.setText("Unit of Measurement");
	            } else if (jtextField == txtPrice) {
	                jtextField.setText("Price");
	            } else if (jtextField == txtQtyUsed) {
	                jtextField.setText("Quantity Used");	       
	            }
	        }
	    }
	}
}

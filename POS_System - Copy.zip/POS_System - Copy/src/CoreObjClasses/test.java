package CoreObjClasses;

import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
import java.sql.ResultSetMetaData;


import JDBConnectivity.JdbcConn;
import net.proteanit.sql.DbUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;

public class test {
    private JTable tblOrders;
    Connection conn = JdbcConn.connect();

    public test(JTable tblOrders) {
        this.tblOrders = tblOrders;
    }

    public void updateTableData() {
        Object[][] newData = retrieveDataFromDatabase();

        // Create an instance of MyTableModel and set it as the model for tblOrders
        MyTableModel tableModel = new MyTableModel(newData, getColumnNames());
        tblOrders.setModel(tableModel);
    }

    public Object[][] retrieveDataFromDatabase() {
        // Retrieve data from the database and store it in a two-dimensional array
        Object[][] data = null;

        try {
            PreparedStatement pst = conn.prepareStatement("SELECT oi.order_item_id, p.Product_Name, oi.quantity, s.SugarLvl, ps.Product_Size, oi.price " +
                    "FROM product_tb AS p " +
                    "INNER JOIN order_items AS oi ON p.Product_ID = oi.item_id " +
                    "LEFT JOIN sizeandsugar AS ss ON oi.size_sugar_id = ss.size_sugar_id " +
                    "LEFT JOIN sugarlvl AS s ON ss.Sugar_Lvl_ID = s.Sugar_Lvl_ID " +
                    "LEFT JOIN product_size AS ps ON ss.Size_ID = ps.Size_ID"); // Replace with your SQL query
            ResultSet rs = pst.executeQuery();

            // Determine the number of rows in the ResultSet
            rs.last();
            int rowCount = rs.getRow();
            rs.beforeFirst();

            // Determine the number of columns in the ResultSet
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Create the data array
            data = new Object[rowCount][columnCount];

            // Populate the data array
            int row = 0;
            while (rs.next()) {
                for (int column = 0; column < columnCount; column++) {
                    data[row][column] = rs.getObject(column + 1);
                }
                row++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data;
    }

    private String[] getColumnNames() {
        String[] columnNames = {
            "id",
            "item",
            "qty",
            "sugar lvl",
            "size",
            "price"
        };
        return columnNames;
    }

    public class MyTableModel extends AbstractTableModel {
        private Object[][] data;
        private String[] columnNames;

        public MyTableModel(Object[][] data, String[] columnNames) {
            this.data = data;
            this.columnNames = columnNames;
        }

        @Override
        public int getRowCount() {
            return data.length;
        }

        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public Object getValueAt(int row, int column) {
            return data[row][column];
        }

        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }

        public void setData(Object[][] data) {
            this.data = data;
            fireTableDataChanged(); // Notify the table that the data has changed
        }
    }

    public void displayOrders() {
        try {
            // Execute the SQL query and retrieve the ResultSet
            PreparedStatement pst = conn.prepareStatement("SELECT oi.order_item_id, p.Product_Name, oi.quantity, s.SugarLvl, ps.Product_Size, oi.price " +
                    "FROM product_tb AS p " +
                    "INNER JOIN order_items AS oi ON p.Product_ID = oi.item_id " +
                    "LEFT JOIN sizeandsugar AS ss ON oi.size_sugar_id = ss.size_sugar_id " +
                    "LEFT JOIN sugarlvl AS s ON ss.Sugar_Lvl_ID = s.Sugar_Lvl_ID " +
                    "LEFT JOIN product_size AS ps ON ss.Size_ID = ps.Size_ID"); // Replace with your SQL query
            ResultSet rs = pst.executeQuery();

            // Convert the ResultSet to a TableModel using DbUtils
            TableModel model = DbUtils.resultSetToTableModel(rs);

            // Assign the model to the tblOrders instance variable
            tblOrders.setModel(model);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

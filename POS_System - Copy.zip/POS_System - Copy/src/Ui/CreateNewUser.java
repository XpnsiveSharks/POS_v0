package Ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;

import CoreObjClasses.PopulateProduct;
import JDBConnectivity.JdbcConn;
import net.proteanit.sql.DbUtils;

import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

public class CreateNewUser extends JDialog {
	private Image logo_des0 = new ImageIcon(CreateNewUser.class.getResource("/rss/icons8-ketchup-96.png")).getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);
	private final JPanel contentPanel = new JPanel();
	private JTextField txtUser;
	private JPasswordField pfPasscode;
	private JPasswordField pfReenterPass;
	private JLabel btnExit;
	private JButton btnCreateUser;
	private JComboBox comboBoxRole;
    Connection conn = JdbcConn.connect();
    private JLabel logoketsup;
    private JLabel lblNewLabel;
    private JTable table;
    private JScrollPane scrollPane;
    private JButton btnSecretDelete;


	public CreateNewUser() {
		setUndecorated(true);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Prince\\Pictures\\ss\\icons8-tea-bag-100 (1).png"));
		initComponents();
		CreateEvents();

	}
	private void initComponents() {
		setBounds(100, 100, 952, 499);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(54, 38, 8));
		contentPanel.setBorder(new LineBorder(new Color(255, 255, 255), 6));
		getContentPane().add(contentPanel, BorderLayout.CENTER);		
		contentPanel.setLayout(null);
		
		txtUser = new JTextField();
		txtUser.setSelectionColor(new Color(0, 100, 0));
		
		
		txtUser.setForeground(new Color(255, 255, 255));
		txtUser.setFont(new Font("Monospaced", Font.PLAIN, 14));
		txtUser.setText("User");
		txtUser.setBorder(new MatteBorder(0, 0, 10, 0, (Color) new Color(50, 205, 50)));
		txtUser.setBackground(new Color(54, 38, 8));
		txtUser.setBounds(669, 162, 203, 34);
		contentPanel.add(txtUser);
		txtUser.setColumns(10);
		
		pfPasscode = new JPasswordField();
		pfPasscode.setSelectionColor(new Color(0, 100, 0));
		pfPasscode.setEchoChar((char)0);

		pfPasscode.setForeground(new Color(255, 255, 255));
		pfPasscode.setText("Passcode");
		pfPasscode.setToolTipText("");
		pfPasscode.setFont(new Font("Monospaced", Font.PLAIN, 13));
		pfPasscode.setBorder(new MatteBorder(0, 0, 10, 0, (Color) new Color(218, 165, 32)));
		pfPasscode.setBackground(new Color(54, 38, 8));
		pfPasscode.setBounds(669, 208, 203, 34);
		contentPanel.add(pfPasscode);
		
		pfReenterPass = new JPasswordField();
		pfReenterPass.setSelectionColor(new Color(0, 100, 0));
		pfReenterPass.setEchoChar((char)0);

		pfReenterPass.setForeground(new Color(255, 255, 255));
		pfReenterPass.setToolTipText("");
		pfReenterPass.setText("Re-enter Passcode");
		pfReenterPass.setFont(new Font("Monospaced", Font.PLAIN, 13));
		pfReenterPass.setBorder(new MatteBorder(0, 0, 10, 0, (Color) new Color(165, 42, 42)));
		pfReenterPass.setBackground(new Color(54, 38, 8));
		pfReenterPass.setBounds(669, 254, 203, 34);
		contentPanel.add(pfReenterPass);
		
		btnCreateUser = new JButton("Create");
		
		
		btnCreateUser.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		btnCreateUser.setBackground(new Color(139, 69, 19));
		btnCreateUser.setForeground(new Color(255, 255, 255));
		btnCreateUser.setBounds(669, 316, 203, 34);
		contentPanel.add(btnCreateUser);
		
		btnExit = new JLabel("X");
		
		btnExit.setHorizontalAlignment(SwingConstants.CENTER);
		btnExit.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		btnExit.setForeground(new Color(255, 255, 255));
		btnExit.setBounds(920, 6, 26, 25);
		contentPanel.add(btnExit);
		
		comboBoxRole = new JComboBox();
		comboBoxRole.setModel(new DefaultComboBoxModel(new String[] {"", "Admin", "Employee"}));
		comboBoxRole.setBackground(new Color(139, 69, 19));
		comboBoxRole.setBounds(665, 124, 207, 34);
		contentPanel.add(comboBoxRole);
		
		logoketsup = new JLabel("");
		
		logoketsup.setHorizontalAlignment(SwingConstants.CENTER);
		logoketsup.setBounds(465, 99, 170, 300);
		contentPanel.add(logoketsup);
		logoketsup.setIcon(new ImageIcon(logo_des0));
		
		lblNewLabel = new JLabel("\"To view all the secrets, press the ketchup.\"");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Monospaced", Font.PLAIN, 12));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(374, 424, 364, 25);
		contentPanel.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(39, 19, 264, 381);
		contentPanel.add(scrollPane);
		scrollPane.setVisible(false);

		
		table = new JTable();
		table.setForeground(new Color(255, 255, 255));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Users", "Role"
			}
		));
		table.setSelectionBackground(new Color(0, 100, 0));
		table.setBackground(new Color(138, 112, 89));
		scrollPane.setViewportView(table);
		table.setVisible(false);

		
		btnSecretDelete = new JButton("Delete from Secrets");
		btnSecretDelete.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        DefaultTableModel model = (DefaultTableModel) table.getModel();
		        int selectedIndex = table.getSelectedRow();

		        if (selectedIndex == -1) {
		            JOptionPane.showMessageDialog(null, "Please select a row to delete.");
		            return;
		        }

		        String firstColumnValue = model.getValueAt(selectedIndex, 0).toString();
		        if (firstColumnValue.equals("root")) {
		            JOptionPane.showMessageDialog(null, "Deleting the 'root' user is not allowed.");
		            return;
		        }

		        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to delete the record?", "Warning", JOptionPane.YES_NO_OPTION);

		        if (dialogResult == JOptionPane.YES_OPTION) {
		            try {
		                Connection conn = JdbcConn.connect();
		                String query = "DELETE FROM admin WHERE user = ?";
		                PreparedStatement pst = conn.prepareStatement(query);
		                pst.setString(1, firstColumnValue);
		                pst.executeUpdate();
		                populateTable();
		                JOptionPane.showMessageDialog(null, "User deleted.");
		            } catch (SQLException r) {
		                JOptionPane.showMessageDialog(null, "Error: " + r.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		            }
		        }
		    }
		});

		btnSecretDelete.setForeground(new Color(255, 255, 255));
		btnSecretDelete.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnSecretDelete.setBackground(new Color(139, 69, 19));
		btnSecretDelete.setBounds(39, 404, 264, 34);
		contentPanel.add(btnSecretDelete);
		btnSecretDelete.setVisible(false);



	}
	private void CreateEvents() {
		txtUser.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(txtUser.getText().equals("User")) {
					txtUser.setText("");
				}else {
					txtUser.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(txtUser.getText().equals("")) {
					txtUser.setText("User");
				}
			}
		});
		pfPasscode.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(pfPasscode.getText().equals("Passcode")) {
					pfPasscode.setEchoChar('*');
					pfPasscode.setText("");
				}else {
					pfPasscode.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(pfPasscode.getText().equals("")) {
					pfPasscode.setText("Passcode");
					pfPasscode.setEchoChar((char)0);
				}
			}
		});
		pfReenterPass.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(pfReenterPass.getText().equals("Re-enter Passcode")) {
					pfReenterPass.setEchoChar('*');
					pfReenterPass.setText("");
				}else {
					pfReenterPass.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(pfReenterPass.getText().equals("")) {
					pfReenterPass.setText("Re-enter Passcode");
					pfReenterPass.setEchoChar((char)0);
				}
			}
		});
		
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				CreateNewUser.this.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				btnExit.setForeground(new Color(66, 245, 78));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnExit.setForeground(new Color(255, 255, 255));
			}
			@Override
			public void mousePressed(MouseEvent e) {
				btnExit.setForeground(new Color(138, 242, 145));

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				btnExit.setForeground(new Color(255, 255, 225));				
			}
			
		});
		btnCreateUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		//Create user method
		CreateNewAcc();
		logoketsup.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 table.setVisible(true);
			     scrollPane.setVisible(true);
				 btnSecretDelete.setVisible(true);

	                populateTable();

				}
			});
	}
	public void CreateNewAcc() {
	    btnCreateUser.addMouseListener(new MouseAdapter() {
	        @Override
	        public void mouseClicked(MouseEvent e) {
	            String username = txtUser.getText();
	            char[] passwordChars = pfPasscode.getPassword();
	            String password = new String(passwordChars);
	            String role = comboBoxRole.getSelectedItem().toString();
	            if (comboBoxRole.getSelectedItem().equals("")) {
	                JOptionPane.showMessageDialog(null, "please select a role!", "Error", JOptionPane.WARNING_MESSAGE);
	            	return;
	            }
	            if (txtUser.getText().equals("User")|| pfPasscode.getText().equals("Passcode")||pfReenterPass.getText().equals("Re-enter Passcode")|| comboBoxRole.getSelectedItem().equals("")) {
	                JOptionPane.showMessageDialog(null, "Please enter valid data!", "Error", JOptionPane.WARNING_MESSAGE);
	            	return;
	            }
	            
	            if (!Arrays.equals(pfPasscode.getPassword(), pfReenterPass.getPassword())) {
	                JOptionPane.showMessageDialog(null, "Passwords do not match!", "Error", JOptionPane.WARNING_MESSAGE);
	                return;
	            }
	    

	            if (checkUsernameExists(username)) {
	                JOptionPane.showMessageDialog(null, "Username already exists!", "Error", JOptionPane.ERROR_MESSAGE);
	                return; 
	            }

	            createUser(username, password, role);
	            JOptionPane.showMessageDialog(null, "User created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                populateTable();

	            txtUser.setText("User");
	            pfPasscode.setText("Passcode");
	            pfReenterPass.setText("Re-enter Passcode");
	            comboBoxRole.setSelectedIndex(0);
	        }
	    });
	}

	private boolean checkUsernameExists(String username) {
	    try {
	        String query = "SELECT COUNT(*) FROM admin WHERE user = ?";
	        PreparedStatement pst = conn.prepareStatement(query);
	        pst.setString(1, username);
	        ResultSet rs = pst.executeQuery();
	        
	        if (rs.next()) {
	            int count = rs.getInt(1);
	            return count > 0; 
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    
	    return false;
	}

	private void createUser(String username, String password, String role) {
	    try {
	        String query = "INSERT INTO admin (user, password, users) VALUES (?, ?, ?)";
	        PreparedStatement pst = conn.prepareStatement(query);
	        pst.setString(1, username);
	        pst.setString(2, password);
	        pst.setString(3, role);
	        pst.executeUpdate();
	        pst.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    
	}
	public void populateTable() {
				 try {
					    PreparedStatement pst = conn.prepareStatement("SELECT user, users FROM admin");
					    ResultSet rs = pst.executeQuery();
					    
					    DefaultTableModel model = (DefaultTableModel) table.getModel(); // Get the existing table model
					    
					    // Clear existing rows from the table
					    model.setRowCount(0);
					    
					    // Populate the table with data from the ResultSet
					    while (rs.next()) {
					        Object[] rowData = new Object[2];
					        rowData[0] = rs.getString("user");
					        rowData[1] = rs.getString("users");
					        model.addRow(rowData);
					    }
					    
					    pst.close();
					} catch (SQLException e1) {
					    e1.printStackTrace();
					    JOptionPane.showMessageDialog(null, "Failed to populate table product: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
			
	}
	public static void main(String[] args) {
		try {
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (Exception e) {
			
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				CreateNewUser frame = new CreateNewUser();
				frame.setVisible(true);
			}
		});
	}
}

package Ui;
/**
* @author: Marynelle
*/
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import javax.swing.border.MatteBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import CoreObjClasses.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
 
public class Inventory extends JFrame {
	private Image logo_ref = new ImageIcon(Inventory.class.getResource("/rss/refr.png")).getImage().getScaledInstance(35, 35, Image.SCALE_SMOOTH);
	private Image logo_des4 = new ImageIcon(Inventory.class.getResource("/rss/icons8-burger-94.png")).getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);
	private Image logo_des1 = new ImageIcon(Inventory.class.getResource("/rss/icons8-bubble-tea-100.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des2 = new ImageIcon(Inventory.class.getResource("/rss/icons8-bubble-tea-96.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private JPanel contentPane, pnlMenu, paneManagement, paneInventory, paneCashier, paneLogout, pnlMain;
	private JLabel lblManagement;
	private JTable tblIngredientUsage, tblIngredients;
	private JTextField txtIngredients, txtUnit, txtQty, txtPrice;
	private JButton btnAdd, btnUpdate, btnDelete;
	private JTable tblIngUsage;
	private JTable tblProductID;
	private JScrollPane scrollPane_2;
	private JTextField txtQtyUsed;
	private JButton btnAddUsage;
	private JButton btnUpdateUsage;
	private JButton btnDeleteUsage;
	private JScrollPane scrollPane_3;
	private JTextField txtProd;
	private JTextField txtIngSorter;
	private JLabel logoRefresh;
	private JLabel logoRefresh2;
	private JLabel logo1;
	private JLabel logo2;
	private JLabel logo3;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				        if ("Nimbus".equals(info.getName())) {
				            UIManager.setLookAndFeel(info.getClassName());
				            break;
				        }
				    }
				} catch (Exception e) {
				}
				Inventory frame = new Inventory();
                frame.setVisible(true);               
				 }
		   });
	}

	public Inventory() {
		Components();
		Events();
			
		
	}
	private void Events() {
		ActionInventory a = new ActionInventory(txtIngredients, txtQty, txtUnit,  txtPrice,
			 btnAdd, btnUpdate, btnDelete, tblIngredients, txtProd, tblProductID,  txtIngSorter,
			 tblIngUsage, btnAddUsage, btnUpdateUsage, btnDeleteUsage, txtQtyUsed, tblIngredientUsage
			 );
		a.InventoryFunction();
		a.loadTableProduct();
		a.filterProduct();
		a.IngredientUsage();
		
		PopulateInventory p = new PopulateInventory(tblIngredients, tblIngredientUsage);
		p.TblIngredientsPopulate();
		p.TblIngredientUsage();

		minorFunctionInventory m = new minorFunctionInventory(txtIngredients, txtQty, txtUnit, txtPrice,
			 txtQtyUsed, paneManagement, paneInventory, paneCashier, paneLogout);
		m.menuPanels();
		m.TextFields();
		
		paneLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Are you sure you want to Logout??") == 0) {
					Inventory.this.dispose();
                }
			}
		});
		paneManagement.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
            		Mods Inventory = new Mods();
            		Inventory.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
		paneInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
            		OverviewUI Inventory = new OverviewUI();
            		Inventory.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
		paneCashier.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
            		CashierUi Inventory = new CashierUi();
            		Inventory.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
	}
	private void Components() {		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1530, 810);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(54, 38, 8));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);		
		contentPane.setLayout(null);
				
		pnlMenu = new JPanel();
		pnlMenu.setBorder(new MatteBorder(0, 0, 0, 3, (Color) new Color(255, 255, 224)));
		pnlMenu.setBackground(new Color(54, 38, 8));
		pnlMenu.setBounds(0, 0, 546, 810);
		contentPane.add(pnlMenu);
		pnlMenu.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 203, 534, 601);
		pnlMenu.add(scrollPane);
		
		tblIngredients = new JTable();
		tblIngredients.setSelectionBackground(new Color(0, 100, 0));
		tblIngredients.setForeground(new Color(255, 250, 250));
		scrollPane.setViewportView(tblIngredients);
		tblIngredients.setBackground(new Color(89, 63, 14));
		
		txtIngredients = new JTextField();
		txtIngredients.setForeground(new Color(255, 255, 255));
		txtIngredients.setText("Ingredients");
		txtIngredients.setBounds(34, 71, 221, 32);
		pnlMenu.add(txtIngredients);
		txtIngredients.setBackground(Color.decode("#8a7059"));
		txtIngredients.setColumns(10);
		
		txtUnit = new JTextField();
		txtUnit.setForeground(new Color(255, 255, 255));
		txtUnit.setText("Unit of Measurement");
		txtUnit.setColumns(10);
		txtUnit.setBackground(new Color(138, 112, 89));
		txtUnit.setBounds(34, 113, 221, 32);
		pnlMenu.add(txtUnit);
		
		txtQty = new JTextField();
		txtQty.setForeground(new Color(255, 255, 255));
		txtQty.setText("Quantity");
		txtQty.setColumns(10);
		txtQty.setBackground(new Color(138, 112, 89));
		txtQty.setBounds(289, 71, 221, 32);
		pnlMenu.add(txtQty);
		
		txtPrice = new JTextField();
		txtPrice.setForeground(new Color(255, 255, 255));
		txtPrice.setText("Price");
		txtPrice.setColumns(10);
		txtPrice.setBackground(new Color(138, 112, 89));
		txtPrice.setBounds(289, 113, 221, 32);
		pnlMenu.add(txtPrice);
		
		JLabel lblNewLabel = new JLabel("INGRIDIENTS");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 25));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(95, 10, 356, 47);
		pnlMenu.add(lblNewLabel);
		
		btnAdd = new JButton("Add");
		btnAdd.setBackground(new Color(139, 69, 19));
		btnAdd.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnAdd.setForeground(new Color(255, 255, 255));
		btnAdd.setBounds(6, 153, 175, 40);
		pnlMenu.add(btnAdd);
		
		btnUpdate = new JButton("Update");
		btnUpdate.setForeground(Color.WHITE);
		btnUpdate.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnUpdate.setBackground(new Color(139, 69, 19));
		btnUpdate.setBounds(185, 153, 175, 40);
		pnlMenu.add(btnUpdate);
		
		btnDelete = new JButton("Delete");
		btnDelete.setForeground(Color.WHITE);
		btnDelete.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnDelete.setBackground(new Color(139, 69, 19));
		btnDelete.setBounds(365, 153, 175, 40);
		pnlMenu.add(btnDelete);
		
		logo2 = new JLabel("");
		logo2.setHorizontalAlignment(SwingConstants.CENTER);
		logo2.setBounds(34, 10, 65, 57);
		pnlMenu.add(logo2);
		logo2.setIcon(new ImageIcon(logo_des1));

		
		logo3 = new JLabel("");
		logo3.setHorizontalAlignment(SwingConstants.CENTER);
		logo3.setBounds(448, 10, 65, 57);
		pnlMenu.add(logo3);
		logo3.setIcon(new ImageIcon(logo_des2));

		
		pnlMain = new JPanel();
		pnlMain.setBounds(546, 47, 984, 763);
		pnlMain.setBackground(new Color(54, 38, 8));
		contentPane.add(pnlMain);
		pnlMain.setLayout(null);
		
		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(6, 276, 972, 481);
		pnlMain.add(scrollPane_3);
		
		tblIngredientUsage = new JTable();
		tblIngredientUsage.setSelectionBackground(new Color(0, 100, 0));
		tblIngredientUsage.setForeground(new Color(255, 250, 250));
		scrollPane_3.setViewportView(tblIngredientUsage);
		tblIngredientUsage.setBackground(new Color(89, 63, 14));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(6, 42, 354, 176);
		pnlMain.add(scrollPane_1);
		
		tblIngUsage = new JTable();
		tblIngUsage.setForeground(new Color(255, 255, 255));
		tblIngUsage.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
			}
		));
		scrollPane_1.setViewportView(tblIngUsage);
		tblIngUsage.setBackground(new Color(89, 63, 14));
		tblIngUsage.setSelectionBackground(new Color(0, 100, 0));
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(365, 42, 270, 176);
		pnlMain.add(scrollPane_2);
		
		tblProductID = new JTable();
		tblProductID.setForeground(new Color(255, 255, 255));
		tblProductID.setSelectionBackground(new Color(0, 100, 0));
		scrollPane_2.setViewportView(tblProductID);
		tblProductID.setBackground(new Color(89, 63, 14));
		
		txtQtyUsed = new JTextField();
		txtQtyUsed.setForeground(new Color(255, 255, 255));
		txtQtyUsed.setBackground(new Color(138, 112, 89));
		txtQtyUsed.setText("Quantity Used");
		txtQtyUsed.setBounds(6, 230, 148, 34);
		pnlMain.add(txtQtyUsed);
		txtQtyUsed.setColumns(10);
		
		btnAddUsage = new JButton("Add");
		btnAddUsage.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnAddUsage.setBackground(new Color(139, 69, 19));
		btnAddUsage.setForeground(new Color(255, 250, 250));
		btnAddUsage.setBounds(155, 230, 160, 34);
		pnlMain.add(btnAddUsage);
		
		btnUpdateUsage = new JButton("Update");
		btnUpdateUsage.setForeground(new Color(255, 250, 250));
		btnUpdateUsage.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnUpdateUsage.setBackground(new Color(139, 69, 19));
		btnUpdateUsage.setBounds(315, 230, 160, 34);
		pnlMain.add(btnUpdateUsage);
		
		btnDeleteUsage = new JButton("Delete");
		btnDeleteUsage.setForeground(new Color(255, 250, 250));
		btnDeleteUsage.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnDeleteUsage.setBackground(new Color(139, 69, 19));
		btnDeleteUsage.setBounds(475, 230, 160, 34);
		pnlMain.add(btnDeleteUsage);
		
		txtProd = new JTextField();
		txtProd.setForeground(new Color(255, 255, 255));
		txtProd.setBackground(new Color(138, 112, 89));
		txtProd.setBounds(365, 6, 270, 34);
		pnlMain.add(txtProd);
		txtProd.setColumns(10);
		
		txtIngSorter = new JTextField();
		txtIngSorter.setForeground(new Color(255, 255, 255));
		txtIngSorter.setBackground(new Color(138, 112, 89));
		txtIngSorter.setColumns(10);
		txtIngSorter.setBounds(6, 6, 354, 34);
		pnlMain.add(txtIngSorter);
		

		
//		logoRefresh = new JLabel("");
//		logoRefresh.setHorizontalAlignment(SwingConstants.CENTER);
//		logoRefresh.setBounds(325, 2, 35, 40);
//		pnlMain.add(logoRefresh);
//		logoRefresh.setIcon(new ImageIcon(logo_ref));
//		
//		logoRefresh2 = new JLabel("");
//		logoRefresh2.setHorizontalAlignment(SwingConstants.CENTER);
//		logoRefresh2.setBounds(600, 2, 35, 40);
//		pnlMain.add(logoRefresh2);
//		logoRefresh2.setIcon(new ImageIcon(logo_ref));
		
		logo1 = new JLabel("");
		logo1.setHorizontalAlignment(SwingConstants.CENTER);
		logo1.setBounds(647, 6, 331, 261);
		pnlMain.add(logo1);
		logo1.setIcon(new ImageIcon(logo_des4));

		


						
		paneManagement = new JPanel();
		
		paneManagement.setBounds(547, 10, 246, 37);
		contentPane.add(paneManagement);
						
		paneManagement.setLayout(null);
		paneManagement.setForeground(Color.WHITE);
		paneManagement.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneManagement.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneManagement.setBackground(new Color(89, 63, 14));
								
		lblManagement = new JLabel("MANAGE");
		lblManagement.setHorizontalAlignment(SwingConstants.CENTER);
		lblManagement.setForeground(Color.WHITE);
		lblManagement.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblManagement.setBounds(35, 5, 176, 27);
		paneManagement.add(lblManagement);
								
		paneInventory = new JPanel();
		
		paneInventory.setBounds(792, 10, 246, 37);
		contentPane.add(paneInventory);
								
		paneInventory.setLayout(null);
		paneInventory.setForeground(Color.WHITE);
		paneInventory.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneInventory.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneInventory.setBackground(new Color(89, 63, 14));
										
		JLabel lblInventory = new JLabel("OVERVIEW");
		lblInventory.setBounds(59, 5, 127, 27);
		paneInventory.add(lblInventory);
		lblInventory.setHorizontalAlignment(SwingConstants.CENTER);
		lblInventory.setForeground(Color.WHITE);
		lblInventory.setFont(new Font("Tahoma", Font.BOLD, 18));
										
		paneCashier = new JPanel();
		
		paneCashier.setBounds(1038, 10, 246, 37);
		contentPane.add(paneCashier);
		paneCashier.setLayout(null);
		paneCashier.setForeground(Color.WHITE);
		paneCashier.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneCashier.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneCashier.setBackground(new Color(89, 63, 14));
										
		JLabel lblCashier = new JLabel("CASHIER");
		lblCashier.setBounds(59, 5, 127, 27);
		paneCashier.add(lblCashier);
		lblCashier.setHorizontalAlignment(SwingConstants.CENTER);
		lblCashier.setForeground(Color.WHITE);
		lblCashier.setFont(new Font("Tahoma", Font.BOLD, 18));
										
		paneLogout = new JPanel();
		paneLogout.setBounds(1284, 10, 246, 37);
		contentPane.add(paneLogout);
		paneLogout.setLayout(null);
		paneLogout.setForeground(Color.WHITE);
		paneLogout.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneLogout.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneLogout.setBackground(new Color(89, 63, 14));
										
		JLabel lblLogout = new JLabel("LOGOUT");
		lblLogout.setBounds(59, 5, 127, 27);
		paneLogout.add(lblLogout);
		lblLogout.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogout.setForeground(Color.WHITE);
		lblLogout.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		}
	}

package Ui;
/**
* @author: Marynelle
*/
import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import JDBConnectivity.JdbcConn;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import javax.swing.JScrollPane;



public class Print extends JDialog {
	private Image logo_des1 = new ImageIcon(Print.class.getResource("/rss/icons8-bubble-tea-100.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des2 = new ImageIcon(Print.class.getResource("/rss/icons8-bubble-tea-96.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des3 = new ImageIcon(Print.class.getResource("/rss/icons8-drinking-64.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des4 = new ImageIcon(Print.class.getResource("/rss/icons8-green-tea-100.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);

	private final JPanel contentPanel = new JPanel();
	private JButton btnTest, btnPrint, btnCancel;
    Connection conn = JdbcConn.connect();
    private JTextArea textArea;

	public Print() {
		setUndecorated(true);
		initComponents();
		CreateEvents();
		
	}
	private void CreateEvents() {
		btnCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		btnTest.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        try {
		            String specificOrderId = null;
		            String lastInsertedIdQuery = "SELECT order_id FROM orders ORDER BY order_id DESC LIMIT 1";
		            Statement statement = conn.createStatement();
		            ResultSet resultSet = statement.executeQuery(lastInsertedIdQuery);
		            if (resultSet.next()) {
		                String orderId = resultSet.getString("order_id");
		                String numericId = orderId.substring(1);
		                int numericValue = Integer.parseInt(numericId);
		                specificOrderId = String.format("O%06d", numericValue);
		            }
		             
		            String query = "SELECT o.order_method, o.order_date, o.total_amount, p.Product_Name, oi.quantity, s.SugarLvl, ps.Product_Size, oi.size_fee, oi.price " +
		                    "FROM product_tb AS p " +
		                    "INNER JOIN order_items AS oi ON p.Product_ID = oi.item_id " +
		                    "LEFT JOIN sizeandsugar AS ss ON oi.size_sugar_id = ss.size_sugar_id " +
		                    "LEFT JOIN sugarlvl AS s ON ss.Sugar_Lvl_ID = s.Sugar_Lvl_ID " +
		                    "LEFT JOIN product_size AS ps ON ss.Size_ID = ps.Size_ID " +
		                    "INNER JOIN orders AS o ON oi.order_id = o.order_id " +
		                    "WHERE oi.order_id = ?";


		            try (PreparedStatement stmt = conn.prepareStatement(query)) {
		                stmt.setString(1, specificOrderId);

		                try (ResultSet rs = stmt.executeQuery()) {
		                    textArea.setText("***********************************************\n");
		                    textArea.append("*                    Receipt                  *\n");
		                    textArea.append("*                  POS System                 *\n");
		                    textArea.append("***********************************************\n");

		                    // Declare variables to store the total amount and order date
		                    double totalAmount = 0.0;
		                    String orderDate = "";


		                    // Iterate over the result set and append the data to the JTextArea
		                    while (rs.next()) {
		                        // Retrieve the values from the current row
		                        String productName = rs.getString("Product_Name");
		                        int quantity = rs.getInt("quantity");
		                        String sugarLevel = rs.getString("SugarLvl");
		                        String productSize = rs.getString("Product_Size");
		                        double sizeFee = rs.getDouble("size_fee");
		                        double price = rs.getDouble("price");
		                        totalAmount += price;

		                        if (orderDate.isEmpty()) {
		                            orderDate = rs.getString("order_date");
		                        }
		                        
		                        textArea.append(String.format("X "+quantity+"	"+productName +"..........₱"+"%.2f\n\n", price));
		                        textArea.append("SugarLvl   : " + sugarLevel + "\n\n");
		                        textArea.append(String.format("Product_Size: " + productSize +"..........₱"+"%.2f\n\n",sizeFee));

		                    }

	                        textArea.append(String.format("total"+"		"+"	  "+"₱"+"%.2f\n\n", totalAmount));
		                    textArea.append("..................................................\n");
		                    textArea.append("Date & Time: " + "	           "+orderDate + "\n\n");
		                    textArea.append("----------Thank you for Purchasing!!!----------");
		                    
		                }
		            }

		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		

		btnPrint.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try{
					textArea.print();
		        }catch(Exception e1){		        
		        }
			}
		});	
		
	}
	private void initComponents() {
		setBounds(15, 176, 576, 567);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(54, 38, 8));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		btnCancel = new JButton("Cancel");
		btnCancel.setBackground(new Color(139, 69, 19));
		btnCancel.setBounds(366, 530, 110, 31);
		contentPanel.add(btnCancel);
		
		btnPrint = new JButton("Print");
		btnPrint.setBackground(new Color(139, 69, 19));
		btnPrint.setBounds(244, 530, 110, 31);
		contentPanel.add(btnPrint);
		
		btnTest = new JButton("test");
		btnTest.setBounds(122, 530, 110, 31);
		contentPanel.add(btnTest);
		
		JLabel logo1 = new JLabel("");
		logo1.setHorizontalAlignment(SwingConstants.CENTER);
		logo1.setBounds(6, 12, 71, 68);
		contentPanel.add(logo1);
		logo1.setIcon(new ImageIcon(logo_des1));

		
		JLabel logo3 = new JLabel("");
		logo3.setHorizontalAlignment(SwingConstants.CENTER);
		logo3.setBounds(499, 475, 71, 68);
		contentPanel.add(logo3);
		logo3.setIcon(new ImageIcon(logo_des2));

		
		JLabel logo4 = new JLabel("");
		logo4.setHorizontalAlignment(SwingConstants.CENTER);
		logo4.setBounds(498, 264, 71, 68);
		contentPanel.add(logo4);
		logo4.setIcon(new ImageIcon(logo_des3));

		
		JLabel logo2 = new JLabel("");
		logo2.setHorizontalAlignment(SwingConstants.CENTER);
		logo2.setBounds(6, 217, 71, 68);
		contentPanel.add(logo2);
		logo2.setIcon(new ImageIcon(logo_des4));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(134, 12, 307, 508);
		contentPanel.add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 9));

		
	}
	public static void main(String[] args) {
		try {
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (Exception e) {
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				Print frame = new Print();
				frame.setVisible(true);
			}
		});
	}
}

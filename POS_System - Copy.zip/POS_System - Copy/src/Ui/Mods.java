package Ui;
/**
* @author: Marynelle
*/
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

import java.awt.Font;
import java.awt.Image;
import java.sql.ResultSet;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import javax.swing.border.MatteBorder;
import javax.swing.JTabbedPane;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import CoreObjClasses.*;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class Mods extends JFrame {
	private Image logo_genID = new ImageIcon(CashierUi.class.getResource("/rss/genCat.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);

	private JPanel contentPane;
	private JPanel pnlMenu;
	private JPanel paneProducts;
	private JPanel paneCategory;
	private JPanel paneAddOns;
	private JPanel paneSize;
	private JPanel paneSugarLvl;
	private JPanel paneCashier;
	private JPanel paneInventory;
	private JPanel paneOverview;
	private JPanel paneLogout;
	private JPanel pnlMain;
	private JTabbedPane tPaneMenu;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JPanel panel_5;
	private JLabel lblImg;
	private JButton btnChooseImg;
	private JTextField txtProductName;
	private JTextField txtProductId;
	private JComboBox cbxProdCategory;
	private JTextField txtPrice;
	private JTextField txtDescription;
	private JButton btnUpdate;
	private JTable tblProducts;
	private JScrollPane scrollPane;
	private JButton btnAdd;
	private JButton btnDelete;
	private JTextField txtCategoryId;
	private JTextField txtProductCategory;
	private JButton btnAddCategory;
	private JButton btnUpdateCategory;
	private JButton btnDeleteCategory;
	private JTextField txtAddOns;
	private JTextField txtAddOnsID;
	private JTable tblAddOns;
	private JScrollPane scrollPane_2;
	private JTextField txtAddOnsPrice;
	private JTable tblProdCategory;
	private JButton btnDeleteAddOns;
	private JButton btnUpdateAddOns;
	private JButton btnInsertAddOns;
	private JTextField txtSize;
	private JTextField txtSizePrice;
	private JButton btnAddSize;
	private JButton btnUpdateSize;
	private JButton btnDeleteSize;
	private JTable tblSize;
	private JTextField txtSugarLevel;
	private JButton btnAddSL;
	private JButton btnUpdateSL;
	private JButton btnDeleteSL;
	private JTable tblSugarLvl;
	private JScrollPane scrollPane_4;
	private JComboBox cbxAddOnsCat;
	private JLabel LblgenCat;
	private JLabel LblGenAO;
	private JLabel LblGenProd;
	private JTextField txtSugarQty;
	private JTextField txtSizePercentageAdded;


	
	public Mods() {
		Components();
		Events();
	}
	private void Events() {
		
		ActionProduct a = new ActionProduct(lblImg, cbxProdCategory, btnChooseImg, txtProductName,
			 txtProductId, txtPrice, txtDescription, btnAdd, btnUpdate,
			 btnDelete, tblProducts, txtCategoryId, txtProductCategory,
			 btnAddCategory, tblProdCategory, btnDeleteCategory, btnUpdateCategory,
			 tblAddOns, txtAddOnsID, txtAddOns, txtAddOnsPrice,
			 btnInsertAddOns, btnUpdateAddOns, btnDeleteAddOns, tblSize, txtSize, 
			 txtSizePrice, btnAddSize, btnUpdateSize, btnDeleteSize, tblSugarLvl, 
			 txtSugarLevel, btnAddSL, btnUpdateSL, btnDeleteSL, cbxAddOnsCat, LblgenCat, LblGenAO, LblGenProd,
			 txtSugarQty, txtSizePercentageAdded);
		a.ProductEvents();
		//ProdCatActions Function
		a.ProdCatActions();
		//Add-Ons Function
		a.AddOnsActions();
		//Product Size Function
		a.ProductSizeFunction();
		//Sugar Lvl Function
		a.SugarLevelFunction();
		//generate cat id
		a.GenerateOrderID();
		a.GenerateAoID();
		a.GeneratePrID();
//***************************************Populate functions****************************************//
		PopulateProduct pp = new PopulateProduct(cbxProdCategory, tblProducts, tblProdCategory, tblAddOns,
			 tblSize, tblSugarLvl, cbxAddOnsCat);
	    // Populate the combo box with categories
	    pp.CbxProdCategoryPopulate();
	    // Populate the table with product infos
	    pp.TblProductPopulate();
	    pp.TblProdCatPopulate();
	    pp.TblAddOnsPopulate();
	    pp.TblProdSizePopulate();
	    pp.TblSugarLvlPopulate();
	    pp.PopulateCbxAddOns();
//***************************************Lower Menu functions****************************************//
	    minorFunctions m = new minorFunctions(paneProducts, paneCategory, paneAddOns, paneSize,
			 paneSugarLvl, panel, paneCashier, paneInventory, paneOverview,
			 paneLogout, tPaneMenu, txtProductName, txtProductId,
			 txtPrice, txtDescription, txtCategoryId, txtProductCategory,
			 txtAddOnsID, txtAddOns, txtAddOnsPrice, txtSize,
			 txtSizePrice,  txtSugarLevel, txtSugarQty, txtSizePercentageAdded );
	    m.menuPanels();
	    m.TextFields();
	    paneLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Are you sure you want to Logout??") == 0) {
					Mods.this.dispose();
                }
			
			}
		});
	    paneCashier.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
            		CashierUi Mods = new CashierUi();
            		Mods.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
	    paneInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
            		Inventory Mods = new Inventory();
            		Mods.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
	    paneOverview.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
            		OverviewUI Mods = new OverviewUI();
            		Mods.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});

	}
	private void Components() {		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1530, 810);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(54, 38, 8));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);		
		contentPane.setLayout(null);

		pnlMenu = new JPanel();
		pnlMenu.setBorder(new MatteBorder(0, 0, 0, 3, (Color) new Color(255, 255, 224)));
		pnlMenu.setBackground(new Color(54, 38, 8));
		pnlMenu.setBounds(0, 0, 414, 810);
		contentPane.add(pnlMenu);
		pnlMenu.setLayout(null);
		
		tPaneMenu = new JTabbedPane(JTabbedPane.TOP);
		tPaneMenu.setBackground(new Color(54, 38, 8));
		tPaneMenu.setBounds(6, 0, 402, 804);
		pnlMenu.add(tPaneMenu);
		
		panel = new JPanel();
		panel.setBackground(new Color(54, 38, 8));
		tPaneMenu.addTab("Product", null, panel, null);
		panel.setLayout(null);
		
		panel_5 = new JPanel();
		panel_5.setBorder(new LineBorder(new Color(255, 255, 255), 2));
		panel_5.setBackground(new Color(54, 38, 8));
		panel_5.setBounds(56, 50, 284, 266);
		panel.add(panel_5);
		panel_5.setLayout(null);
		
		lblImg = new JLabel("CHOOSE IMAGE");
		lblImg.setBackground(new Color(54, 38, 8));
		lblImg.setBounds(0, 0, 284, 266);
		panel_5.add(lblImg);
		lblImg.setForeground(new Color(255, 255, 255));
		lblImg.setHorizontalAlignment(SwingConstants.CENTER);
		
		btnChooseImg = new JButton("Choose");
		btnChooseImg.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnChooseImg.setForeground(new Color(255, 255, 255));
		btnChooseImg.setBackground(new Color(139, 69, 19));
		btnChooseImg.setBounds(116, 326, 165, 36);
		panel.add(btnChooseImg);
		
		txtProductName = new JTextField();
		txtProductName.setForeground(new Color(255, 255, 255));
		txtProductName.setText("Product Name");
		txtProductName.setBounds(56, 477, 284, 36);
		txtProductName.setBackground(Color.decode("#8a7059"));
		
		panel.add(txtProductName);
		txtProductName.setColumns(10);
				
		cbxProdCategory = new JComboBox();
		cbxProdCategory.setBackground(new Color(54, 38, 8));
		cbxProdCategory.setBounds(56, 431, 284, 36);
		panel.add(cbxProdCategory);
				
		JLabel lblNewLabel_1 = new JLabel("Product Category");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(64, 402, 274, 30);
		panel.add(lblNewLabel_1);
				
		txtProductId = new JTextField();
		txtProductId.setForeground(new Color(255, 255, 255));
		txtProductId.setBackground(Color.decode("#8a7059"));
				
		txtProductId.setText("Product ID");
		txtProductId.setColumns(10);
		txtProductId.setBounds(56, 523, 284, 36);
		panel.add(txtProductId);
						
		txtPrice = new JTextField();
		txtPrice.setForeground(new Color(255, 255, 255));
		txtPrice.setBackground(Color.decode("#8a7059"));
		txtPrice.setText("Price");
		txtPrice.setColumns(10);
		txtPrice.setBounds(56, 571, 284, 36);
		panel.add(txtPrice);
						
		txtDescription = new JTextField();
		txtDescription.setForeground(new Color(255, 255, 255));
		txtDescription.setBackground(Color.decode("#8a7059"));
		txtDescription.setText("Description");
		txtDescription.setColumns(10);
		txtDescription.setBounds(56, 619, 284, 36);
		panel.add(txtDescription);
						
		btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnAdd.setForeground(new Color(255, 255, 255));
		btnAdd.setBackground(new Color(139, 69, 19));
		btnAdd.setBounds(116, 665, 165, 36);
		panel.add(btnAdd);
						
		btnUpdate = new JButton("Update");
		btnUpdate.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnUpdate.setBackground(new Color(139, 69, 19));
		btnUpdate.setForeground(new Color(255, 255, 255));
		btnUpdate.setBounds(24, 711, 165, 36);
		panel.add(btnUpdate);
						
		btnDelete = new JButton("Delete");
		btnDelete.setBackground(new Color(139, 69, 19));
		btnDelete.setForeground(new Color(255, 255, 255));
		btnDelete.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnDelete.setBounds(213, 711, 165, 36);
		panel.add(btnDelete);
						
		LblGenProd = new JLabel("");
		LblGenProd.setHorizontalAlignment(SwingConstants.CENTER);
		LblGenProd.setBounds(352, 523, 30, 36);
		panel.add(LblGenProd);
		LblGenProd.setIcon(new ImageIcon(logo_genID));
		
		panel_1 = new JPanel();
		panel_1.setBackground(new Color(54, 38, 8));
		tPaneMenu.addTab("Category", null, panel_1, null);
		panel_1.setLayout(null);
		
		txtCategoryId = new JTextField();
		txtCategoryId.setForeground(new Color(255, 255, 255));
		txtCategoryId.setText("Category ID");
		txtCategoryId.setColumns(10);
		txtCategoryId.setBounds(59, 12, 284, 36);
		txtCategoryId.setBackground(Color.decode("#8a7059"));

		panel_1.add(txtCategoryId);
		
		txtProductCategory = new JTextField();
		txtProductCategory.setForeground(new Color(255, 255, 255));
		txtProductCategory.setText("Product category");
		txtProductCategory.setColumns(10);
		txtProductCategory.setBounds(59, 54, 284, 36);
		txtProductCategory.setBackground(Color.decode("#8a7059"));
		panel_1.add(txtProductCategory);
		
		btnAddCategory = new JButton("Add");
		btnAddCategory.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnAddCategory.setForeground(new Color(255, 255, 255));
		btnAddCategory.setBackground(new Color(139, 69, 19));
		btnAddCategory.setBounds(4, 97, 128, 36);
		panel_1.add(btnAddCategory);
		
		btnUpdateCategory = new JButton("Update");
		btnUpdateCategory.setBackground(new Color(139, 69, 19));
		btnUpdateCategory.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnUpdateCategory.setForeground(new Color(255, 255, 255));
		btnUpdateCategory.setBounds(136, 97, 128, 36);
		panel_1.add(btnUpdateCategory);
		
		btnDeleteCategory = new JButton("Delete");
		btnDeleteCategory.setForeground(new Color(255, 255, 255));
		btnDeleteCategory.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnDeleteCategory.setBackground(new Color(139, 69, 19));
		btnDeleteCategory.setBounds(268, 97, 128, 36);
		panel_1.add(btnDeleteCategory);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 144, 382, 618);
		panel_1.add(scrollPane_1);
		
		tblProdCategory = new JTable();
		JTableHeader header2 = tblProdCategory.getTableHeader();
		header2.setReorderingAllowed(false);
		tblProdCategory.setSelectionBackground(new Color(0, 100, 0));
		tblProdCategory.setForeground(new Color(255, 255, 255));
		tblProdCategory.setBackground(new Color(89, 63, 14));
		scrollPane_1.setViewportView(tblProdCategory);
		
		LblgenCat = new JLabel("");
		LblgenCat.setHorizontalAlignment(SwingConstants.CENTER);
		LblgenCat.setBounds(354, 12, 30, 36);
		panel_1.add(LblgenCat);
		LblgenCat.setIcon(new ImageIcon(logo_genID));
		
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(54, 38, 8));
		tPaneMenu.addTab("Add-ons", null, panel_2, null);
		panel_2.setLayout(null);
		
		txtAddOns = new JTextField();
		txtAddOns.setForeground(new Color(255, 255, 255));
		txtAddOns.setText("Add-On");
		txtAddOns.setColumns(10);
		txtAddOns.setBounds(61, 92, 284, 36);
		txtAddOns.setBackground(Color.decode("#8a7059"));

		panel_2.add(txtAddOns);
		
		txtAddOnsID = new JTextField();
		txtAddOnsID.setForeground(new Color(255, 255, 255));
		txtAddOnsID.setText("Add-On ID");
		txtAddOnsID.setColumns(10);
		txtAddOnsID.setBounds(61, 12, 284, 36);
		txtAddOnsID.setBackground(Color.decode("#8a7059"));
		panel_2.add(txtAddOnsID);
		
		btnUpdateAddOns = new JButton("Update");
		btnUpdateAddOns.setBackground(new Color(139, 69, 19));
		btnUpdateAddOns.setBounds(137, 182, 128, 36);
		panel_2.add(btnUpdateAddOns);
		
		btnInsertAddOns = new JButton("Add");
		btnInsertAddOns.setBackground(new Color(139, 69, 19));
		btnInsertAddOns.setBounds(5, 182, 128, 36);
		panel_2.add(btnInsertAddOns);
		
		btnDeleteAddOns = new JButton("Delete");
		btnDeleteAddOns.setBackground(new Color(139, 69, 19));
		btnDeleteAddOns.setBounds(269, 182, 128, 36);
		panel_2.add(btnDeleteAddOns);
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(5, 230, 392, 538);
		panel_2.add(scrollPane_2);
		
		tblAddOns = new JTable();
		tblAddOns.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column"
			}
		));
		tblAddOns.setSelectionBackground(new Color(0, 100, 0));
		tblAddOns.setForeground(new Color(255, 255, 255));
		scrollPane_2.setViewportView(tblAddOns);
		tblAddOns.setBackground(new Color(89, 63, 14));
		
		txtAddOnsPrice = new JTextField();
		txtAddOnsPrice.setForeground(new Color(255, 255, 255));
		txtAddOnsPrice.setText("Price");
		txtAddOnsPrice.setColumns(10);
		txtAddOnsPrice.setBounds(61, 134, 284, 36);
		txtAddOnsPrice.setBackground(Color.decode("#8a7059"));

		panel_2.add(txtAddOnsPrice);
		
		cbxAddOnsCat = new JComboBox();
		cbxAddOnsCat.setBackground(new Color(54, 38, 8));
		cbxAddOnsCat.setBounds(61, 50, 284, 36);
		panel_2.add(cbxAddOnsCat);
		
		LblGenAO = new JLabel("");
		LblGenAO.setHorizontalAlignment(SwingConstants.CENTER);
		LblGenAO.setBounds(357, 12, 30, 36);
		panel_2.add(LblGenAO);
		LblGenAO.setIcon(new ImageIcon(logo_genID));
		
		panel_3 = new JPanel();
		panel_3.setBackground(new Color(54, 38, 8));
		tPaneMenu.addTab("Size", null, panel_3, null);
		panel_3.setLayout(null);
		
		txtSize = new JTextField();
		txtSize.setForeground(new Color(255, 255, 255));
		txtSize.setText("Product Size");
		txtSize.setColumns(10);
		txtSize.setBounds(50, 6, 284, 36);
		txtSize.setBackground(Color.decode("#8a7059"));
		panel_3.add(txtSize);
		
		txtSizePrice = new JTextField();
		txtSizePrice.setForeground(new Color(255, 255, 255));
		txtSizePrice.setText("Price");
		txtSizePrice.setColumns(10);
		txtSizePrice.setBounds(50, 54, 284, 36);
		txtSizePrice.setBackground(Color.decode("#8a7059"));
		panel_3.add(txtSizePrice);
		
		btnAddSize = new JButton("Add");
		btnAddSize.setForeground(new Color(255, 255, 255));
		btnAddSize.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnAddSize.setBackground(new Color(139, 69, 19));
		btnAddSize.setBounds(4, 151, 128, 36);
		panel_3.add(btnAddSize);
		
		btnUpdateSize = new JButton("Update");
		btnUpdateSize.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnUpdateSize.setBackground(new Color(139, 69, 19));
		btnUpdateSize.setForeground(new Color(255, 255, 255));
		btnUpdateSize.setBounds(136, 151, 128, 36);
		panel_3.add(btnUpdateSize);
		
		btnDeleteSize = new JButton("Delete");
		btnDeleteSize.setBackground(new Color(139, 69, 19));
		btnDeleteSize.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnDeleteSize.setForeground(new Color(255, 255, 255));
		btnDeleteSize.setBounds(268, 151, 128, 36);
		panel_3.add(btnDeleteSize);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(6, 199, 390, 531);
		panel_3.add(scrollPane_3);
		
		tblSize = new JTable();
		tblSize.setForeground(new Color(255, 255, 255));
		tblSize.setSelectionBackground(new Color(0, 100, 0));
		tblSize.setBackground(new Color(89, 63, 14));
		scrollPane_3.setViewportView(tblSize);
		
		txtSugarQty = new JTextField();
		txtSugarQty.setForeground(new Color(255, 255, 255));
		txtSugarQty.setBounds(50, 102, 284, 36);
		txtSugarQty.setText("Sugar Qty");
		txtSugarQty.setBackground(Color.decode("#8a7059"));
		panel_3.add(txtSugarQty);
		txtSugarQty.setColumns(10);
		
		panel_4 = new JPanel();
		panel_4.setBackground(new Color(54, 38, 8));
		tPaneMenu.addTab("Sugar lvl", null, panel_4, null);
		panel_4.setLayout(null);
		
		txtSugarLevel = new JTextField();
		txtSugarLevel.setForeground(new Color(255, 255, 255));
		txtSugarLevel.setText("Sugar Level");
		txtSugarLevel.setColumns(10);
		txtSugarLevel.setBounds(50, 16, 284, 36);
		txtSugarLevel.setBackground(Color.decode("#8a7059"));
		panel_4.add(txtSugarLevel);
		
		btnAddSL = new JButton("Add");
		btnAddSL.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnAddSL.setForeground(new Color(255, 255, 255));
		btnAddSL.setBackground(new Color(139, 69, 19));
		btnAddSL.setBounds(6, 108, 128, 36);
		panel_4.add(btnAddSL);
		
		btnUpdateSL = new JButton("Update");
		btnUpdateSL.setBackground(new Color(139, 69, 19));
		btnUpdateSL.setForeground(new Color(255, 255, 255));
		btnUpdateSL.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnUpdateSL.setBounds(138, 108, 128, 36);
		panel_4.add(btnUpdateSL);
		
		btnDeleteSL = new JButton("Delete");
		btnDeleteSL.setForeground(new Color(255, 255, 255));
		btnDeleteSL.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnDeleteSL.setBackground(new Color(139, 69, 19));
		btnDeleteSL.setBounds(270, 108, 128, 36);
		panel_4.add(btnDeleteSL);
		
		scrollPane_4 = new JScrollPane();
		scrollPane_4.setBackground(new Color(54, 38, 8));
		scrollPane_4.setBounds(6, 156, 390, 569);
		panel_4.add(scrollPane_4);
		
		tblSugarLvl = new JTable();
		tblSugarLvl.setForeground(new Color(255, 255, 255));
		tblSugarLvl.setSelectionBackground(new Color(0, 100, 0));
		tblSugarLvl.setBackground(new Color(89, 63, 14));
		scrollPane_4.setViewportView(tblSugarLvl);
		
		txtSizePercentageAdded = new JTextField();
		txtSizePercentageAdded.setForeground(new Color(255, 255, 255));
		txtSizePercentageAdded.setBounds(50, 64, 284, 36);
		txtSizePercentageAdded.setText("Size percentage Added");
		txtSizePercentageAdded.setBackground(Color.decode("#8a7059"));
		panel_4.add(txtSizePercentageAdded);
		txtSizePercentageAdded.setColumns(10);
		
		paneProducts = new JPanel();
		paneProducts.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneProducts.setBackground(new Color(89, 63, 14));
		paneProducts.setForeground(new Color(255, 255, 255));
		paneProducts.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneProducts.setBounds(414, 763, 224, 37);
		contentPane.add(paneProducts);
		paneProducts.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PRODUCT");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(47, 5, 127, 27);
		paneProducts.add(lblNewLabel);
		
		paneCategory = new JPanel();
		paneCategory.setLayout(null);
		paneCategory.setForeground(Color.WHITE);
		paneCategory.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneCategory.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneCategory.setBackground(new Color(89, 63, 14));
		paneCategory.setBounds(634, 763, 224, 37);
		contentPane.add(paneCategory);
		
		JLabel lblAddons = new JLabel("CATEGORY");
		lblAddons.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddons.setForeground(Color.WHITE);
		lblAddons.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAddons.setBounds(47, 5, 127, 27);
		paneCategory.add(lblAddons);
		
		paneAddOns = new JPanel();
		paneAddOns.setLayout(null);
		paneAddOns.setForeground(Color.WHITE);
		paneAddOns.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneAddOns.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneAddOns.setBackground(new Color(89, 63, 14));
		paneAddOns.setBounds(858, 763, 224, 37);
		contentPane.add(paneAddOns);
		
		JLabel lblC = new JLabel("ADD-ONS");
		lblC.setHorizontalAlignment(SwingConstants.CENTER);
		lblC.setForeground(Color.WHITE);
		lblC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblC.setBounds(47, 5, 127, 27);
		paneAddOns.add(lblC);
		
		paneSize = new JPanel();
		paneSize.setLayout(null);
		paneSize.setForeground(Color.WHITE);
		paneSize.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneSize.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneSize.setBackground(new Color(89, 63, 14));
		paneSize.setBounds(1082, 763, 224, 37);
		contentPane.add(paneSize);
		
		JLabel lblSize = new JLabel("SIZE");
		lblSize.setHorizontalAlignment(SwingConstants.CENTER);
		lblSize.setForeground(Color.WHITE);
		lblSize.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSize.setBounds(47, 5, 127, 27);
		paneSize.add(lblSize);
		
		paneSugarLvl = new JPanel();
		paneSugarLvl.setLayout(null);
		paneSugarLvl.setForeground(Color.WHITE);
		paneSugarLvl.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneSugarLvl.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneSugarLvl.setBackground(new Color(89, 63, 14));
		paneSugarLvl.setBounds(1306, 763, 224, 37);
		contentPane.add(paneSugarLvl);
		
		JLabel lblSugarLvl = new JLabel("SUGAR LVL");
		lblSugarLvl.setHorizontalAlignment(SwingConstants.CENTER);
		lblSugarLvl.setForeground(Color.WHITE);
		lblSugarLvl.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSugarLvl.setBounds(47, 5, 127, 27);
		paneSugarLvl.add(lblSugarLvl);
		
		pnlMain = new JPanel();
		pnlMain.setBounds(414, 47, 1116, 717);
		pnlMain.setBackground(new Color(54, 38, 8));
		contentPane.add(pnlMain);
		pnlMain.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setBackground(new Color(54, 58, 63));
		scrollPane.setBounds(10, 10, 1096, 697);
		pnlMain.add(scrollPane);
		
		tblProducts = new JTable();
		JTableHeader header1 = tblProducts.getTableHeader();
		header1.setReorderingAllowed(false);
		tblProducts.setModel(new DefaultTableModel(
			new Object[][] {
				{},
			},
			new String[] {
			}
		));
		tblProducts.setSelectionBackground(new Color(0, 100, 0));
		tblProducts.setForeground(new Color(255, 255, 255));
		scrollPane.setViewportView(tblProducts);
		tblProducts.setBackground(new Color(89, 63, 14));
						
		paneCashier = new JPanel();
		
		paneCashier.setBounds(414, 10, 279, 37);
		contentPane.add(paneCashier);
						
		paneCashier.setLayout(null);
		paneCashier.setForeground(Color.WHITE);
		paneCashier.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneCashier.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneCashier.setBackground(new Color(89, 63, 14));
								
		JLabel lblCashier = new JLabel("CASHIER");
		lblCashier.setHorizontalAlignment(SwingConstants.CENTER);
		lblCashier.setForeground(Color.WHITE);
		lblCashier.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblCashier.setBounds(71, 5, 127, 27);
		paneCashier.add(lblCashier);
								
		paneInventory = new JPanel();
		
		paneInventory.setBounds(693, 10, 279, 37);
		contentPane.add(paneInventory);
								
		paneInventory.setLayout(null);
		paneInventory.setForeground(Color.WHITE);
		paneInventory.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneInventory.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneInventory.setBackground(new Color(89, 63, 14));
										
		JLabel lblInventory = new JLabel("INVENTORY");
		lblInventory.setBounds(76, 5, 127, 27);
		paneInventory.add(lblInventory);
		lblInventory.setHorizontalAlignment(SwingConstants.CENTER);
		lblInventory.setForeground(Color.WHITE);
		lblInventory.setFont(new Font("Tahoma", Font.BOLD, 18));
										
		paneOverview = new JPanel();
		
		paneOverview.setBounds(972, 10, 279, 37);
		contentPane.add(paneOverview);
		paneOverview.setLayout(null);
		paneOverview.setForeground(Color.WHITE);
		paneOverview.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneOverview.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneOverview.setBackground(new Color(89, 63, 14));
										
		JLabel lblOverview = new JLabel("OVERVIEW");
		lblOverview.setBounds(76, 5, 127, 27);
		paneOverview.add(lblOverview);
		lblOverview.setHorizontalAlignment(SwingConstants.CENTER);
		lblOverview.setForeground(Color.WHITE);
		lblOverview.setFont(new Font("Tahoma", Font.BOLD, 18));
										
		paneLogout = new JPanel();
		
		paneLogout.setBounds(1251, 10, 279, 37);
		contentPane.add(paneLogout);
		paneLogout.setLayout(null);
		paneLogout.setForeground(Color.WHITE);
		paneLogout.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneLogout.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneLogout.setBackground(new Color(89, 63, 14));
										
		JLabel lblLogout = new JLabel("LOGOUT");
		lblLogout.setBounds(76, 5, 127, 27);
		paneLogout.add(lblLogout);
		lblLogout.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogout.setForeground(Color.WHITE);
		lblLogout.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				        if ("Nimbus".equals(info.getName())) {
				            UIManager.setLookAndFeel(info.getClassName());
				            break;
				        }
				    }
				} catch (Exception e) {
				}
				Mods frame = new Mods();
                frame.setVisible(true);               
				 }
		   });
	}

	}

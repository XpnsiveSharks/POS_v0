package Ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import javax.swing.border.MatteBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuBar;
 
public class copy extends JFrame {

	private JPanel contentPane;
	private JPanel pnlMenu;
	private JPanel paneCashier;
	private JPanel paneInventory;
	private JPanel paneOverview;
	private JPanel paneLogout;
	private JPanel pnlMain;
	private JLabel lblManagement;


//	


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				        if ("Nimbus".equals(info.getName())) {
				            UIManager.setLookAndFeel(info.getClassName());
				            break;
				        }
				    }
				} catch (Exception e) {
				}
				copy frame = new copy();
                frame.setVisible(true);               
				 }
		   });
	}

	/**
	 * Create the frame.
	 */
	public copy() {
		Events();
		Components();
		
	
		
	}
	private void Events() {
		
	}
	private void Components() {		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1530, 810);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(54, 38, 8));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);		
		contentPane.setLayout(null);
		
		
		pnlMenu = new JPanel();
		pnlMenu.setBorder(new MatteBorder(0, 0, 0, 3, (Color) new Color(255, 255, 224)));
		pnlMenu.setBackground(new Color(54, 38, 8));
		pnlMenu.setBounds(0, 0, 414, 810);
		contentPane.add(pnlMenu);
		pnlMenu.setLayout(null);
		
		pnlMain = new JPanel();
		pnlMain.setBounds(414, 47, 1116, 763);
		pnlMain.setBackground(new Color(54, 38, 8));
		contentPane.add(pnlMain);
		pnlMain.setLayout(null);
						
		paneCashier = new JPanel();
		paneCashier.setBounds(414, 10, 279, 37);
		contentPane.add(paneCashier);
						
		paneCashier.setLayout(null);
		paneCashier.setForeground(Color.WHITE);
		paneCashier.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneCashier.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneCashier.setBackground(new Color(89, 63, 14));
								
		lblManagement = new JLabel("MANAGEMENT");
		lblManagement.setHorizontalAlignment(SwingConstants.CENTER);
		lblManagement.setForeground(Color.WHITE);
		lblManagement.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblManagement.setBounds(51, 5, 176, 27);
		paneCashier.add(lblManagement);
								
		paneInventory = new JPanel();
		paneInventory.setBounds(693, 10, 279, 37);
		contentPane.add(paneInventory);
								
		paneInventory.setLayout(null);
		paneInventory.setForeground(Color.WHITE);
		paneInventory.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneInventory.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneInventory.setBackground(new Color(89, 63, 14));
										
		JLabel lblInventory = new JLabel("OVERVIEW");
		lblInventory.setBounds(76, 5, 127, 27);
		paneInventory.add(lblInventory);
		lblInventory.setHorizontalAlignment(SwingConstants.CENTER);
		lblInventory.setForeground(Color.WHITE);
		lblInventory.setFont(new Font("Tahoma", Font.BOLD, 18));
										
		paneOverview = new JPanel();
		paneOverview.setBounds(972, 10, 279, 37);
		contentPane.add(paneOverview);
		paneOverview.setLayout(null);
		paneOverview.setForeground(Color.WHITE);
		paneOverview.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneOverview.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneOverview.setBackground(new Color(89, 63, 14));
										
		JLabel lblCashier = new JLabel("CASHIER");
		lblCashier.setBounds(76, 5, 127, 27);
		paneOverview.add(lblCashier);
		lblCashier.setHorizontalAlignment(SwingConstants.CENTER);
		lblCashier.setForeground(Color.WHITE);
		lblCashier.setFont(new Font("Tahoma", Font.BOLD, 18));
										
		paneLogout = new JPanel();
		paneLogout.setBounds(1251, 10, 279, 37);
		contentPane.add(paneLogout);
		paneLogout.setLayout(null);
		paneLogout.setForeground(Color.WHITE);
		paneLogout.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneLogout.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneLogout.setBackground(new Color(89, 63, 14));
										
		JLabel lblLogout = new JLabel("LOGOUT");
		lblLogout.setBounds(76, 5, 127, 27);
		paneLogout.add(lblLogout);
		lblLogout.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogout.setForeground(Color.WHITE);
		lblLogout.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		}
	}

var searchData=
[
  ['cashierui_0',['CashierUi',['../class_ui_1_1_cashier_ui.html',1,'Ui']]],
  ['copy_1',['copy',['../class_ui_1_1copy.html#a5c9a3fd20d8ffe68e402080d7310e0c6',1,'Ui.copy.copy()'],['../class_ui_1_1copy.html',1,'Ui.copy']]],
  ['createnewuser_2',['CreateNewUser',['../class_ui_1_1_create_new_user.html',1,'Ui']]]
];

package Ui;
//this line of codes are the important imports for this class to run
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;

import JDBConnectivity.JdbcConn;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
public class Login extends JFrame {
/*This code  below demonstrates the process of loading an image file from a resource location and resizing it to a specific width and 
 * height in pixels. The resulting image is then stored in a variable and can be utilized for different purposes within the OverviewUI 
 * class or any other location where these variables are accessible.
 */
	private Image logo_des0 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-baguette-64.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des1 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-bubble-tea-100.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des2 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-bubble-tea-96.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des3 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-drinking-64.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des4 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-burger-94.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des5 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-kawaii-milk-100.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des6 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-donut-96.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des7 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-taco-64.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des8 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-milk-bottle-80.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des9 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-metal-straw-64.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des10 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-coffee-to-go-80.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des11 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-burger-100.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	private Image logo_des12 = new ImageIcon(OverviewUI.class.getResource("/rss/icons8-bubble-tea-96.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);

	private JPanel contentPane;
	private JPanel pnlMenu;
	private JPanel pnlMain;
	private JTextField txtUser;
	private JButton btnNewButton;
    Connection conn = JdbcConn.connect();
    private JPasswordField pwdPasscode;
    private JLabel logo1;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;
    private JLabel logo6;
    private JLabel logo7;
    private JLabel logo8;
    private JLabel logo9;
    private JLabel logo10;
    private JLabel logo11;
    private JLabel logo12;
    private JLabel logo13;
    private JLabel lblNewLabel_2;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				        if ("Nimbus".equals(info.getName())) {
				            UIManager.setLookAndFeel(info.getClassName());
				            break;
				        }
				    }
				} catch (Exception e) {
				}
				Login frame = new Login();
                frame.setVisible(true);               
				 }
		   });
	}

	public Login() {
		//method invocation
		Components();
		Events();	
	} 
	private void Events() {
		//This code checks if the entered credentials match a record in the "admin" table.
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String username = txtUser.getText();
	            char[] passwordChars = pwdPasscode.getPassword();
	            String password = new String(passwordChars);
	            try {
	                String query = "SELECT * FROM admin WHERE user = ? AND password = ?";
	                PreparedStatement statement = conn.prepareStatement(query);
	                statement.setString(1, username);
	                statement.setString(2, password);

	                ResultSet resultSet = statement.executeQuery();
	                if (resultSet.next()) {
	                	try {
	                		OverviewUI Login = new OverviewUI();
	                		Login.setVisible(true);
	    				} catch (Exception e1) {
	    					e1.printStackTrace();
	    				}
	    				dispose();
	                } else {
	                    JOptionPane.showMessageDialog(null, "Invalid username or password. "
	                    		+ "Please try again or sign up for a new account.");
	                }

	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
			}
			});
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login.this.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel.setForeground(new Color(66, 245, 78));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel.setForeground(new Color(255, 255, 255));
			}
			@Override
			public void mousePressed(MouseEvent e) {
				lblNewLabel.setForeground(new Color(138, 242, 145));
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				lblNewLabel.setForeground(new Color(255, 255, 225));
	
			}
		});
		
		txtUser.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(txtUser.getText().equals("User")) {
					txtUser.setText("");
				}else {
					txtUser.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(txtUser.getText().equals("")) {
					txtUser.setText("User");
				}
			}
		});
		pwdPasscode.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(pwdPasscode.getText().equals("Passcode")) {
				pwdPasscode.setEchoChar('*');
				pwdPasscode.setText("");
			}else {
				pwdPasscode.selectAll();
			}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(pwdPasscode.getText().equals("")) {
					pwdPasscode.setText("Passcode");
					pwdPasscode.setEchoChar((char)0);
				}
			}
		});
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_2.setForeground(new Color(66, 245, 78));

			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_2.setForeground(new Color(255, 255, 255));
			}
			@Override
			public void mousePressed(MouseEvent e) {
				lblNewLabel_2.setForeground(new Color(138, 242, 145));

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				lblNewLabel_2.setForeground(new Color(255, 255, 225));

			}
			@Override
			public void mouseClicked(MouseEvent e) {
				//method invocation
				MethodCreateNewUser();
			}
		});
	}
	private void Components() {		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1530, 810);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(54, 38, 8));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);		
		contentPane.setLayout(null);
		
		pnlMain = new JPanel();
		pnlMain.setBounds(6, 0, 1197, 810);
		pnlMain.setBackground(new Color(54, 38, 8));
		contentPane.add(pnlMain);
		pnlMain.setLayout(null);
		
		logo1 = new JLabel("");
		logo1.setHorizontalAlignment(SwingConstants.CENTER);
		logo1.setBounds(53, 80, 135, 131);
		pnlMain.add(logo1);
	//This code demonstrates how to use the stored image variables. 
		logo1.setIcon(new ImageIcon(logo_des0));
		
		JLabel logo2 = new JLabel("");
		logo2.setHorizontalAlignment(SwingConstants.CENTER);
		logo2.setBounds(75, 615, 135, 131);
		pnlMain.add(logo2);
		logo2.setIcon(new ImageIcon(logo_des1));
	
		JLabel logo3 = new JLabel("");
		logo3.setHorizontalAlignment(SwingConstants.CENTER);
		logo3.setBounds(389, 501, 135, 131);
		pnlMain.add(logo3);
		logo3.setIcon(new ImageIcon(logo_des6));
	
		JLabel logo4 = new JLabel("");
		logo4.setHorizontalAlignment(SwingConstants.CENTER);
		logo4.setBounds(75, 358, 135, 131);
		pnlMain.add(logo4);
		logo4.setIcon(new ImageIcon(logo_des5));
	
		JLabel logo5 = new JLabel("");
		logo5.setHorizontalAlignment(SwingConstants.CENTER);
		logo5.setBounds(610, 615, 135, 131);
		pnlMain.add(logo5);
		logo5.setIcon(new ImageIcon(logo_des4));
		
		lblNewLabel_1 = new JLabel("FOODS & BEVERAGES");
		lblNewLabel_1.setFont(new Font("Franklin Gothic Heavy", Font.PLAIN, 60));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(194, 255, 809, 159);
		pnlMain.add(lblNewLabel_1);
		
		logo6 = new JLabel("");
		logo6.setHorizontalAlignment(SwingConstants.CENTER);
		logo6.setBounds(340, 80, 135, 131);
		pnlMain.add(logo6);
		logo6.setIcon(new ImageIcon(logo_des2));

		logo7 = new JLabel("");
		logo7.setHorizontalAlignment(SwingConstants.CENTER);
		logo7.setBounds(683, 435, 135, 131);
		pnlMain.add(logo7);
		logo7.setIcon(new ImageIcon(logo_des3));

		logo8 = new JLabel("");
		logo8.setHorizontalAlignment(SwingConstants.CENTER);
		logo8.setBounds(985, 646, 135, 131);
		pnlMain.add(logo8);
		logo8.setIcon(new ImageIcon(logo_des7));
		
		logo9 = new JLabel("");
		logo9.setHorizontalAlignment(SwingConstants.CENTER);
		logo9.setBounds(998, 358, 135, 131);
		pnlMain.add(logo9);
		logo9.setIcon(new ImageIcon(logo_des8));
		
		logo10 = new JLabel("");
		logo10.setHorizontalAlignment(SwingConstants.CENTER);
		logo10.setBounds(845, 149, 135, 131);
		pnlMain.add(logo10);
		logo10.setIcon(new ImageIcon(logo_des9));
		
		logo11 = new JLabel("");
		logo11.setHorizontalAlignment(SwingConstants.CENTER);
		logo11.setBounds(1038, 35, 135, 131);
		pnlMain.add(logo11);
		logo11.setIcon(new ImageIcon(logo_des10));
	
		logo12 = new JLabel("");
		logo12.setHorizontalAlignment(SwingConstants.CENTER);
		logo12.setBounds(610, 61, 135, 131);
		pnlMain.add(logo12);
		logo12.setIcon(new ImageIcon(logo_des11));
	
		logo13 = new JLabel("");
		logo13.setHorizontalAlignment(SwingConstants.CENTER);
		logo13.setBounds(262, 656, 135, 131);
		pnlMain.add(logo13);
		logo13.setIcon(new ImageIcon(logo_des12));
				
		pnlMenu = new JPanel();
		pnlMenu.setBounds(1204, 0, 326, 810);
		contentPane.add(pnlMenu);
		pnlMenu.setBorder(new MatteBorder(0, 3, 0, 0, (Color) new Color(255, 255, 224)));
		pnlMenu.setBackground(new Color(54, 38, 8));
		pnlMenu.setLayout(null);
		
		txtUser = new JTextField();
		
		txtUser.setForeground(new Color(255, 255, 255));
		txtUser.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtUser.setText("User");
		txtUser.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(255, 255, 255)));
		txtUser.setBackground(new Color(54, 38, 8));
		txtUser.setBounds(55, 347, 215, 27);
		pnlMenu.add(txtUser);
		txtUser.setColumns(10);
		
		btnNewButton = new JButton("Login");
		btnNewButton.setFont(new Font("Segoe UI Semibold", Font.BOLD, 18));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(139, 69, 19));
		btnNewButton.setBounds(55, 454, 215, 41);
		pnlMenu.add(btnNewButton);
		
		pwdPasscode = new JPasswordField();
		
		pwdPasscode.setEchoChar((char)0);
		pwdPasscode.setFont(new Font("Tahoma", Font.PLAIN, 12));
		pwdPasscode.setForeground(new Color(255, 255, 255));
		pwdPasscode.setText("Passcode");
		pwdPasscode.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(255, 255, 255)));
		pwdPasscode.setBackground(new Color(54, 38, 8));
		pwdPasscode.setBounds(55, 386, 215, 27);
		pnlMenu.add(pwdPasscode);
		
		lblNewLabel = new JLabel("EXIT");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(270, 6, 50, 16);
		pnlMenu.add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("Create new user");
		lblNewLabel_2.setFont(new Font("Monospaced", Font.PLAIN, 14));
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(58, 494, 212, 27);
		pnlMenu.add(lblNewLabel_2);
		
		}
		public void MethodCreateNewUser() {   
			String password = JOptionPane.showInputDialog(null, "Input Passcode", "Enter Password", JOptionPane.PLAIN_MESSAGE);
	        if (password != null && !password.isEmpty()) {
	            try {
	            	String query = "SELECT * FROM admin WHERE password = ? AND users = 'root'";
	                PreparedStatement statement = conn.prepareStatement(query);
	                statement.setString(1, password);

	                ResultSet resultSet = statement.executeQuery();
	                if (resultSet.next()) {
	                	CreateNewUser dialog = new CreateNewUser();
	                    dialog.setModal(true);
	                    dialog.setVisible(true);
	                } else {
	                    JOptionPane.showMessageDialog(null, "Invalid password.", "Error", JOptionPane.ERROR_MESSAGE);
	                }

	                statement.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }     
	}


}

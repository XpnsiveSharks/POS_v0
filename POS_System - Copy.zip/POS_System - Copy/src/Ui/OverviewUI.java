package Ui;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import javax.swing.border.MatteBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import CoreObjClasses.*;
import JDBConnectivity.JdbcConn;
import javax.swing.JTextField;
import javax.swing.JEditorPane;
import javax.swing.JTabbedPane;
public class OverviewUI extends JFrame {
	
	private JPanel contentPane;
	private JPanel pnlMenu;
	private JPanel paneManage;
	private JPanel paneInventory;
	private JPanel paneCashier;
	private JPanel paneLogout;
	private JPanel pnlMain;
	private JLabel lblManagement;
	private JTable tblIngredients;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel;
	private JLabel lblWarningMessage;
    Connection conn = JdbcConn.connect();
    private JLabel lblNewLabel_1;
    private JLabel lblSoldItems;
    private JTable tblSoldItems;
    private JTextField txtIngStatFilter;
    private JTextField txtSoldItemsFilter;
    private JTable tblOrders;
    private JTextField txtOrdersFilter;
    private JPanel panel;
    private JPanel panel_1;
    private JPanel panel_2;
    private JTable tblSoldOrders;
    private JTextField txtSoldAndOrders;
    private JLabel lblSoldItemsAnd;
    private JScrollPane scrollPane_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				        if ("Nimbus".equals(info.getName())) {
				            UIManager.setLookAndFeel(info.getClassName());
				            break;
				        }
				    }
				} catch (Exception e) {
				}
				OverviewUI frame = new OverviewUI();
                frame.setVisible(true);               
				 }
		   });
	}

	/**
	 * Create the frame.
	 */
	public OverviewUI() {
		Components();

		Events();
		
		paneManage.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		    	String password = JOptionPane.showInputDialog(null, "Input Passcode", "Enter Password", JOptionPane.PLAIN_MESSAGE);
		        if (password != null && !password.isEmpty()) {
		            try {
		            	String query = "SELECT * FROM admin WHERE password = ? AND (users = 'Admin' OR users = 'root')";
		                PreparedStatement statement = conn.prepareStatement(query);
		                statement.setString(1, password);

		                ResultSet resultSet = statement.executeQuery();
		                if (resultSet.next()) {
		                	try {
		                        Mods CashierUi = new Mods();
		                        CashierUi.setVisible(true);
		                        dispose();
		                    } catch (Exception e1) {
		                        e1.printStackTrace();
		                    }
		                } else {
		                    JOptionPane.showMessageDialog(null, "Invalid password or user role.", "Error", JOptionPane.ERROR_MESSAGE);
		                }

		                statement.close();
		            } catch (Exception ex) {
		                ex.printStackTrace();
		            }
		        }
		    }
		});	
		
		paneInventory.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        String password = JOptionPane.showInputDialog(null, "Input Passcode", "Enter Password", JOptionPane.PLAIN_MESSAGE);
		        if (password != null && !password.isEmpty()) {
		            try {
		            	String query = "SELECT * FROM admin WHERE password = ? AND (users = 'Admin' OR users = 'root')";
		                PreparedStatement statement = conn.prepareStatement(query);
		                statement.setString(1, password);

		                ResultSet resultSet = statement.executeQuery();
		                if (resultSet.next()) {
		                    try {
		                        Inventory OverviewUI = new Inventory();
		                        OverviewUI.setVisible(true);
		                        dispose(); 
		                    } catch (Exception e1) {
		                        e1.printStackTrace();
		                    }
		                } else {
		                    JOptionPane.showMessageDialog(null, "Invalid password or user role.", "Error", JOptionPane.ERROR_MESSAGE);
		                }

		                statement.close();
		            } catch (Exception ex) {
		                ex.printStackTrace();
		            }
		        }
		    }
		});


		paneCashier.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
            		CashierUi OverviewUI = new CashierUi();
            		OverviewUI.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
		paneLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Are you sure you want to Logout??") == 0) {
					OverviewUI.this.dispose();
                }
			}
		});
		
		
	}
	private void Events() {
		PopulateOverview p = new PopulateOverview(tblIngredients, lblWarningMessage, tblSoldItems, 
				 txtIngStatFilter, txtSoldItemsFilter, tblOrders, txtOrdersFilter, txtSoldAndOrders, tblSoldOrders
				);
		p.checkIngredientQuantityUsedUp();
		p.HistoryOfPurchasedItems();
		p.LoadTblPurchasedItems();
		p.IngredientsStatus();
		p.LoadTblIngredientsStatus();
		p.OrdersHistory();
		p.LoadTblOrders();
		p.LoadTblOrdersSold();
		p.OrdersSold();
		
		minorActionOverview m = new minorActionOverview(paneManage, paneInventory, paneCashier, paneLogout);
		m.menuPanels();
	}
	
	private void Components() {		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1530, 810);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(54, 38, 8));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);		
		contentPane.setLayout(null);
		
		
		pnlMenu = new JPanel();
		pnlMenu.setBorder(new MatteBorder(0, 0, 0, 3, (Color) new Color(255, 255, 224)));
		pnlMenu.setBackground(new Color(54, 38, 8));
		pnlMenu.setBounds(0, 0, 414, 810);
		contentPane.add(pnlMenu);
		pnlMenu.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(89, 63, 14));
		scrollPane.setForeground(new Color(255, 255, 255));
		scrollPane.setBounds(10, 129, 394, 675);
		pnlMenu.add(scrollPane);
		
		tblIngredients = new JTable();
		tblIngredients.setSelectionBackground(new Color(0, 100, 0));
		tblIngredients.setForeground(new Color(255, 255, 255));
		tblIngredients.setBackground(new Color(89, 63, 14));
		scrollPane.setViewportView(tblIngredients);
		
		lblNewLabel = new JLabel("Ingredients Status");
		lblNewLabel.setBounds(10, 10, 394, 68);
		pnlMenu.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Script MT Bold", Font.PLAIN, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 250, 250));
		
		txtIngStatFilter = new JTextField();
		txtIngStatFilter.setForeground(new Color(255, 255, 255));
		txtIngStatFilter.setBackground(new Color(138, 112, 89));
		txtIngStatFilter.setBounds(10, 90, 181, 34);
		pnlMenu.add(txtIngStatFilter);
		txtIngStatFilter.setColumns(10);
		
		pnlMain = new JPanel();
		pnlMain.setBounds(414, 47, 1116, 763);
		pnlMain.setBackground(new Color(54, 38, 8));
		contentPane.add(pnlMain);
		pnlMain.setLayout(null);
						
		paneManage = new JPanel();
		paneManage.setBounds(0, 50, 279, 37);
		pnlMain.add(paneManage);
						
		paneManage.setLayout(null);
		paneManage.setForeground(Color.WHITE);
		paneManage.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneManage.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneManage.setBackground(new Color(89, 63, 14));
								
		lblManagement = new JLabel("MANAGE");
		lblManagement.setHorizontalAlignment(SwingConstants.CENTER);
		lblManagement.setForeground(Color.WHITE);
		lblManagement.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblManagement.setBounds(51, 5, 176, 27);
		paneManage.add(lblManagement);
								
		paneInventory = new JPanel();
		paneInventory.setBounds(279, 50, 279, 37);
		pnlMain.add(paneInventory);
								
		paneInventory.setLayout(null);
		paneInventory.setForeground(Color.WHITE);
		paneInventory.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneInventory.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneInventory.setBackground(new Color(89, 63, 14));
										
		JLabel lblInventory = new JLabel("INVENTORY");
		lblInventory.setBounds(76, 5, 127, 27);
		paneInventory.add(lblInventory);
		lblInventory.setHorizontalAlignment(SwingConstants.CENTER);
		lblInventory.setForeground(Color.WHITE);
		lblInventory.setFont(new Font("Tahoma", Font.BOLD, 18));
										
		paneCashier = new JPanel();
		paneCashier.setBounds(558, 50, 279, 37);
		pnlMain.add(paneCashier);
		paneCashier.setLayout(null);
		paneCashier.setForeground(Color.WHITE);
		paneCashier.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneCashier.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneCashier.setBackground(new Color(89, 63, 14));
										
		JLabel lblCashier = new JLabel("CASHIER");
		lblCashier.setBounds(76, 5, 127, 27);
		paneCashier.add(lblCashier);
		lblCashier.setHorizontalAlignment(SwingConstants.CENTER);
		lblCashier.setForeground(Color.WHITE);
		lblCashier.setFont(new Font("Tahoma", Font.BOLD, 18));
										
		paneLogout = new JPanel();
		paneLogout.setBounds(837, 50, 279, 37);
		pnlMain.add(paneLogout);
		paneLogout.setLayout(null);
		paneLogout.setForeground(Color.WHITE);
		paneLogout.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneLogout.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneLogout.setBackground(new Color(89, 63, 14));
										
		JLabel lblLogout = new JLabel("LOGOUT");
		lblLogout.setBounds(76, 5, 127, 27);
		paneLogout.add(lblLogout);
		lblLogout.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogout.setForeground(Color.WHITE);
		lblLogout.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		lblWarningMessage = new JLabel("");
		lblWarningMessage.setBorder(new MatteBorder(3, 0, 0, 0, (Color) new Color(255, 255, 255)));
		lblWarningMessage.setBounds(0, 0, 1116, 47);
		pnlMain.add(lblWarningMessage);
		lblWarningMessage.setHorizontalAlignment(SwingConstants.CENTER);
		lblWarningMessage.setFont(new Font("Monospaced", Font.PLAIN, 16));
		lblWarningMessage.setForeground(new Color(255, 255, 255));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 97, 1096, 656);
		pnlMain.add(tabbedPane);
		
		panel = new JPanel();
		panel.setBackground(new Color(54, 38, 8));
		tabbedPane.addTab("Sold Items", null, panel, null);
		panel.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 67, 1071, 552);
		panel.add(scrollPane_1);
		
		tblSoldItems = new JTable();
		tblSoldItems.setSelectionBackground(new Color(0, 100, 0));
		tblSoldItems.setForeground(new Color(255, 255, 255));
		scrollPane_1.setViewportView(tblSoldItems);
		tblSoldItems.setBackground(new Color(89, 63, 14));
		
		txtSoldItemsFilter = new JTextField();
		txtSoldItemsFilter.setBounds(10, 23, 181, 34);
		panel.add(txtSoldItemsFilter);
		txtSoldItemsFilter.setForeground(new Color(255, 255, 255));
		txtSoldItemsFilter.setColumns(10);
		txtSoldItemsFilter.setBackground(new Color(138, 112, 89));
		
		lblSoldItems = new JLabel("Sold Items");
		lblSoldItems.setBounds(343, 10, 405, 50);
		panel.add(lblSoldItems);
		lblSoldItems.setHorizontalAlignment(SwingConstants.CENTER);
		lblSoldItems.setForeground(new Color(255, 250, 250));
		lblSoldItems.setFont(new Font("Script MT Bold", Font.PLAIN, 40));
		
		panel_1 = new JPanel();
		panel_1.setBackground(new Color(54, 38, 8));
		tabbedPane.addTab("Orders History", null, panel_1, null);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 67, 1071, 552);
		panel_1.add(scrollPane_2);
		
		tblOrders = new JTable();
		tblOrders.setSelectionBackground(new Color(0, 100, 0));
		tblOrders.setForeground(new Color(255, 255, 255));
		scrollPane_2.setViewportView(tblOrders);
		tblOrders.setBackground(new Color(89, 63, 14));
		
		txtOrdersFilter = new JTextField();
		txtOrdersFilter.setBounds(10, 23, 181, 34);
		panel_1.add(txtOrdersFilter);
		txtOrdersFilter.setForeground(Color.WHITE);
		txtOrdersFilter.setColumns(10);
		txtOrdersFilter.setBackground(new Color(138, 112, 89));
		
		JLabel lblOrders = new JLabel("Orders History");
		lblOrders.setBounds(288, 10, 538, 50);
		panel_1.add(lblOrders);
		lblOrders.setHorizontalAlignment(SwingConstants.CENTER);
		lblOrders.setForeground(new Color(255, 250, 250));
		lblOrders.setFont(new Font("Script MT Bold", Font.PLAIN, 40));
		
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(54, 38, 8));
		tabbedPane.addTab("Orders & Sold Items", null, panel_2, null);
		panel_2.setLayout(null);
		
		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(10, 67, 1071, 552);
		panel_2.add(scrollPane_3);
		
		tblSoldOrders = new JTable();
		tblSoldOrders.setSelectionBackground(new Color(0, 100, 0));
		tblSoldOrders.setForeground(new Color(255, 250, 250));
		scrollPane_3.setViewportView(tblSoldOrders);
		tblSoldOrders.setBackground(new Color(89, 63, 14));
		
		txtSoldAndOrders = new JTextField();
		txtSoldAndOrders.setForeground(Color.WHITE);
		txtSoldAndOrders.setColumns(10);
		txtSoldAndOrders.setBackground(new Color(138, 112, 89));
		txtSoldAndOrders.setBounds(10, 23, 181, 34);
		panel_2.add(txtSoldAndOrders);
		
		lblSoldItemsAnd = new JLabel("Sold Items And Orders History");
		lblSoldItemsAnd.setHorizontalAlignment(SwingConstants.CENTER);
		lblSoldItemsAnd.setForeground(new Color(255, 250, 250));
		lblSoldItemsAnd.setFont(new Font("Script MT Bold", Font.PLAIN, 40));
		lblSoldItemsAnd.setBounds(276, 7, 538, 50);
		panel_2.add(lblSoldItemsAnd);
		
		lblNewLabel_1 = new JLabel("Status Bar");
		lblNewLabel_1.setFont(new Font("Script MT Bold", Font.BOLD, 29));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(414, 0, 1116, 47);
		contentPane.add(lblNewLabel_1);
		
		}
	}

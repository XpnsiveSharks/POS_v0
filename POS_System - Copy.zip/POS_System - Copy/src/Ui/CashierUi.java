package Ui;
/**
 * @author: Marynelle
 */
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import javax.swing.border.MatteBorder;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.border.LineBorder;
import javax.swing.JComboBox;
import CoreObjClasses.*;
import JDBConnectivity.JdbcConn;

import javax.swing.table.DefaultTableModel;
public class CashierUi extends JFrame {
	private Image logo_search = new ImageIcon(CashierUi.class.getResource("/rss/search.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image logo_des1 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-bubble-tea-100.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des2 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-bubble-tea-96.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des3 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-drinking-64.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des4 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-green-tea-100.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des5 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-kawaii-milk-100.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	//new added
	private Image logo_des7 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-taco-64.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des8 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-milk-bottle-80.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des9 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-metal-straw-64.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des10 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-coffee-to-go-80.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des11 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-burger-100.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private Image logo_des12 = new ImageIcon(CashierUi.class.getResource("/rss/icons8-bubble-tea-96.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
	private JPanel contentPane;
	private JPanel pnlMenu;
	private JPanel paneCashier;
	private JPanel paneInventory;
	private JPanel paneOverview;
	private JPanel paneLogout;
	private JPanel pnlMain;
	private JLabel lblManagement;
	private JTable tblOrders;
	private JScrollPane scrollPane;
	private JTextField txtTotalP;
	private JTextField txtChange;
	private JTextField txtPayment;
	private JRadioButton rdbtnDine;
	private JLabel lblOorderMethod;
	private JRadioButton rdbtnTakeout;
	private JRadioButton rdbtnDelivery;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JLabel lblCustomersInfo;
	private JTextField txtName;
	private JTextField txtPhoneemail;
	private JTextField txtAddress;
	private JPanel pnlMain_1;
	private JPanel pnlMain_2;
	private JPanel pnlMain_3;
	private JTable tblAddOns;
	private JComboBox cbxAddOnsCat;
	private JScrollPane scrollPane_1;
	private JLabel LblAddOnsSearch;
	private JTable tblProducts;
	private JLabel lblProducts;
	private JLabel lblSearchProducts;
	private JTextField txtSearchProID;
	private JLabel lblSearchProID;
	private JComboBox cbxProdCat;
	private JButton btnPay;
	private JTable tblProdSize, tblSugarLvl;
	private JButton btnRemoveItem;
	private JTextField txtGenOrID;
	private JButton btnGenerateOrderID;
	private JButton btnAddCusInfo;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel LblDes1;
	private JLabel LblDes2;
	private JLabel LblDes3;
	private JLabel LblDes4;
	private JLabel LblDes5;
	private JButton btnPrintReceipt;
    Connection conn = JdbcConn.connect();

    
	

	public CashierUi() {
		Components();
		Events();
	}
	private void Events() {
		//Populate
		PopulateCashier pp = new PopulateCashier(cbxAddOnsCat, tblProdSize, tblSugarLvl, cbxProdCat, tblOrders);
		pp.PopulateCbxAddOns();
		pp.PopulateCbxProdCat();
		//Actions
		ActionCashier a = new ActionCashier(LblAddOnsSearch, cbxAddOnsCat, tblAddOns, cbxProdCat, tblProducts,
				lblSearchProducts, txtSearchProID, lblSearchProID);
		a.AddOnsActions();
		a.ActionCbxSearchProdCat();
//		a.filterProduct();
//		a.loadTableProduct();

		
		
		OrderActions o = new OrderActions(tblAddOns, tblProdSize, tblSugarLvl, tblProducts,
			 txtName, txtPhoneemail, txtAddress, rdbtnDine,  rdbtnTakeout,  rdbtnDelivery,
			 buttonGroup,  tblOrders,  btnPay,  btnRemoveItem,  txtGenOrID,
			  btnGenerateOrderID, txtTotalP, txtChange, txtPayment, btnAddCusInfo, btnPrintReceipt);

		o.InsertProductToDb();
		o.InsertAddOnsToProduct();		
		o.GenerateOrderID();
		o.PayButton();
		o.RemoveItemFromTableOrders();
		o.ItemsTotalDisplayInTextField();
		o.PayButton();
		o.orders();
		o.printReceipt();

		
		//Designs
		minorFunctionsForCashier m = new minorFunctionsForCashier(paneCashier, paneOverview, 
				 paneLogout, paneInventory);
		m.menuPanels();

		paneLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Are you sure you want to Logout??") == 0) {
					CashierUi.this.dispose();
                }
			}
		});
		paneCashier.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        String password = JOptionPane.showInputDialog(null, "Input Passcode", "Enter Password", JOptionPane.PLAIN_MESSAGE);
		        if (password != null && !password.isEmpty()) {
		            try {
		            	String query = "SELECT * FROM admin WHERE password = ? AND (users = 'Admin' OR users = 'root')";
		                PreparedStatement statement = conn.prepareStatement(query);
		                statement.setString(1, password);

		                ResultSet resultSet = statement.executeQuery();
		                if (resultSet.next()) {
		                	try {
		                        Mods CashierUi = new Mods();
		                        CashierUi.setVisible(true);
		                        dispose();
		                    } catch (Exception e1) {
		                        e1.printStackTrace();
		                    }
		                } else {
		                    JOptionPane.showMessageDialog(null, "Invalid password or user role.", "Error", JOptionPane.ERROR_MESSAGE);
		                }

		                statement.close();
		            } catch (Exception ex) {
		                ex.printStackTrace();
		            }
		        }
		    }
		});
		paneInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String password = JOptionPane.showInputDialog(null, "Input Passcode", "Enter Password", JOptionPane.PLAIN_MESSAGE);
		        if (password != null && !password.isEmpty()) {
		            try {
		                String query = "SELECT * FROM admin WHERE password = ?";
		                PreparedStatement statement = conn.prepareStatement(query);
		                statement.setString(1, password);

		                ResultSet resultSet = statement.executeQuery();
		                if (resultSet.next()) {
		                    try {
		                    	Inventory CashierUi = new Inventory();
		                        CashierUi.setVisible(true);
		                        dispose();
		                    } catch (Exception e1) {
		                        e1.printStackTrace();
		                    }
		                } else {
		                    JOptionPane.showMessageDialog(null, "Invalid password.", "Error", JOptionPane.ERROR_MESSAGE);
		                }

		                statement.close();
		                conn.close();
		            } catch (Exception ex) {
		                ex.printStackTrace();
		            }
		        }
			}
		});
		paneOverview.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
            		OverviewUI CashierUI = new OverviewUI();
            		CashierUI.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
		
	}
	private void Components() {		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1530, 810);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(54, 58, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);		
		contentPane.setLayout(null);
		
		
		pnlMenu = new JPanel();
		pnlMenu.setBorder(new MatteBorder(0, 0, 0, 3, (Color) new Color(255, 255, 224)));
		pnlMenu.setBackground(new Color(54, 38, 8));
		pnlMenu.setBounds(6, 0, 588, 810);
		contentPane.add(pnlMenu);
		pnlMenu.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(139, 69, 19));
		scrollPane.setBounds(6, 172, 576, 567);
		pnlMenu.add(scrollPane);
		
		tblOrders = new JTable();
		tblOrders.setForeground(new Color(255, 255, 255));
		tblOrders.setSelectionBackground(new Color(0, 100, 0));
		tblOrders.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Product", "Qty", "Sugar lvl", "Size", "Size fee", "Price"
			}
		));
		scrollPane.setViewportView(tblOrders);
		tblOrders.setBackground(new Color(138, 112, 89));
		
		btnPay = new JButton("Pay");
		btnPay.setBorder(null);
		btnPay.setBackground(new Color(139, 69, 19));
		btnPay.setForeground(new Color(255, 255, 255));
		btnPay.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnPay.setBounds(201, 751, 176, 41);
		pnlMenu.add(btnPay);
		
		btnRemoveItem = new JButton("Remove Item");
		btnRemoveItem.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnRemoveItem.setBorder(null);
		btnRemoveItem.setBackground(new Color(139, 69, 19));
		btnRemoveItem.setForeground(new Color(255, 255, 255));
		btnRemoveItem.setBounds(17, 751, 167, 41);
		pnlMenu.add(btnRemoveItem);
		
		txtTotalP = new JTextField();
		txtTotalP.setHorizontalAlignment(SwingConstants.CENTER);
		txtTotalP.setForeground(new Color(255, 255, 255));
		txtTotalP.setFont(new Font("SansSerif", Font.BOLD, 14));
		txtTotalP.setBorder(new LineBorder(new Color(0, 0, 0)));
		txtTotalP.setBackground(Color.decode("#8a7059"));
		txtTotalP.setEditable(false);
		txtTotalP.setBounds(15, 119, 176, 41);
		pnlMenu.add(txtTotalP);
		txtTotalP.setColumns(10);
		
		txtChange = new JTextField();
		txtChange.setHorizontalAlignment(SwingConstants.CENTER);
		txtChange.setForeground(new Color(255, 255, 255));
		txtChange.setFont(new Font("SansSerif", Font.BOLD, 14));
		txtChange.setBackground(Color.decode("#8a7059"));
		txtChange.setBorder(new LineBorder(new Color(0, 0, 0)));
		txtChange.setEditable(false);
		txtChange.setColumns(10);
		txtChange.setBounds(206, 119, 176, 41);
		pnlMenu.add(txtChange);
		
		JLabel lblNewLabel = new JLabel("Total");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(15, 84, 174, 34);
		pnlMenu.add(lblNewLabel);
		
		JLabel lblChange = new JLabel("Change");
		lblChange.setHorizontalAlignment(SwingConstants.CENTER);
		lblChange.setForeground(Color.WHITE);
		lblChange.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblChange.setBounds(204, 84, 176, 34);
		pnlMenu.add(lblChange);
		
		txtPayment = new JTextField();
		txtPayment.setHorizontalAlignment(SwingConstants.CENTER);
		txtPayment.setForeground(new Color(255, 255, 255));
		txtPayment.setFont(new Font("SansSerif", Font.BOLD, 14));
		txtPayment.setBorder(new LineBorder(new Color(0, 0, 0)));
		txtPayment.setBackground(Color.decode("#8a7059"));
		txtPayment.setBounds(397, 119, 176, 41);
		pnlMenu.add(txtPayment);
		txtPayment.setColumns(10);
		
		JLabel lblPayment = new JLabel("Payment");
		lblPayment.setHorizontalAlignment(SwingConstants.CENTER);
		lblPayment.setForeground(Color.WHITE);
		lblPayment.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPayment.setBounds(395, 84, 176, 34);
		pnlMenu.add(lblPayment);
		
		btnPrintReceipt = new JButton("Print Receipt");
		btnPrintReceipt.setForeground(new Color(255, 255, 255));
		btnPrintReceipt.setFont(new Font("SansSerif", Font.BOLD, 18));
		btnPrintReceipt.setBackground(new Color(139, 69, 19));
		btnPrintReceipt.setBorder(null);
		btnPrintReceipt.setBounds(394, 751, 176, 41);
		pnlMenu.add(btnPrintReceipt);
		
		txtGenOrID = new JTextField();
		txtGenOrID.setFont(new Font("SansSerif", Font.BOLD, 14));
		txtGenOrID.setBorder(null);
		txtGenOrID.setForeground(new Color(255, 255, 255));
		txtGenOrID.setBackground(Color.decode("#8a7059"));
		txtGenOrID.setHorizontalAlignment(SwingConstants.CENTER);
		txtGenOrID.setBounds(84, 20, 167, 39);
		pnlMenu.add(txtGenOrID);
		txtGenOrID.setEditable(false);
		txtGenOrID.setColumns(10);
		
		btnGenerateOrderID = new JButton("GENERATE ORDER ID");
		btnGenerateOrderID.setForeground(new Color(255, 255, 255));
		btnGenerateOrderID.setBorder(null);
		btnGenerateOrderID.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnGenerateOrderID.setBackground(new Color(139, 69, 19));
		btnGenerateOrderID.setBounds(335, 20, 167, 38);
		pnlMenu.add(btnGenerateOrderID);
		
		LblDes1 = new JLabel("");
		LblDes1.setHorizontalAlignment(SwingConstants.CENTER);
		LblDes1.setBounds(6, 6, 66, 62);
		pnlMenu.add(LblDes1);
		LblDes1.setIcon(new ImageIcon(logo_des1));
		
		LblDes2 = new JLabel("");
		LblDes2.setHorizontalAlignment(SwingConstants.CENTER);
		LblDes2.setBounds(356, 56, 66, 62);
		pnlMenu.add(LblDes2);
		LblDes2.setIcon(new ImageIcon(logo_des2));
		
		LblDes3 = new JLabel("");
		LblDes3.setHorizontalAlignment(SwingConstants.CENTER);
		LblDes3.setBounds(165, 56, 66, 62);
		pnlMenu.add(LblDes3);
		LblDes3.setIcon(new ImageIcon(logo_des3));
		
		LblDes4 = new JLabel("");
		LblDes4.setHorizontalAlignment(SwingConstants.CENTER);
		LblDes4.setBounds(514, 6, 66, 62);
		pnlMenu.add(LblDes4);
		LblDes4.setIcon(new ImageIcon(logo_des4));
		
		JLabel logo1 = new JLabel("");
		logo1.setBounds(263, 6, 66, 62);
		pnlMenu.add(logo1);
		logo1.setHorizontalAlignment(SwingConstants.CENTER);
		logo1.setIcon(new ImageIcon(logo_des7));


		
		pnlMain = new JPanel();
		pnlMain.setBounds(588, 47, 942, 763);
		pnlMain.setBackground(new Color(54, 38, 8));
		contentPane.add(pnlMain);
		pnlMain.setLayout(null);
		
		pnlMain_1 = new JPanel();
		pnlMain_1.setBorder(new LineBorder(new Color(255, 255, 255)));
		pnlMain_1.setBackground(new Color(54, 38, 8));
		pnlMain_1.setBounds(12, 493, 489, 264);
		pnlMain.add(pnlMain_1);
		pnlMain_1.setLayout(null);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(6, 66, 474, 192);
		pnlMain_1.add(scrollPane_1);
		
		tblAddOns = new JTable();
		tblAddOns.setForeground(new Color(255, 255, 255));
		tblAddOns.setSelectionBackground(new Color(0, 100, 0));
		tblAddOns.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Add-Ons ID", "Add-Ons", "Price"
			}
		) {

			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tblAddOns.getColumnModel().getColumn(0).setResizable(false);
		tblAddOns.getColumnModel().getColumn(2).setResizable(false);
		scrollPane_1.setViewportView(tblAddOns);
		tblAddOns.setBackground(new Color(138, 112, 89));
		
		cbxAddOnsCat = new JComboBox();
		cbxAddOnsCat.setBorder(null);
		cbxAddOnsCat.setBackground(new Color(139, 69, 19));
		cbxAddOnsCat.setBounds(60, 34, 224, 31);
		pnlMain_1.add(cbxAddOnsCat);
		
		JLabel lblAddons = new JLabel("ADD-ONS");
		lblAddons.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddons.setForeground(Color.WHITE);
		lblAddons.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAddons.setBounds(158, 6, 176, 27);
		pnlMain_1.add(lblAddons);
		
		LblAddOnsSearch = new JLabel("");
		LblAddOnsSearch.setBounds(304, 34, 30, 31);
		pnlMain_1.add(LblAddOnsSearch);
		LblAddOnsSearch.setIcon(new ImageIcon(logo_search));
		
		JLabel logo4 = new JLabel("");
		logo4.setHorizontalAlignment(SwingConstants.CENTER);
		logo4.setBounds(392, 3, 66, 62);
		pnlMain_1.add(logo4);
		logo4.setIcon(new ImageIcon(logo_des10));

		
		pnlMain_2 = new JPanel();
		pnlMain_2.setBorder(new LineBorder(new Color(255, 255, 255)));
		pnlMain_2.setBackground(new Color(54, 38, 8));
		pnlMain_2.setBounds(503, 493, 439, 264);
		pnlMain.add(pnlMain_2);
		pnlMain_2.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(224, 8, 196, 194);
		pnlMain_2.add(panel_1);
		panel_1.setBorder(new LineBorder(new Color(255, 255, 255)));
		panel_1.setBackground(new Color(89, 63, 14));
		panel_1.setLayout(null);
		
		rdbtnDine = new JRadioButton("Dine-In");
		buttonGroup.add(rdbtnDine);
		rdbtnDine.setFont(new Font("Tahoma", Font.BOLD, 12));
		rdbtnDine.setForeground(new Color(255, 255, 255));
		rdbtnDine.setBounds(51, 79, 94, 18);
		panel_1.add(rdbtnDine);
		
		lblOorderMethod = new JLabel("ORDER METHOD");
		lblOorderMethod.setBorder(new LineBorder(new Color(255, 255, 255)));
		lblOorderMethod.setHorizontalAlignment(SwingConstants.CENTER);
		lblOorderMethod.setForeground(Color.WHITE);
		lblOorderMethod.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblOorderMethod.setBounds(3, 6, 190, 34);
		panel_1.add(lblOorderMethod);
		
		rdbtnTakeout = new JRadioButton("Take-Out");
		buttonGroup.add(rdbtnTakeout);
		rdbtnTakeout.setForeground(Color.WHITE);
		rdbtnTakeout.setFont(new Font("Tahoma", Font.BOLD, 12));
		rdbtnTakeout.setBounds(51, 112, 94, 18);
		panel_1.add(rdbtnTakeout);
		
		rdbtnDelivery = new JRadioButton("Delivery");
		buttonGroup.add(rdbtnDelivery);
		rdbtnDelivery.setForeground(Color.WHITE);
		rdbtnDelivery.setFont(new Font("Tahoma", Font.BOLD, 12));
		rdbtnDelivery.setBounds(51, 145, 94, 18);
		panel_1.add(rdbtnDelivery);
		
		JPanel panel = new JPanel();
		panel.setBounds(16, 8, 196, 194);
		pnlMain_2.add(panel);
		panel.setBorder(new LineBorder(new Color(255, 255, 255)));
		panel.setBackground(new Color(89, 63, 14));
		panel.setLayout(null);
		
		lblCustomersInfo = new JLabel("CUSTOMERS INFO");
		lblCustomersInfo.setHorizontalAlignment(SwingConstants.CENTER);
		lblCustomersInfo.setForeground(Color.WHITE);
		lblCustomersInfo.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCustomersInfo.setBorder(new LineBorder(new Color(255, 255, 255)));
		lblCustomersInfo.setBounds(3, 6, 190, 34);
		panel.add(lblCustomersInfo);
		
		txtName = new JTextField();
		txtName.setHorizontalAlignment(SwingConstants.CENTER);
		txtName.setForeground(new Color(255, 250, 250));
		txtName.setBorder(new LineBorder(new Color(0, 0, 0)));
		txtName.setBackground(Color.decode("#8a7059"));
		txtName.setBounds(4, 52, 187, 28);
		panel.add(txtName);
		txtName.setColumns(10);
		
		txtPhoneemail = new JTextField();
		txtPhoneemail.setHorizontalAlignment(SwingConstants.CENTER);
		txtPhoneemail.setForeground(new Color(255, 250, 250));
		txtPhoneemail.setBorder(new LineBorder(new Color(0, 0, 0)));
		txtPhoneemail.setBackground(Color.decode("#8a7059"));
		txtPhoneemail.setColumns(10);
		txtPhoneemail.setBounds(4, 109, 187, 28);
		panel.add(txtPhoneemail);
		 	
		txtAddress = new JTextField();
		txtAddress.setHorizontalAlignment(SwingConstants.CENTER);
		txtAddress.setBorder(new LineBorder(new Color(0, 0, 0)));
		txtAddress.setBackground(Color.decode("#8a7059"));
		txtAddress.setForeground(new Color(255, 250, 250));
		txtAddress.setColumns(10);
		txtAddress.setBounds(4, 160, 187, 28);
		panel.add(txtAddress);
		
		lblNewLabel_1 = new JLabel("Address");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(3, 146, 190, 16);
		panel.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Phone/Email");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(3, 94, 190, 16);
		panel.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Name");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(3, 38, 190, 16);
		panel.add(lblNewLabel_3);
		
		btnAddCusInfo = new JButton("ADD");
		btnAddCusInfo.setForeground(new Color(255, 255, 255));
		btnAddCusInfo.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnAddCusInfo.setBackground(new Color(138, 112, 89));
		btnAddCusInfo.setBounds(118, 212, 201, 38);
		pnlMain_2.add(btnAddCusInfo);
		
		pnlMain_3 = new JPanel();
		pnlMain_3.setLayout(null);
		pnlMain_3.setBorder(new LineBorder(new Color(255, 255, 255)));
		pnlMain_3.setBackground(new Color(54, 38, 8));
		pnlMain_3.setBounds(12, 6, 930, 485);
		pnlMain.add(pnlMain_3);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(6, 68, 914, 411);
		pnlMain_3.add(scrollPane_4);
		
		tblProducts = new JTable();
		tblProducts.setFont(new Font("Tahoma", Font.PLAIN, 14));
		tblProducts.setForeground(new Color(255, 255, 255));
		tblProducts.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Product Name", "Price", "Describe", "Image"
			}
		));
		scrollPane_4.setViewportView(tblProducts);
		tblProducts.setBackground(new Color(138, 112, 89));
		tblProducts.setSelectionBackground(new Color(0, 100, 0));
		
		lblProducts = new JLabel("PRODUCTS");
		lblProducts.setHorizontalAlignment(SwingConstants.CENTER);
		lblProducts.setForeground(Color.WHITE);
		lblProducts.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblProducts.setBounds(467, 6, 176, 27);
		pnlMain_3.add(lblProducts);
		
		cbxProdCat = new JComboBox();
		cbxProdCat.setBackground(new Color(139, 69, 19));
		cbxProdCat.setBorder(null);
		cbxProdCat.setBounds(6, 35, 224, 31);
		pnlMain_3.add(cbxProdCat);
		
		lblSearchProducts = new JLabel("");
		lblSearchProducts.setBounds(230, 35, 30, 31);
		pnlMain_3.add(lblSearchProducts);
		lblSearchProducts.setIcon(new ImageIcon(logo_search));
		
		txtSearchProID = new JTextField();
		txtSearchProID.setHorizontalAlignment(SwingConstants.CENTER);
		txtSearchProID.setBorder(new LineBorder(new Color(0, 0, 0)));
		txtSearchProID.setBackground(Color.decode("#8a7059"));
		txtSearchProID.setForeground(new Color(255, 255, 255));
		txtSearchProID.setColumns(10);
		txtSearchProID.setBounds(280, 36, 194, 28);
		pnlMain_3.add(txtSearchProID);
		
		lblSearchProID = new JLabel("");
		lblSearchProID.setBounds(477, 35, 30, 31);
		pnlMain_3.add(lblSearchProID);
		lblSearchProID.setIcon(new ImageIcon(logo_search));

		
		JLabel logo2 = new JLabel("");
		logo2.setHorizontalAlignment(SwingConstants.CENTER);
		logo2.setBounds(854, 6, 66, 62);
		pnlMain_3.add(logo2);
		logo2.setIcon(new ImageIcon(logo_des9));

		
		JLabel logo3 = new JLabel("");
		logo3.setHorizontalAlignment(SwingConstants.CENTER);
		logo3.setBounds(741, 6, 66, 62);
		pnlMain_3.add(logo3);
		logo3.setIcon(new ImageIcon(logo_des8));
		
		LblDes5 = new JLabel("");
		LblDes5.setBounds(611, 4, 66, 62);
		pnlMain_3.add(LblDes5);
		LblDes5.setHorizontalAlignment(SwingConstants.CENTER);
		LblDes5.setIcon(new ImageIcon(logo_des5));

		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(null);
		panel_2.setBackground(new Color(54, 38, 8));
		panel_2.setBounds(594, 0, 936, 46);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		paneOverview = new JPanel();
		
		paneOverview.setBounds(464, 4, 236, 37);
		panel_2.add(paneOverview);
		paneOverview.setLayout(null);
		paneOverview.setForeground(Color.WHITE);
		paneOverview.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneOverview.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneOverview.setBackground(new Color(89, 63, 14));
		
		JLabel lblOverview = new JLabel("OVERVIEW");
		lblOverview.setBounds(54, 5, 127, 27);
		paneOverview.add(lblOverview);
		lblOverview.setHorizontalAlignment(SwingConstants.CENTER);
		lblOverview.setForeground(Color.WHITE);
		lblOverview.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		paneLogout = new JPanel();
		paneLogout.setBounds(700, 4, 236, 37);
		panel_2.add(paneLogout);
		paneLogout.setLayout(null);
		paneLogout.setForeground(Color.WHITE);
		paneLogout.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneLogout.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneLogout.setBackground(new Color(89, 63, 14));
		
		JLabel lblLogout = new JLabel("LOGOUT");
		lblLogout.setBounds(54, 5, 127, 27);
		paneLogout.add(lblLogout);
		lblLogout.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogout.setForeground(Color.WHITE);
		lblLogout.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		paneInventory = new JPanel();
		
		paneInventory.setBounds(229, 4, 235, 37);
		panel_2.add(paneInventory);
		
		paneInventory.setLayout(null);
		paneInventory.setForeground(Color.WHITE);
		paneInventory.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneInventory.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneInventory.setBackground(new Color(89, 63, 14));
		
		JLabel lblInventory = new JLabel("INVENTORY");
		lblInventory.setBounds(54, 5, 127, 27);
		paneInventory.add(lblInventory);
		lblInventory.setHorizontalAlignment(SwingConstants.CENTER);
		lblInventory.setForeground(Color.WHITE);
		lblInventory.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		paneCashier = new JPanel();
		
		paneCashier.setBounds(0, 4, 229, 37);
		panel_2.add(paneCashier);
		
		paneCashier.setLayout(null);
		paneCashier.setForeground(Color.WHITE);
		paneCashier.setFont(new Font("Tahoma", Font.PLAIN, 10));
		paneCashier.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(255, 255, 255)));
		paneCashier.setBackground(new Color(89, 63, 14));
		
		lblManagement = new JLabel("MANAGE");
		lblManagement.setHorizontalAlignment(SwingConstants.CENTER);
		lblManagement.setForeground(Color.WHITE);
		lblManagement.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblManagement.setBounds(26, 5, 176, 27);
		paneCashier.add(lblManagement);
		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				        if ("Nimbus".equals(info.getName())) {
				            UIManager.setLookAndFeel(info.getClassName());
				            break;
				        }
				    }
				} catch (Exception e) {
				}
				CashierUi frame = new CashierUi();
                frame.setVisible(true);               
				 }
		   });
		}
	}

